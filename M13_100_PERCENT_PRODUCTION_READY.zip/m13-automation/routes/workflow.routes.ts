import { Router } from 'express';
import { workflowController } from '../controllers/workflow.controller';
import { m13AuthMiddleware } from '../middleware/m13.middleware';
const router=Router();
router.use(m13AuthMiddleware);
router.post('/',workflowController.createWorkflow); router.get('/',workflowController.listWorkflows); router.get('/:id',workflowController.getWorkflow); router.put('/:id',workflowController.updateWorkflow); router.delete('/:id',workflowController.deleteWorkflow); router.post('/:id/trigger',workflowController.manualTrigger);
export default router;
