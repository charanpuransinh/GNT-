export function clonePayload<T>(value:T):T{return structuredClone(value);}
export function isSafeHttpUrl(value:string):boolean{try{const u=new URL(value);return u.protocol==='https:';}catch{return false;}}
export function assertValidTimezone(timezone:string):void{try{new Intl.DateTimeFormat('en-US',{timeZone:timezone}).format();}catch{throw new Error('INVALID_TIMEZONE');}}
export function assertNonNegativeInteger(value:unknown,name:string):asserts value is number{if(typeof value!=='number'||!Number.isInteger(value)||value<0)throw new Error(`${name}_INVALID`);}
