import { prisma } from '../db';
import { M13EventPayload } from '../types/m13.types';
export class TriggerEvaluatorService {
 async evaluateEventTrigger(event:M13EventPayload):Promise<string[]> { const triggers=await prisma.m13Trigger.findMany({where:{tenantId:event.tenantId,isActive:true,type:'EVENT'},include:{workflow:true}}); return triggers.filter(t=>{const c=t.config as Record<string,unknown>;return c.eventName===event.eventName&&t.workflow.isActive&&t.workflow.tenantId===event.tenantId;}).map(t=>t.workflowId); }
 async evaluateScheduleTrigger(scheduleId:string,tenantId:string):Promise<string|null> { const s=await prisma.m13Schedule.findFirst({where:{id:scheduleId,tenantId},include:{workflow:true}}); return s?.isActive&&s.workflow.isActive?s.workflowId:null; }
 async evaluateManualTrigger(workflowId:string,tenantId:string):Promise<boolean> { const w=await prisma.m13Workflow.findFirst({where:{id:workflowId,tenantId},include:{triggers:true}}); return !!w?.isActive&&w.triggers.some(t=>t.type==='MANUAL'&&t.isActive&&t.tenantId===tenantId); }
}
export const triggerEvaluatorService=new TriggerEvaluatorService();
