import { prisma } from '../db'; import { M13JobStatus } from '../types/m13.types';
export class JobProcessorService{
 async getJob(jobId:string,tenantId:string){return prisma.m13Job.findFirst({where:{id:jobId,tenantId},include:{logs:{orderBy:{createdAt:'asc'}}}})}
 async listJobs(workflowId:string|undefined,tenantId:string,status?:M13JobStatus){return prisma.m13Job.findMany({where:{tenantId,...(workflowId?{workflowId}:{}),...(status?{status}:{})},orderBy:{createdAt:'desc'},include:{logs:{take:5,orderBy:{createdAt:'desc'}}}})}
 async updateJobStatus(jobId:string,tenantId:string,status:M13JobStatus,result?:Record<string,unknown>,error?:string){const data:any={status};if(result!==undefined)data.result=result;if(error!==undefined)data.error=error;if(status===M13JobStatus.COMPLETED||status===M13JobStatus.FAILED||status===M13JobStatus.CANCELLED)data.completedAt=new Date();await prisma.m13Job.updateMany({where:{id:jobId,tenantId},data});}
 async cancelJob(jobId:string,tenantId:string){const updated=await prisma.m13Job.updateMany({where:{id:jobId,tenantId,status:{in:[M13JobStatus.PENDING,M13JobStatus.RETRYING]}},data:{status:M13JobStatus.CANCELLED,completedAt:new Date()}});return updated.count===1;}
 async logJobEvent(jobId:string,tenantId:string,level:string,message:string,metadata?:Record<string,unknown>){await prisma.m13JobLog.create({data:{jobId,tenantId,level,message,metadata:metadata||{}}});}
}
export const jobProcessorService=new JobProcessorService();
