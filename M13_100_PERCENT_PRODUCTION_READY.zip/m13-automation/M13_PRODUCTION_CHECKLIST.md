# M13 Production Checklist

## Code gate
- [x] Broken relative imports removed
- [x] Placeholder/mock implementation paths removed from M13 source
- [x] Cron evaluation implemented with timezone support
- [x] Atomic schedule claiming implemented
- [x] Workflow action completion is tied to actual action result
- [x] Retry flow separated from BullMQ duplicate retries
- [x] Production auth rejects unverified identity context
- [x] Request schemas validated
- [x] Outbound API requires HTTPS
- [x] Graceful shutdown wired
- [x] Frontend API paths aligned with backend contract

## Deployment gate
- [ ] Apply Prisma schema/migration to target PostgreSQL
- [ ] Verify Redis connectivity/TLS in target environment
- [ ] Host M06 must attach verified identity context before M13 middleware
- [ ] Configure outbound M13 endpoint secrets only where actions are enabled
- [ ] Run target-environment integration/smoke tests

These deployment items are environment operations, not missing M13 source-code work.
