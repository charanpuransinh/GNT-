import { Request, Response, NextFunction } from 'express';
import { ZodSchema } from 'zod';
export interface M13RequestContext { tenantId:string; userId:string; roles?:string[]; }
declare global { namespace Express { interface Request { m13?: M13RequestContext; verifiedIdentity?: M13RequestContext; } } }
export function m13AuthMiddleware(req:Request,res:Response,next:NextFunction):void {
  const auth=req.header('authorization');
  if(!auth?.startsWith('Bearer ') || auth.length<16){res.status(401).json({success:false,error:'UNAUTHORIZED'});return;}
  const verified=req.verifiedIdentity;
  if(!verified?.tenantId || !verified.userId){res.status(401).json({success:false,error:'AUTH_CONTEXT_NOT_VERIFIED'});return;}
  req.m13=verified; next();
}
export function validate(schema:ZodSchema){return(req:Request,res:Response,next:NextFunction):void=>{const parsed=schema.safeParse(req.body);if(!parsed.success){res.status(400).json({success:false,error:'VALIDATION_ERROR',details:parsed.error.issues});return;}req.body=parsed.data;next();};}
export function m13ErrorHandler(err:unknown,_req:Request,res:Response,_next:NextFunction):void{res.status(500).json({success:false,error:'M13_INTERNAL_ERROR'});}
export function requireTenant(req:Request):string{const tenantId=req.m13?.tenantId;if(!tenantId)throw new Error('M13_AUTH_TENANT_REQUIRED');return tenantId;}
