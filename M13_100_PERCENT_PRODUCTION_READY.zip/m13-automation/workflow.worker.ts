import { Worker, RedisOptions } from 'bullmq';
import { M13_QUEUE_NAMES, M13_JOB_NAMES } from './queue/queue.names';
import { workflowEngineService } from './services/workflow-engine.service';
import { retryHandlerService } from './services/retry-handler.service';
const connection:RedisOptions={host:process.env.REDIS_HOST||(process.env.NODE_ENV==='production'?'':'localhost'),port:Number(process.env.REDIS_PORT||6379),password:process.env.REDIS_PASSWORD, ...(process.env.REDIS_TLS==='true'?{tls:{}}:{})};
export const workflowWorker=new Worker(M13_QUEUE_NAMES.WORKFLOW,async job=>{if(job.name===M13_JOB_NAMES.EXECUTE_WORKFLOW){try{await workflowEngineService.executeWorkflow(job.data.jobId);}catch(error){await retryHandlerService.autoRetry(job.data.jobId,job.data.tenantId);}}else throw new Error(`M13_UNKNOWN_JOB:${job.name}`);},{connection,concurrency:5});
