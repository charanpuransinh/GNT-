import { describe,it,expect } from 'vitest';
describe('M13 API contract',()=>{it('uses the locked base path',()=>{expect('/api/m13').toBe('/api/m13');});});
