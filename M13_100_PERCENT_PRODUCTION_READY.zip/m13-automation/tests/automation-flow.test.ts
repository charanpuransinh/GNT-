import {describe,it,expect} from "vitest";
import {M13JobStatus} from "../types/m13.types";
describe("M13 production invariants",()=>{it("has terminal statuses",()=>{expect([M13JobStatus.COMPLETED,M13JobStatus.FAILED,M13JobStatus.CANCELLED]).toHaveLength(3)});it("does not expose a dev auth bypass in production middleware",async()=>{const fs=await import("node:fs/promises");const s=await fs.readFile(new URL("../middleware/m13.middleware.ts",import.meta.url),"utf8");expect(s).not.toContain("M13_DEV_AUTH");});});
