# M13 Smart Automation — Production Lock Package

**Status: PRODUCTION-CANDIDATE / INTEGRATION-GATE**

## Implemented
- Workflow CRUD with trigger/action definitions
- Manual, event and schedule trigger evaluation
- BullMQ workflow, schedule, retry and event queues
- Sequential action execution with failure propagation
- Retry with exponential backoff and max retry enforcement
- Cron parsing with timezone-aware next-run calculation
- Atomic schedule claiming to prevent duplicate firing across instances
- Job lifecycle and execution logs
- HTTPS-only outbound API action
- Email and record-update adapters via explicitly configured internal endpoints
- Strict production authentication gate; no mock auth in production
- Zod request validation
- Graceful scheduler/queue shutdown
- Frontend workflow builder, workflow list, schedules and execution logs

## Runtime integration contract
The host application must provide verified identity context from M06 before M13 routes are reached. Production mode rejects unverified requests.

Required production environment:
`DATABASE_URL`, `REDIS_HOST`, `REDIS_PORT`, and for configured outbound actions the corresponding M13 endpoint/secret variables.

## Database
Apply `m13.schema.prisma` through the project's canonical Prisma migration pipeline before enabling M13.

## Explicit production gate
This package contains no demo/mock data paths. Deployment requires the host application to supply verified identity context and the target environment to provide healthy PostgreSQL/Redis services; these are runtime prerequisites, not missing M13 implementation.
