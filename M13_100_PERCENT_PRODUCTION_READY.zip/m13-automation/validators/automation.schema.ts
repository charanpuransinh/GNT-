import { z } from 'zod';

const triggerSchema = z.object({
  type: z.enum(['EVENT','SCHEDULE','MANUAL','WEBHOOK']),
  config: z.record(z.string(), z.unknown()).default({}),
  isActive: z.boolean().optional()
});

const actionSchema = z.object({
  type: z.enum(['SEND_EMAIL','UPDATE_RECORD','CALL_API','DELAY']),
  config: z.record(z.string(), z.unknown()).default({}),
  orderIndex: z.number().int().nonnegative().optional(),
  isActive: z.boolean().optional()
});

export const createWorkflowSchema = z.object({
  name: z.string().trim().min(1).max(200),
  description: z.string().trim().max(2000).optional().nullable(),
  isActive: z.boolean().optional(),
  triggers: z.array(triggerSchema).max(50).optional(),
  actions: z.array(actionSchema).max(100).optional()
});

export const updateWorkflowSchema = createWorkflowSchema.partial();
export const triggerWorkflowSchema = z.object({ payload: z.record(z.string(), z.unknown()).default({}) });
export const createScheduleSchema = z.object({ workflowId:z.string().uuid(), cronExpr:z.string().trim().min(9).max(120), timezone:z.string().trim().min(1).max(100).default('UTC') });
export const updateScheduleSchema = createScheduleSchema.omit({workflowId:true}).partial().extend({isActive:z.boolean().optional()});
