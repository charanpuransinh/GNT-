import { Request, Response } from 'express';
import { schedulerService } from '../services/scheduler.service';
import { createScheduleSchema, updateScheduleSchema } from '../validators/automation.schema';
import { requireTenant } from '../middleware/m13.middleware';
export class ScheduleController{
 async createSchedule(req:Request,res:Response):Promise<void>{const p=createScheduleSchema.safeParse(req.body);if(!p.success){res.status(400).json({success:false,error:'VALIDATION_ERROR',details:p.error.issues});return;}try{const id=await schedulerService.createSchedule(p.data.workflowId,p.data.cronExpr,p.data.timezone,requireTenant(req));res.status(201).json({success:true,data:{scheduleId:id}});}catch(e){res.status(400).json({success:false,error:e instanceof Error?e.message:'SCHEDULE_CREATE_FAILED'});}}
 async listSchedules(req:Request,res:Response):Promise<void>{res.json({success:true,data:await schedulerService.listSchedules(requireTenant(req))});}
 async updateSchedule(req:Request,res:Response):Promise<void>{const p=updateScheduleSchema.safeParse(req.body);if(!p.success){res.status(400).json({success:false,error:'VALIDATION_ERROR',details:p.error.issues});return;}try{await schedulerService.updateSchedule(req.params.id,p.data,requireTenant(req));res.json({success:true,message:'Schedule updated'});}catch(e){res.status(400).json({success:false,error:e instanceof Error?e.message:'SCHEDULE_UPDATE_FAILED'});}}
 async deleteSchedule(req:Request,res:Response):Promise<void>{try{await schedulerService.deleteSchedule(req.params.id,requireTenant(req));res.status(204).send();}catch{res.status(404).json({success:false,error:'SCHEDULE_NOT_FOUND'});}}
}
export const scheduleController=new ScheduleController();
