import { Request, Response } from 'express';
import { prisma } from '../db';
import { workflowEngineService } from '../services/workflow-engine.service';
import { triggerEvaluatorService } from '../services/trigger-evaluator.service';
import { createWorkflowSchema, updateWorkflowSchema, triggerWorkflowSchema } from '../validators/automation.schema';
import { requireTenant } from '../middleware/m13.middleware';

export class WorkflowController {
  async createWorkflow(req:Request,res:Response):Promise<void>{
    const parsed=createWorkflowSchema.safeParse(req.body); if(!parsed.success){res.status(400).json({success:false,error:'VALIDATION_ERROR',details:parsed.error.issues});return;}
    const d=parsed.data; const tenantId=requireTenant(req); const workflow=await prisma.m13Workflow.create({data:{tenantId,name:d.name,description:d.description??null,isActive:d.isActive??true,triggers:d.triggers?{create:d.triggers}:undefined,actions:d.actions?{create:d.actions.map((a,i)=>({...a,orderIndex:a.orderIndex??i}))}:undefined},include:{triggers:true,actions:true}});
    res.status(201).json({success:true,data:workflow});
  }
  async listWorkflows(req:Request,res:Response):Promise<void>{const rows=await prisma.m13Workflow.findMany({where:{tenantId:requireTenant(req)},include:{triggers:true,actions:true},orderBy:{createdAt:'desc'}});res.json({success:true,data:rows});}
  async getWorkflow(req:Request,res:Response):Promise<void>{const row=await prisma.m13Workflow.findFirst({where:{id:req.params.id,tenantId:requireTenant(req)},include:{triggers:true,actions:true,jobs:{orderBy:{createdAt:'desc'},take:20}}});if(!row){res.status(404).json({success:false,error:'WORKFLOW_NOT_FOUND'});return;}res.json({success:true,data:row});}
  async updateWorkflow(req:Request,res:Response):Promise<void>{const parsed=updateWorkflowSchema.safeParse(req.body);if(!parsed.success){res.status(400).json({success:false,error:'VALIDATION_ERROR',details:parsed.error.issues});return;}const d=parsed.data;try{const row=await prisma.m13Workflow.updateMany({where:{id:req.params.id,tenantId:requireTenant(req)},data:{name:d.name,description:d.description,isActive:d.isActive}});res.json({success:true,data:row});}catch{res.status(404).json({success:false,error:'WORKFLOW_NOT_FOUND'});}}
  async deleteWorkflow(req:Request,res:Response):Promise<void>{try{await prisma.m13Workflow.deleteMany({where:{id:req.params.id,tenantId:requireTenant(req)}});res.status(204).send();}catch{res.status(404).json({success:false,error:'WORKFLOW_NOT_FOUND'});}}
  async manualTrigger(req:Request,res:Response):Promise<void>{const parsed=triggerWorkflowSchema.safeParse(req.body||{});if(!parsed.success){res.status(400).json({success:false,error:'VALIDATION_ERROR',details:parsed.error.issues});return;}const can=await triggerEvaluatorService.evaluateManualTrigger(req.params.id,requireTenant(req));if(!can){res.status(409).json({success:false,error:'MANUAL_TRIGGER_NOT_ALLOWED'});return;}try{const jobId=await workflowEngineService.triggerWorkflow(req.params.id,parsed.data.payload,requireTenant(req));res.status(202).json({success:true,data:{jobId},message:'Workflow queued'});}catch(error){res.status(404).json({success:false,error:error instanceof Error?error.message:'TRIGGER_FAILED'});}}
}
export const workflowController=new WorkflowController();
