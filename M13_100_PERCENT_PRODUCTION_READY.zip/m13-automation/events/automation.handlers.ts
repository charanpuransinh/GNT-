import { M13EventPayload } from '../types/m13.types';
export type M13EventHandler=(event:M13EventPayload)=>Promise<void>;
export const automationHandlers:Record<string,M13EventHandler>={};
export function registerAutomationHandler(eventName:string,handler:M13EventHandler):void{automationHandlers[eventName]=handler;}
