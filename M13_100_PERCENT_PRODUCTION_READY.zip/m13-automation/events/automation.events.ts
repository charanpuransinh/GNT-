export const M13_AUTOMATION_EVENTS={WORKFLOW_TRIGGERED:'m13:workflow:triggered',JOB_COMPLETED:'m13:job:completed',JOB_FAILED:'m13:job:failed',SCHEDULE_FIRED:'m13:schedule:fired'} as const;
export type M13AutomationEvent=typeof M13_AUTOMATION_EVENTS[keyof typeof M13_AUTOMATION_EVENTS];
