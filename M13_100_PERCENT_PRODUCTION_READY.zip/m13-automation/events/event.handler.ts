import { M13EventPayload } from '../types/m13.types';
import { triggerEvaluatorService } from '../services/trigger-evaluator.service';
import { workflowEngineService } from '../services/workflow-engine.service';
export type M13EventSubscriber=(handler:(event:M13EventPayload)=>Promise<void>)=>()=>void;
export class EventHandler{
 private unsubscribe:()=>void=()=>{};
 async handleIncomingEvent(event:M13EventPayload):Promise<void>{for(const workflowId of await triggerEvaluatorService.evaluateEventTrigger(event)) await workflowEngineService.triggerWorkflow(workflowId,event.data);}
 subscribeToEvents(subscriber?:M13EventSubscriber):void{if(!subscriber)return; this.unsubscribe=subscriber(event=>this.handleIncomingEvent(event));}
 unsubscribeFromEvents():void{this.unsubscribe();this.unsubscribe=()=>{};}
}
export const eventHandler=new EventHandler();
