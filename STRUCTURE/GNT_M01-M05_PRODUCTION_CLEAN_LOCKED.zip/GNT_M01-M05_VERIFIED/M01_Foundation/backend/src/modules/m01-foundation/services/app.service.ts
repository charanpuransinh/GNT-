import * as os from 'os';
import { appRepository } from '../repositories/app.repository';
import { appInternal } from './app.internal';
import { eventBus } from '@/common/events/event-bus';
import { AppConfig, HealthStatus, SystemInfo } from '../types/app.types';
import { logger } from '@/common/logging/logger';

let lastHealthStatus: HealthStatus['status'] | undefined;

export const appService = {
  async getAppConfig(): Promise<Partial<AppConfig>> {
    const rawConfig = await appRepository.getConfig();
    const enriched = appInternal.validateAndEnrichConfig(rawConfig);
    return appInternal.sanitizeConfigForClient(enriched);
  },

  async getHealthStatus(): Promise<HealthStatus> {
    const [dbHealth, cacheHealth, storageHealth] = await Promise.all([
      appRepository.checkDatabaseConnection(),
      appRepository.checkCacheConnection(),
      appRepository.checkStorageConnection(),
    ]);

    const allHealthy = dbHealth && cacheHealth && storageHealth;
    // Database is the only hard dependency — if it's down the system is down;
    // if only cache/storage are down, the system degrades but keeps serving.
    const status: HealthStatus['status'] = allHealthy ? 'healthy' : !dbHealth ? 'down' : 'degraded';

    if (status === 'degraded' && lastHealthStatus !== 'degraded') {
      eventBus.publish('system.health.degraded', {
        check: !dbHealth ? 'database' : !cacheHealth ? 'cache' : 'storage',
        status,
        timestamp: new Date(),
      });
      logger.warn('Health check reported degraded status', { status, dbHealth, cacheHealth, storageHealth });
    }
    if (status === 'healthy' && lastHealthStatus && lastHealthStatus !== 'healthy') {
      eventBus.publish('system.health.restored', { status, timestamp: new Date() });
    }
    lastHealthStatus = status;

    return {
      status,
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      version: process.env.APP_VERSION || '1.0.0',
      checks: {
        database: dbHealth,
        cache: cacheHealth,
        storage: storageHealth,
      },
    };
  },

  async getSystemInfo(): Promise<SystemInfo> {
    const memUsage = process.memoryUsage();
    const totalMem = os.totalmem();

    return {
      platform: process.platform,
      nodeVersion: process.version,
      memoryUsage: {
        used: Math.round(memUsage.heapUsed / 1024 / 1024),
        total: Math.round(totalMem / 1024 / 1024),
        percentage: Math.round((memUsage.heapUsed / totalMem) * 100),
      },
      cpuLoad: Math.round(os.loadavg()[0] * 100) / 100, // 1-minute load average
      activeConnections: await appRepository.getActiveConnectionCount(),
    };
  },

  async checkMaintenanceMode(): Promise<{ maintenanceMode: boolean; message?: string }> {
    const config = await appRepository.getConfig();
    return {
      maintenanceMode: config.maintenanceMode || false,
      message: config.maintenanceMode
        ? 'System is under scheduled maintenance. Please try again later.'
        : undefined,
    };
  },
};
