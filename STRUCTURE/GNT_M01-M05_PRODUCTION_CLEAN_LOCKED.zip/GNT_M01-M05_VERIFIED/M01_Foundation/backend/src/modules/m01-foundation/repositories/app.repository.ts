import { prisma } from '@/common/config/env-config';
import { redis } from '@/common/config/cache-config';
import { storageClient } from '@/common/config/storage-config';
import { AppConfig } from '../types/app.types';
import { logger } from '@/common/logging/logger';

export const appRepository = {
  async getConfig(): Promise<Partial<AppConfig>> {
    // M01 does not own DB tables — reads from environment or shared config store
    // In production, this would read from a centralized config service
    return {
      appName: process.env.APP_NAME,
      version: process.env.APP_VERSION,
      environment: process.env.NODE_ENV as AppConfig['environment'],
      features: JSON.parse(process.env.FEATURE_FLAGS || '{}'),
      maintenanceMode: process.env.MAINTENANCE_MODE === 'true',
      companyName: process.env.COMPANY_NAME,
      branding: process.env.BRANDING_LOGO
        ? {
            logoUrl: process.env.BRANDING_LOGO,
            primaryColor: process.env.BRANDING_COLOR,
          }
        : undefined,
    };
  },

  async checkDatabaseConnection(): Promise<boolean> {
    try {
      await prisma.$queryRaw`SELECT 1`;
      return true;
    } catch (error) {
      logger.error('Database health check failed', { error });
      return false;
    }
  },

  async checkCacheConnection(): Promise<boolean> {
    try {
      if (redis) {
        await redis.ping();
        return true;
      }
      return false;
    } catch (error) {
      logger.error('Cache health check failed', { error });
      return false;
    }
  },

  async checkStorageConnection(): Promise<boolean> {
    try {
      if (!storageClient) return false;
      await storageClient.ping();
      return true;
    } catch (error) {
      logger.error('Storage health check failed', { error });
      return false;
    }
  },

  async getActiveConnectionCount(): Promise<number> {
    try {
      // Live socket/session count is tracked in Redis by the connection
      // gateway (incremented on connect, decremented on disconnect).
      if (!redis) return 0;
      const count = await redis.get('system:active_connections');
      return count ? parseInt(count, 10) : 0;
    } catch (error) {
      logger.error('Failed to read active connection count', { error });
      return 0;
    }
  },
};
