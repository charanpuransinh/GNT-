# M01–M05 HOST DEPENDENCY CONTRACT

This ZIP is a module package, not the complete host application. The following shared/runtime contracts are required by the locked modules. No business logic is hidden here.

## Backend shared exports required
- `@/common/config/env-config` → `prisma`
- `@/common/config/cache-config` → `redis`
- `@/common/config/storage-config` → `storageClient` with `ping()`
- `@/common/config/internal-api-client` → `internalApiClient` with `get/post/put`
- `@/common/events/event-bus` → `EventBus`, shared `eventBus`, `publish`, `subscribe`
- `@/common/logging/logger` → `logger`
- `@/common/logging/audit-logger` → `AuditLogger`, `auditLogger`
- `@/common/errors/error-classes` → `AppError`
- `@/common/middleware/auth-middleware`
- `@/common/middleware/tenant-middleware`
- `@/common/middleware/request-tracer`
- `@/common/middleware/validation-middleware`

## Frontend host exports required
- `@/core/api-client`
- `@/components/ui/*`
- `@/components/layout/*`
- `@/components/feedback/*`
- `@/hooks/useOffline`

## External API dependencies
- M04 → M02 public auth/user/role contract
- M05 → M10 public ledger contract
- M03 → M02 auth context and M04 company context

## Database dependency order
1. M04 company/branch/FY tables
2. M02 user/role/permission tables (depend on M04 company/branch)
3. M03 device/session/deployment/release tables
4. M05 party/ledger-view tables

The M02 and M03 schemas intentionally reference canonical entities owned by earlier modules; migration orchestration must therefore respect dependency order rather than numeric module order.
