import { internalApiClient } from '@/common/config/internal-api-client';

// Calls M10's public ledger.service contract (see M05_LOCK_PACKAGE.md:
// "M05 -> M10 ledger.service PUBLIC"). party_ledger_view is M05-owned but
// populated from M10's data via this contract — M05 must never read
// M10's own accounting tables directly.
export class M10Client {
  async getLedgerEntries(partyId: string, companyId: string): Promise<any[]> {
    const response = await internalApiClient.get(`/api/v1/m10/ledger/party/${partyId}`, {
      params: { companyId },
    });
    return response?.data || [];
  }
}
