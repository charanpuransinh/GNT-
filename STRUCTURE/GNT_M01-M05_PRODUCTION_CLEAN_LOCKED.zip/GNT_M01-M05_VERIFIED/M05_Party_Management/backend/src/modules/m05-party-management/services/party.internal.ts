import { M10Client } from "../clients/m10.client";

export class PartyInternal {
  constructor(private readonly m10Client: M10Client = new M10Client()) {}

  async validateGSTIN(gstin: string): Promise<boolean> {
    const regex = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/;
    return regex.test(gstin);
  }

  async calculateAging(partyId: string, companyId: string, repo: PartyRepository) {
    const invoices = await repo.findInvoicesForAging(partyId, companyId);
    const aging = { partyId, d0_30: 0, d31_60: 0, d61_90: 0, d90_plus: 0, total: 0 };
    const now = new Date();
    for (const inv of invoices) {
      const days = Math.max(0, Math.floor((now.getTime() - new Date(inv.dueDate).getTime()) / (1000 * 60 * 60 * 24)));
      const amt = inv.balance || 0;
      if (days <= 30) aging.d0_30 += amt;
      else if (days <= 60) aging.d31_60 += amt;
      else if (days <= 90) aging.d61_90 += amt;
      else aging.d90_plus += amt;
      aging.total += amt;
    }
    return aging;
  }

  async fetchLedgerFromAccounting(partyId: string, companyId: string): Promise<any[]> {
    // Calls M10 ledger.service PUBLIC method via the contract client —
    // was previously a stub always returning an empty array.
    return this.m10Client.getLedgerEntries(partyId, companyId);
  }
}