import { EventBus } from "../../../common/events/event-bus";
import { AuditLogger } from "../../../common/logging/audit-logger";
export class PartyEventHandlers {
  constructor(private readonly eventBus: EventBus, private readonly audit: AuditLogger) {}
  register() {
    this.eventBus.subscribe("party.created", (p) => this.audit.log({ action: "AUDIT_PARTY_CREATED", target: p.partyId }));
    this.eventBus.subscribe("party.updated", (p) => this.audit.log({ action: "AUDIT_PARTY_UPDATED", target: p.partyId }));
    this.eventBus.subscribe("party.deleted", (p) => this.audit.log({ action: "AUDIT_PARTY_DELETED", target: p.partyId }));
    this.eventBus.subscribe("party.outstanding.changed", (p) => this.audit.log({ action: "AUDIT_OUTSTANDING_CHANGED", target: p.partyId, meta: p }));
  }
}
