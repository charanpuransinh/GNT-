import { Request, Response, NextFunction } from "express";
import { PartyService } from "../services/party.service";
export class PartyController {
  constructor(private readonly svc: PartyService) {}
  async list(req: Request, res: Response, next: NextFunction) {
    try { const data = await this.svc.list(req.context.companyId, req.query); res.json({ success: true, data, meta: { requestId: req.context.requestId } }); }
    catch(err){ next(err); }
  }
  async get(req: Request, res: Response, next: NextFunction) {
    try { const data = await this.svc.get(req.params.id, req.context.companyId); res.json({ success: true, data }); }
    catch(err){ next(err); }
  }
  async create(req: Request, res: Response, next: NextFunction) {
    try { const data = await this.svc.create(req.context.companyId, req.body); res.status(201).json({ success: true, data }); }
    catch(err){ next(err); }
  }
  async update(req: Request, res: Response, next: NextFunction) {
    try { const data = await this.svc.update(req.params.id, req.context.companyId, req.body); res.json({ success: true, data }); }
    catch(err){ next(err); }
  }
  async remove(req: Request, res: Response, next: NextFunction) {
    try { await this.svc.delete(req.params.id, req.context.companyId); res.json({ success: true, message: "Deleted" }); }
    catch(err){ next(err); }
  }
  async aging(req: Request, res: Response, next: NextFunction) {
    try { const data = await this.svc.getAging(req.params.id, req.context.companyId); res.json({ success: true, data }); }
    catch(err){ next(err); }
  }
  async creditLimit(req: Request, res: Response, next: NextFunction) {
    try { const data = await this.svc.checkCreditLimit(req.params.id, req.context.companyId); res.json({ success: true, data }); }
    catch(err){ next(err); }
  }
  async ledger(req: Request, res: Response, next: NextFunction) {
    try { const data = await this.svc.getLedger(req.params.id, req.context.companyId); res.json({ success: true, data }); }
    catch(err){ next(err); }
  }
}