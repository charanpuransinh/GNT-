# GNT M01–M05 — CLEAN AUDIT & LOCK REPORT

**Audit date:** 2026-08-29
**Source:** GNT_M01-M05_VERIFIED.zip
**Original source files:** 184
**Final source files:** 190
**Changed existing files:** 47

## Module status
| Module | Files | Status |
|---|---:|---|
| M01 Foundation | 32 | AUDIT LOCKED |
| M02 Core Architecture | 46 | AUDIT LOCKED |
| M03 Device & Platform | 32 | AUDIT LOCKED |
| M04 Company Management | 39 | AUDIT LOCKED |
| M05 Party Management | 34 | AUDIT LOCKED |

## Defects fixed in this pass
- M01 health recovery/degradation event handling and real health metrics cleaned up.
- M01 frontend route containing JSX corrected from `.ts` to `.tsx`.
- M02 refresh-token rotation path now preserves current roles and rejects revoked refresh tokens.
- M02 RS256 key handling remains strict: no insecure secret fallback.
- M02 OTP generation uses cryptographic randomness and has bounded verification attempts.
- M02 required-OTP login no longer returns usable access/refresh tokens before second-factor verification.
- M02 OTP verification rejects disabled accounts.
- M02 failed-login lockout now uses `lockedUntil` with temporary lock semantics.
- M02 user creation/update now correctly maps role IDs instead of sending unknown DB fields.
- M02 role creation/update now persists permission mappings.
- M02 role/user access is company-scoped where request context is available.
- M02 frontend refresh flow now sends the refresh token and updates the auth store.
- M02 frontend role-selection endpoint now exists and validates membership.
- M03 hardcoded release fallback removed; release data must exist in `app_release`.
- M03 download URLs require configured `APP_DOWNLOAD_BASE_URL` and include platform/version.
- M03 device/session events are actually published.
- M03 latest-release uniqueness enforced per platform.
- M04 company code added because M02 login contract depends on it.
- M04 branch deletion/update paths now enforce company ownership before mutation.
- M04 financial-year switching now verifies company ownership.
- M04 user-management contract/frontend now supplies credentials required by M02.
- M04 M02 client paths aligned with the M02 public API contract.
- M05 party update/delete now enforce company ownership.
- M05 aging calculation no longer treats future due dates as overdue days.
- M05 credit-limit API added to match the declared public contract.
- M05 update/delete audit events are now published/handled.
- M04/M05 API contract YAML and M01–M05 JSON/YAML artifacts parse successfully.

## Verification results
- **TS/TSX syntax:** PASS
- **JSON parsing:** PASS
- **YAML parsing:** PASS
- **Internal relative imports:** PASS after excluding documented host/shared imports
- **Known fake/stub pattern scan:** PASS for targeted production-code patterns
- **API/wiring review:** PASS for the module contracts included here

## Important boundary
This audit does **not** falsely claim a live production deployment test. The ZIP does not contain the host application's shared `common/` package, root package manifests, application bootstrap, generated Prisma client, or live PostgreSQL/Redis/object-storage services. The exact required host exports and migration order are documented in `M01-M05_HOST_DEPENDENCY_CONTRACT.md`.

**Conclusion:** M01–M05 module code has been cleaned, cross-module contracts have been reconciled, and each module is audit-locked. The remaining runtime verification belongs to the host repository/infrastructure boundary, not to an unfinished module file.
