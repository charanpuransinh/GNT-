import { CompanyRepository } from "../repositories/company.repository";
import { BranchRepository } from "../repositories/branch.repository";
import { CompanyInternal } from "./company.internal";
import { M02Client } from "../clients/m02.client";
import { EventBus } from "../../../common/events/event-bus";
import { AuditLogger } from "../../../common/logging/audit-logger";
import { AppError } from "../../../common/errors/error-classes";

export class CompanyService {
  constructor(
    private readonly companyRepo: CompanyRepository,
    private readonly branchRepo: BranchRepository,
    private readonly internal: CompanyInternal,
    private readonly eventBus: EventBus,
    private readonly audit: AuditLogger,
    private readonly m02Client: M02Client,
  ) {}

  async getProfile(companyId: string) { return this.companyRepo.findById(companyId); }

  async updateProfile(companyId: string, data: any) {
    const updated = await this.companyRepo.update(companyId, data);
    this.eventBus.publish("company.profile.updated", { companyId, timestamp: new Date() });
    this.audit.log({ action: "COMPANY_PROFILE_UPDATE", target: companyId });
    return updated;
  }

  async getFinancialYears(companyId: string) { return this.companyRepo.findFinancialYears(companyId); }

  async createFinancialYear(companyId: string, data: any) {
    const fy = await this.companyRepo.createFY({ ...data, companyId });
    this.audit.log({ action: "FY_CREATED", target: fy.id });
    return fy;
  }

  async switchFinancialYear(fyId: string, companyId: string) {
    const fy = await this.companyRepo.findFYByIdForCompany(fyId, companyId);
    if (!fy) throw new AppError("GNT-ERR-0403", "Financial year not found", 404);
    await this.companyRepo.deactivateAllFY(companyId);
    await this.companyRepo.activateFY(fyId);
    this.eventBus.publish("company.fy.switched", { companyId, fyId, timestamp: new Date() });
    this.audit.log({ action: "FY_SWITCHED", target: fyId });
  }

  async getRoles(companyId: string) { return this.m02Client.findRolesByCompany(companyId); }

  async updateRolePermissions(roleId: string, companyId: string, permissions: string[]) {
    const role = await this.m02Client.findRoleById(roleId);
    if (!role || role.companyId !== companyId) throw new AppError("GNT-ERR-0401", "Role not found", 404);
    await this.m02Client.updateRolePermissions(roleId, permissions);
    this.audit.log({ action: "ROLE_PERMISSIONS_UPDATED", target: roleId });
  }

  async getUsers(companyId: string) { return this.m02Client.findUsersByCompany(companyId); }

  async createUser(companyId: string, data: any) {
    const user = await this.m02Client.createUser({ ...data, companyId });
    this.eventBus.publish("company.user.created", { userId: user.id, companyId });
    this.audit.log({ action: "USER_CREATED", target: user.id });
    return user;
  }

  async toggleUserStatus(userId: string, companyId: string) {
    const user = await this.m02Client.findUserById(userId);
    if (!user || user.companyId !== companyId) throw new AppError("GNT-ERR-0402", "User not found", 404);
    await this.m02Client.toggleUserStatus(userId, !user.isActive);
    this.audit.log({ action: "USER_STATUS_TOGGLED", target: userId });
  }
}