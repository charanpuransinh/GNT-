import { internalApiClient } from '@/common/config/internal-api-client';

// Calls M02's public HTTP contract (see M02-core.contract.yaml) for every
// user/role operation M04 needs. This replaces the direct user_master /
// role_master Prisma access that used to live in company.repository.ts —
// M04 does not own those tables and must never write to them directly
// (see M04-wiring-map.json: "forbidden": ["M04 -> any module DB directly"]).
export class M02Client {
  async findUsersByCompany(companyId: string) {
    const r = await internalApiClient.get(`/api/v1/m02/auth/users`, { params: { companyId } }); return r?.data ?? r;
  }

  async findUserById(id: string) {
    const r = await internalApiClient.get(`/api/v1/m02/auth/users/${id}`); return r?.data ?? r;
  }

  async createUser(data: any) {
    const payload = data.roleId ? { ...data, roleIds: [data.roleId] } : data; delete payload.roleId; const r = await internalApiClient.post(`/api/v1/m02/auth/users`, payload); return r?.data ?? r;
  }

  async toggleUserStatus(id: string, isActive: boolean) {
    const r = await internalApiClient.put(`/api/v1/m02/auth/users/${id}`, { isActive }); return r?.data ?? r;
  }

  async findRolesByCompany(companyId: string) {
    const r = await internalApiClient.get(`/api/v1/m02/auth/roles`, { params: { companyId } }); return r?.data ?? r;
  }

  async findRoleById(id: string) {
    const r = await internalApiClient.get(`/api/v1/m02/auth/roles/${id}`); return r?.data ?? r;
  }

  async updateRolePermissions(roleId: string, permissions: string[]) {
    const r = await internalApiClient.put(`/api/v1/m02/auth/roles/${roleId}`, { permissionIds: permissions }); return r?.data ?? r;
  }
}
