import { BranchRepository } from "../repositories/branch.repository";
import { EventBus } from "../../../common/events/event-bus";
import { AuditLogger } from "../../../common/logging/audit-logger";
import { AppError } from "../../../common/errors/error-classes";

export class BranchService {
  constructor(
    private readonly branchRepo: BranchRepository,
    private readonly eventBus: EventBus,
    private readonly audit: AuditLogger,
  ) {}

  async getBranches(companyId: string) { return this.branchRepo.findByCompany(companyId); }

  async createBranch(companyId: string, data: any) {
    const code = await this.generateBranchCode(companyId);
    const branch = await this.branchRepo.create({ ...data, companyId, code, isActive: true });
    this.eventBus.publish("company.branch.created", { branchId: branch.id, companyId });
    this.audit.log({ action: "BRANCH_CREATED", target: branch.id });
    return branch;
  }

  async deleteBranch(branchId: string, companyId: string) {
    const deleted = await this.branchRepo.softDelete(branchId, companyId);
    if (!deleted) throw new AppError("GNT-ERR-0404", "Branch not found", 404);
    this.eventBus.publish("company.branch.deleted", { branchId, companyId });
    this.audit.log({ action: "BRANCH_DELETED", target: branchId });
  }

  private async generateBranchCode(companyId: string) {
    const count = await this.branchRepo.countByCompany(companyId);
    return `BR-${String(count + 1).padStart(3, "0")}`;
  }
}