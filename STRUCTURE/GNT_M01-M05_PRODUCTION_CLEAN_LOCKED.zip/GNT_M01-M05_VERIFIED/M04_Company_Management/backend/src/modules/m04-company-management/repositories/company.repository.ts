import { PrismaClient } from "@prisma/client";
export class CompanyRepository {
  constructor(private readonly prisma: PrismaClient) {}
  async findById(id: string) { return this.prisma.company_master.findUnique({ where: { id } }); }
  async update(id: string, data: any) { return this.prisma.company_master.update({ where: { id }, data: { ...data, updatedAt: new Date() } }); }
  async findFinancialYears(companyId: string) { return this.prisma.financial_year.findMany({ where: { companyId }, orderBy: { startDate: "desc" } }); }
  async findFYByIdForCompany(id: string, companyId: string) { return this.prisma.financial_year.findFirst({ where: { id, companyId } }); }
  async createFY(data: any) { return this.prisma.financial_year.create({ data }); }
  async deactivateAllFY(companyId: string) { return this.prisma.financial_year.updateMany({ where: { companyId }, data: { isActive: false } }); }
  async activateFY(id: string) { return this.prisma.financial_year.update({ where: { id }, data: { isActive: true } }); }
}
