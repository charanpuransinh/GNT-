import { z } from "zod";
export const companyProfileSchema = z.object({
  name: z.string().min(1).max(200),
  code: z.string().min(2).max(20).regex(/^[A-Z0-9_-]+$/).optional(),
  gstin: z.string().regex(/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/, "Invalid GSTIN").optional().or(z.literal("")),
  address: z.string().max(500).optional(),
  phone: z.string().max(20).optional(),
  email: z.string().email().optional().or(z.literal("")),
});
export const branchCreateSchema = z.object({ name: z.string().min(1).max(100), address: z.string().optional() });
export const financialYearSchema = z.object({
  startDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/), endDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/), prefix: z.string().max(10),
}).refine(v => v.endDate > v.startDate, { message: "endDate must be after startDate", path: ["endDate"] });
export const rolePermissionsSchema = z.object({ permissions: z.array(z.string().uuid()) });
export const userCreateSchema = z.object({ name: z.string().min(2).max(100), email: z.string().email(), username: z.string().min(3).max(50), password: z.string().min(8).max(100), branchId: z.string().uuid().optional(), roleId: z.string().uuid(), });
