import { deviceRepository } from '../repositories/device.repository';
import { logger } from '@/common/logging/logger';
import { DeploymentSettings } from '../types/device.types';

export const deviceInternal = {
  async getLatestVersion(platform: string): Promise<string> {
    const release = await deviceRepository.getLatestRelease(platform);
    if (!release) throw new Error(`No published release configured for platform: ${platform}`);
    return release.version;
  },

  compareVersions(v1: string, v2: string): number {
    const parts1 = v1.split('.').map(Number);
    const parts2 = v2.split('.').map(Number);

    for (let i = 0; i < Math.max(parts1.length, parts2.length); i++) {
      const a = parts1[i] || 0;
      const b = parts2[i] || 0;
      if (a < b) return -1;
      if (a > b) return 1;
    }
    return 0;
  },

  async getUpdateSeverity(platform: string, current: string, latest: string): Promise<'critical' | 'major' | 'minor' | 'patch'> {
    // Prefer the severity the release was actually published with, if on record.
    const release = await deviceRepository.getReleaseByVersion(platform, latest);
    if (release?.severity) return release.severity as 'critical' | 'major' | 'minor' | 'patch';

    const currentParts = current.split('.').map(Number);
    const latestParts = latest.split('.').map(Number);

    if (latestParts[0] > currentParts[0]) return 'critical';
    if (latestParts[1] > currentParts[1]) return 'major';
    if (latestParts[2] > currentParts[2] + 5) return 'minor';
    return 'patch';
  },

  async getReleaseNotes(platform: string, version: string): Promise<string[]> {
    const release = await deviceRepository.getReleaseByVersion(platform, version);
    if (!release) throw new Error(`Release ${version} not found for platform: ${platform}`);
    return release.releaseNotes || [];
  },

  generateDownloadUrl(platform: string, version: string): string {
    const baseUrl = process.env.APP_DOWNLOAD_BASE_URL;
    if (!baseUrl) throw new Error('APP_DOWNLOAD_BASE_URL is not configured');
    return `${baseUrl.replace(/\/$/, '')}/releases/${encodeURIComponent(platform)}/${encodeURIComponent(version)}`;
  },

  getDefaultSettings(): DeploymentSettings {
    return {
      autoUpdate: false,
      updateNotifications: true,
      sessionTimeout: 30,
      forceSingleSession: false,
      offlineSync: true,
      syncInterval: 15,
    };
  },

  generateSessionExpiry(timeoutMinutes: number): Date {
    return new Date(Date.now() + timeoutMinutes * 60 * 1000);
  },
};
