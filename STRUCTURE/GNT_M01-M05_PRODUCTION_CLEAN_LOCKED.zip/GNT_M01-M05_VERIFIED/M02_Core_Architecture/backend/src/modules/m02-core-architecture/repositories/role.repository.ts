import { prisma } from '@/common/config/env-config';

export const roleRepository = {
  async findById(id: string) { return prisma.role_master.findUnique({ where: { id }, include: { role_permission: { include: { permission_master: true } } } }); },
  async findByCompanyId(companyId: string) { return prisma.role_master.findMany({ where: { companyId }, include: { role_permission: { include: { permission_master: true } } } }); },
  async getRolesByUserId(userId: string) { const rows = await prisma.user_role.findMany({ where: { userId }, include: { role_master: true } }); return rows.map((r: any) => r.role_master); },
  async getPermissionsByUserId(userId: string): Promise<string[]> {
    const rows = await prisma.user_role.findMany({ where: { userId }, include: { role_master: { include: { role_permission: { include: { permission_master: true } } } } } });
    const permissions = new Set<string>();
    rows.forEach((r: any) => r.role_master.role_permission.forEach((rp: any) => permissions.add(`${rp.permission_master.module}:${rp.permission_master.action}`)));
    return [...permissions];
  },
  async create(data: any) {
    const { permissionIds = [], ...roleData } = data;
    return prisma.role_master.create({ data: { ...roleData, role_permission: { create: permissionIds.map((permissionId: string) => ({ permission_master: { connect: { id: permissionId } } })) } } });
  },
  async update(id: string, data: any) {
    const { permissionIds, ...roleData } = data;
    if (permissionIds === undefined) return prisma.role_master.update({ where: { id }, data: roleData });
    return prisma.$transaction(async (tx: any) => {
      const updated = await tx.role_master.update({ where: { id }, data: roleData });
      await tx.role_permission.deleteMany({ where: { roleId: id } });
      if (permissionIds.length) await tx.role_permission.createMany({ data: permissionIds.map((permissionId: string) => ({ roleId: id, permissionId })) });
      return updated;
    });
  },
  async delete(id: string) { return prisma.role_master.delete({ where: { id } }); },
  async getUserCountForRole(roleId: string) { return prisma.user_role.count({ where: { roleId } }); },
};
