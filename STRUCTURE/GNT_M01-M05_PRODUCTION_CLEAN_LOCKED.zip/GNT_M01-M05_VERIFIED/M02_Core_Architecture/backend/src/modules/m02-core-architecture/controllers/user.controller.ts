import { Request, Response, NextFunction } from 'express';
import { userService } from '../services/user.service';
import { logger } from '@/common/logging/logger';
import { AppError } from '@/common/errors/error-classes';

const companyContext = (req: Request): string | undefined => {
  const userCompanyId = (req as any).user?.companyId;
  const requested = (req as any).company?.id || (req.query?.companyId as string | undefined);
  if (userCompanyId && requested && userCompanyId !== requested) throw new AppError('GNT-ERR-2013', 'Cross-company access denied', 403);
  return requested || userCompanyId;
};

export const userController = {
  async listUsers(req: Request, res: Response, next: NextFunction) {
    try {
      const companyId = companyContext(req);
      const users = await userService.listUsers(companyId);
      res.json({
        success: true,
        data: users,
        meta: {
          requestId: res.locals.requestId,
          timestamp: new Date().toISOString(),
        },
      });
    } catch (error) {
      next(error);
    }
  },

  async getUser(req: Request, res: Response, next: NextFunction) {
    try {
      const { id } = req.params;
      const user = await userService.getUserById(id, companyId);
      res.json({
        success: true,
        data: user,
        meta: {
          requestId: res.locals.requestId,
          timestamp: new Date().toISOString(),
        },
      });
    } catch (error) {
      next(error);
    }
  },

  async createUser(req: Request, res: Response, next: NextFunction) {
    try {
      const companyId = companyContext(req) || req.body.companyId;
      const user = await userService.createUser({ ...req.body, companyId });
      res.status(201).json({
        success: true,
        data: user,
        meta: {
          requestId: res.locals.requestId,
          timestamp: new Date().toISOString(),
        },
      });
    } catch (error) {
      next(error);
    }
  },

  async updateUser(req: Request, res: Response, next: NextFunction) {
    try {
      const { id } = req.params;
      const user = await userService.updateUser(id, req.body, companyId);
      res.json({
        success: true,
        data: user,
        meta: {
          requestId: res.locals.requestId,
          timestamp: new Date().toISOString(),
        },
      });
    } catch (error) {
      next(error);
    }
  },

  async deleteUser(req: Request, res: Response, next: NextFunction) {
    try {
      const { id } = req.params;
      await userService.deleteUser(id, companyId);
      res.json({
        success: true,
        data: { deleted: true },
        meta: {
          requestId: res.locals.requestId,
          timestamp: new Date().toISOString(),
        },
      });
    } catch (error) {
      next(error);
    }
  },

  async unlockAccount(req: Request, res: Response, next: NextFunction) {
    try {
      const { id } = req.params;
      const user = await userService.unlockAccount(id, companyId);
      res.json({
        success: true,
        data: user,
        meta: {
          requestId: res.locals.requestId,
          timestamp: new Date().toISOString(),
        },
      });
    } catch (error) {
      next(error);
    }
  },
};
