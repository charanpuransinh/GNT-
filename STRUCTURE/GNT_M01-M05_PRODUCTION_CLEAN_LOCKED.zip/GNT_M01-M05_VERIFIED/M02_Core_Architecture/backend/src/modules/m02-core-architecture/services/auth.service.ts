import { userRepository } from '../repositories/user.repository';
import { roleRepository } from '../repositories/role.repository';
import { authInternal } from './auth.internal';
import {
  LoginRequest,
  LoginResponse,
  OTPVerifyRequest,
  OTPVerifyResponse,
  UserProfile,
  TokenPair,
} from '../types/auth.types';
import { AppError } from '@/common/errors/error-classes';
import { logger } from '@/common/logging/logger';
import { eventBus } from '@/common/events/event-bus';

export const authService = {
  async login(data: LoginRequest): Promise<LoginResponse> {
    // 1. Find user by username + company code
    const user = await userRepository.findByUsernameAndCompany(
      data.username,
      data.companyCode
    );

    if (!user) {
      eventBus.publish('user.login.failed', { username: data.username, companyCode: data.companyCode });
      throw new AppError('GNT-ERR-2002', 'Invalid credentials', 401);
    }

    if (!user.isActive) {
      throw new AppError('GNT-ERR-2003', 'Account is disabled', 403);
    }

    // 2. Check lock status BEFORE verifying the password. Doing this check
    //    after a correct password (as before) meant the reset in step 4
    //    could never run once a user crossed 5 failed attempts — the
    //    account stayed locked forever, even with the right password.
    if (user.lockedUntil && new Date(user.lockedUntil) > new Date()) {
      throw new AppError('GNT-ERR-2004', 'Account temporarily locked due to too many failed attempts.', 403);
    }
    if (user.lockedUntil) await userRepository.resetFailedAttempts(user.id);

    // 3. Verify password
    const isValidPassword = await authInternal.verifyPassword(
      data.password,
      user.passwordHash
    );

    if (!isValidPassword) {
      const updated = await userRepository.incrementFailedAttempts(user.id);
      if (updated.failedLoginAttempts >= 5) {
        await userRepository.lockAccount(user.id, new Date(Date.now() + 15 * 60 * 1000));
      }
      eventBus.publish('user.login.failed', { userId: user.id, companyId: user.companyId });
      throw new AppError('GNT-ERR-2002', 'Invalid credentials', 401);
    }

    // 4. Correct password — always reachable now, so failed attempts reset properly.
    await userRepository.resetFailedAttempts(user.id);

    // 5. Get user roles and permissions
    if (!user.isActive) throw new AppError('GNT-ERR-2003', 'Account is disabled', 403);

    const roles = await roleRepository.getRolesByUserId(user.id);
    const permissions = await roleRepository.getPermissionsByUserId(user.id);

    // 6. Check if OTP is required before issuing any authenticated token.
    // Tokens must never be usable to bypass a required second factor.
    const requiresOtp = user.twoFactorEnabled || authInternal.isHighRiskLogin(user);
    if (requiresOtp) {
      await authInternal.sendOtp(user.id, user.email);
    }

    // 7. Update last login only after the primary credential check. Token
    // issuance is intentionally delayed until OTP verification when needed.
    await userRepository.updateLastLogin(user.id);
    if (!requiresOtp) eventBus.publish('user.login.success', { userId: user.id, companyId: user.companyId });

    const tokens = requiresOtp ? null : authInternal.generateTokenPair({
      userId: user.id,
      companyId: user.companyId,
      roles: roles.map((r) => r.id),
    });

    return {
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        username: user.username,
        avatar: user.avatar,
        roles: roles.map((r) => ({ id: r.id, name: r.name, description: r.description, permissions: [] })),
        permissions,
        companyId: user.companyId,
        branchId: user.branchId,
        isActive: user.isActive,
        lastLoginAt: user.lastLoginAt?.toISOString(),
      },
      accessToken: tokens?.accessToken,
      refreshToken: tokens?.refreshToken,
      requiresOtp,
      roles: roles.map((r) => ({ id: r.id, name: r.name, description: r.description, permissions: [] })),
    };
  },

  async verifyOtp(data: OTPVerifyRequest): Promise<OTPVerifyResponse> {
    const isValid = await authInternal.verifyOtp(data.userId, data.otp);

    if (!isValid) {
      throw new AppError('GNT-ERR-2005', 'Invalid or expired OTP', 401);
    }

    const user = await userRepository.findById(data.userId);
    if (!user) {
      throw new AppError('GNT-ERR-2006', 'User not found', 404);
    }

    const roles = await roleRepository.getRolesByUserId(user.id);
    const permissions = await roleRepository.getPermissionsByUserId(user.id);

    const tokens = authInternal.generateTokenPair({
      userId: user.id,
      companyId: user.companyId,
      roles: roles.map((r) => r.id),
    });
    eventBus.publish('user.login.success', { userId: user.id, companyId: user.companyId, secondFactor: true });

    return {
      accessToken: tokens.accessToken,
      refreshToken: tokens.refreshToken,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        username: user.username,
        avatar: user.avatar,
        roles: roles.map((r) => ({ id: r.id, name: r.name, description: r.description, permissions: [] })),
        permissions,
        companyId: user.companyId,
        branchId: user.branchId,
        isActive: user.isActive,
        lastLoginAt: user.lastLoginAt?.toISOString(),
      },
    };
  },

  async refreshToken(refreshToken: string): Promise<TokenPair> {
    const payload = authInternal.verifyRefreshToken(refreshToken);
    if (payload.type !== 'refresh' || !payload.userId || !payload.companyId) {
      throw new AppError('GNT-ERR-2007', 'Invalid refresh token', 401);
    }
    if (payload.iat && await authInternal.isTokenRevoked(payload.userId, payload.iat)) {
      throw new AppError('GNT-ERR-2007', 'Refresh token revoked', 401);
    }
    const user = await userRepository.findById(payload.userId);

    if (!user || !user.isActive) {
      throw new AppError('GNT-ERR-2007', 'Invalid refresh token', 401);
    }

    return authInternal.generateTokenPair({
      userId: user.id,
      companyId: user.companyId,
      roles: (await roleRepository.getRolesByUserId(user.id)).map((r) => r.id),
    });
  },

  async selectRole(userId: string, roleId: string): Promise<{ success: true }> {
    const roles = await roleRepository.getRolesByUserId(userId);
    if (!roles.some((role) => role.id === roleId)) {
      throw new AppError('GNT-ERR-2012', 'Role is not assigned to the current user', 403);
    }
    return { success: true };
  },

  async logout(userId: string): Promise<void> {
    await authInternal.revokeTokens(userId);
    eventBus.publish('user.logout', { userId });
  },

  async getCurrentUser(userId: string): Promise<UserProfile> {
    const user = await userRepository.findById(userId);
    if (!user) {
      throw new AppError('GNT-ERR-2006', 'User not found', 404);
    }

    const roles = await roleRepository.getRolesByUserId(user.id);
    const permissions = await roleRepository.getPermissionsByUserId(user.id);

    return {
      id: user.id,
      name: user.name,
      email: user.email,
      username: user.username,
      avatar: user.avatar,
      roles: roles.map((r) => ({ id: r.id, name: r.name, description: r.description, permissions: [] })),
      permissions,
      companyId: user.companyId,
      branchId: user.branchId,
      isActive: user.isActive,
      lastLoginAt: user.lastLoginAt?.toISOString(),
    };
  },

  async unlockSession(userId: string, pin: string): Promise<void> {
    const user = await userRepository.findById(userId);
    if (!user) {
      throw new AppError('GNT-ERR-2006', 'User not found', 404);
    }

    const isValidPin = await authInternal.verifyPin(userId, pin);
    if (!isValidPin) {
      throw new AppError('GNT-ERR-2008', 'Invalid PIN', 401);
    }
  },
};
