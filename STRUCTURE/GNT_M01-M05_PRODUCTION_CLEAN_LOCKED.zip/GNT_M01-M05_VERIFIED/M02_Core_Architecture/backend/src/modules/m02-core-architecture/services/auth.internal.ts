import { randomInt } from 'crypto';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import { redis } from '@/common/config/cache-config';
import { eventBus } from '@/common/events/event-bus';
import { logger } from '@/common/logging/logger';

const ACCESS_TOKEN_PRIVATE_KEY = mustGetKey('ACCESS_TOKEN_PRIVATE_KEY');
const ACCESS_TOKEN_PUBLIC_KEY = mustGetKey('ACCESS_TOKEN_PUBLIC_KEY');
const REFRESH_TOKEN_PRIVATE_KEY = mustGetKey('REFRESH_TOKEN_PRIVATE_KEY');
const REFRESH_TOKEN_PUBLIC_KEY = mustGetKey('REFRESH_TOKEN_PUBLIC_KEY');

const ACCESS_TOKEN_EXPIRY = '15m';
const REFRESH_TOKEN_EXPIRY = '7d';
const OTP_EXPIRY_SECONDS = 10 * 60;
const OTP_MAX_ATTEMPTS = 5;
const OTP_REDIS_PREFIX = 'auth:otp:';
const OTP_ATTEMPT_PREFIX = 'auth:otp-attempts:';
const REVOKED_TOKEN_PREFIX = 'auth:revoked:';
const PIN_REDIS_PREFIX = 'auth:pin:';

function mustGetKey(envVar: string): string {
  const key = process.env[envVar];
  if (!key) throw new Error(`${envVar} is not configured — RS256 requires a PEM key pair`);
  return key.replace(/\\n/g, '\n');
}

export const authInternal = {
  async hashPassword(password: string): Promise<string> { return bcrypt.hash(password, 12); },
  async verifyPassword(password: string, hash: string): Promise<boolean> { return bcrypt.compare(password, hash); },

  generateTokenPair(payload: { userId: string; companyId: string; roles: string[] }): { accessToken: string; refreshToken: string } {
    const accessToken = jwt.sign({ ...payload, type: 'access' }, ACCESS_TOKEN_PRIVATE_KEY, { expiresIn: ACCESS_TOKEN_EXPIRY, algorithm: 'RS256' });
    const refreshToken = jwt.sign({ userId: payload.userId, companyId: payload.companyId, roles: payload.roles, type: 'refresh' }, REFRESH_TOKEN_PRIVATE_KEY, { expiresIn: REFRESH_TOKEN_EXPIRY, algorithm: 'RS256' });
    return { accessToken, refreshToken };
  },

  verifyAccessToken(token: string): any { return jwt.verify(token, ACCESS_TOKEN_PUBLIC_KEY, { algorithms: ['RS256'] }); },
  verifyRefreshToken(token: string): any { return jwt.verify(token, REFRESH_TOKEN_PUBLIC_KEY, { algorithms: ['RS256'] }); },

  async sendOtp(userId: string, email: string): Promise<void> {
    const otp = randomInt(100000, 1000000).toString();
    await redis.set(`${OTP_REDIS_PREFIX}${userId}`, otp, 'EX', OTP_EXPIRY_SECONDS);
    await redis.set(`${OTP_ATTEMPT_PREFIX}${userId}`, '0', 'EX', OTP_EXPIRY_SECONDS);
    eventBus.publish('notification.otp.send', { userId, channel: 'email', destination: email, otp, expiresInSeconds: OTP_EXPIRY_SECONDS });
    logger.info(`OTP dispatched for user ${userId}`, { expiresInSeconds: OTP_EXPIRY_SECONDS });
  },

  async verifyOtp(userId: string, otp: string): Promise<boolean> {
    const key = `${OTP_REDIS_PREFIX}${userId}`;
    const attemptsKey = `${OTP_ATTEMPT_PREFIX}${userId}`;
    const stored = await redis.get(key);
    if (!stored) return false;
    const attempts = Number(await redis.get(attemptsKey) || '0');
    if (attempts >= OTP_MAX_ATTEMPTS) { await redis.del(key, attemptsKey); return false; }
    if (stored !== otp) { await redis.incr(attemptsKey); return false; }
    await redis.del(key, attemptsKey);
    return true;
  },

  async verifyPin(userId: string, pin: string): Promise<boolean> {
    const storedHash = await redis.get(`${PIN_REDIS_PREFIX}${userId}`);
    return storedHash ? bcrypt.compare(pin, storedHash) : false;
  },
  async setPin(userId: string, pin: string): Promise<void> { await redis.set(`${PIN_REDIS_PREFIX}${userId}`, await bcrypt.hash(pin, 10)); },

  isHighRiskLogin(user: any): boolean {
    return user.failedLoginAttempts >= 2 || Boolean(user.lastKnownDeviceId && user.currentDeviceId && user.lastKnownDeviceId !== user.currentDeviceId);
  },

  async revokeTokens(userId: string): Promise<void> {
    await redis.set(`${REVOKED_TOKEN_PREFIX}${userId}`, Date.now().toString(), 'EX', 7 * 24 * 60 * 60);
    logger.info(`Tokens revoked for user ${userId}`);
  },
  async isTokenRevoked(userId: string, issuedAtSeconds: number): Promise<boolean> {
    const revokedAt = await redis.get(`${REVOKED_TOKEN_PREFIX}${userId}`);
    return Boolean(revokedAt && issuedAtSeconds * 1000 < Number(revokedAt));
  },
};
