import { prisma } from '@/common/config/env-config';

export const userRepository = {
  async findById(id: string) {
    return prisma.user_master.findUnique({ where: { id }, include: { user_role: { include: { role_master: true } } } });
  },
  async findByUsernameAndCompany(username: string, companyCode: string) {
    return prisma.user_master.findFirst({ where: { username, company_master: { code: companyCode } } });
  },
  async findByCompanyId(companyId: string) {
    return prisma.user_master.findMany({ where: { companyId, deletedAt: null }, select: { id: true, name: true, email: true, username: true, avatar: true, isActive: true, lastLoginAt: true, createdAt: true } });
  },
  async create(data: any) {
    const { roleIds = [], passwordHash, ...userData } = data;
    return prisma.user_master.create({ data: { ...userData, passwordHash, user_role: { create: roleIds.map((roleId: string) => ({ role_master: { connect: { id: roleId } } })) } } });
  },
  async update(id: string, data: any) {
    const { roleIds, password, ...userData } = data;
    if (password) throw new Error('Plaintext password must not reach repository');
    if (roleIds) {
      return prisma.$transaction(async (tx: any) => {
        const updated = await tx.user_master.update({ where: { id }, data: userData });
        await tx.user_role.deleteMany({ where: { userId: id } });
        if (roleIds.length) await tx.user_role.createMany({ data: roleIds.map((roleId: string) => ({ userId: id, roleId })) });
        return updated;
      });
    }
    return prisma.user_master.update({ where: { id }, data: userData });
  },
  async delete(id: string) { return prisma.user_master.update({ where: { id }, data: { isActive: false, deletedAt: new Date() } }); },
  async incrementFailedAttempts(id: string) { return prisma.user_master.update({ where: { id }, data: { failedLoginAttempts: { increment: 1 } } }); },
  async lockAccount(id: string, until: Date) { return prisma.user_master.update({ where: { id }, data: { lockedUntil: until } }); },
  async resetFailedAttempts(id: string) { return prisma.user_master.update({ where: { id }, data: { failedLoginAttempts: 0, lockedUntil: null } }); },
  async updateLastLogin(id: string) { return prisma.user_master.update({ where: { id }, data: { lastLoginAt: new Date() } }); },
};
