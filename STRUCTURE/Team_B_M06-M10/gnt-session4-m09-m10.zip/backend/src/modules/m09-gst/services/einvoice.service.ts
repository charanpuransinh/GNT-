import { PrismaClient } from '@prisma/client';
import { EInvoiceRepository } from '../repositories/einvoice.repository';

export interface TransportDetails {
  distance_km: number;
  vehicle_no?: string;
  transporter_id?: string;
  transporter_name?: string;
}

export class EInvoiceService {
  constructor(private repo: EInvoiceRepository) {}

  async generateIRN(invoiceId: string): Promise<any> {
    const invoice = await this.repo.getInvoiceData(invoiceId);
    if (!invoice) throw new Error('Invoice not found');

    const irn = `IRN${Date.now()}${Math.floor(Math.random() * 10000)}`;
    const ackNo = `ACK${Date.now()}`;
    const qrCode = `data:image/png;base64,${Buffer.from(JSON.stringify({ irn, invoiceId })).toString('base64')}`;

    const record = await this.repo.createEInvoice({
      company_id: invoice.company_id,
      sales_invoice_id: invoiceId,
      irn,
      ack_no: ackNo,
      ack_date: new Date(),
      signed_invoice: JSON.stringify(invoice),
      qr_code: qrCode,
      status: 'generated',
    });

    return record;
  }

  async cancelIRN(irn: string, reason: string): Promise<any> {
    const existing = await this.repo.findByIRN(irn);
    if (!existing) throw new Error('IRN not found');
    if (existing.status === 'cancelled') throw new Error('Already cancelled');
    return this.repo.updateEInvoiceStatus(irn, 'cancelled');
  }

  async getStatus(irn: string): Promise<any> {
    return this.repo.findByIRN(irn);
  }

  async generateEWayBill(invoiceId: string, transport: TransportDetails): Promise<any> {
    const invoice = await this.repo.getInvoiceData(invoiceId);
    if (!invoice) throw new Error('Invoice not found');

    const ewbNo = `EWB${Date.now()}${Math.floor(Math.random() * 10000)}`;
    const validUpto = new Date();
    validUpto.setDate(validUpto.getDate() + 1);

    return this.repo.createEWayBill({
      company_id: invoice.company_id,
      sales_invoice_id: invoiceId,
      ewb_no: ewbNo,
      ewb_date: new Date(),
      valid_upto: validUpto,
      distance_km: transport.distance_km,
      vehicle_no: transport.vehicle_no,
      status: 'generated',
    });
  }
}
