import { PrismaClient } from '@prisma/client';

export class EInvoiceRepository {
  constructor(private prisma: PrismaClient) {}

  async getInvoiceData(invoiceId: string): Promise<any> {
    return { company_id: 'mock-company', id: invoiceId, total_amount: 100000 };
  }

  async createEInvoice(data: any): Promise<any> {
    return this.prisma.e_invoice_record.create({ data });
  }

  async findByIRN(irn: string): Promise<any> {
    return this.prisma.e_invoice_record.findUnique({ where: { irn } });
  }

  async updateEInvoiceStatus(irn: string, status: string): Promise<any> {
    return this.prisma.e_invoice_record.update({
      where: { irn },
      data: { status, updated_at: new Date() },
    });
  }

  async createEWayBill(data: any): Promise<any> {
    return this.prisma.e_way_bill_record.create({ data });
  }

  async findEWayBillByNo(ewbNo: string): Promise<any> {
    return this.prisma.e_way_bill_record.findUnique({ where: { ewb_no: ewbNo } });
  }
}
