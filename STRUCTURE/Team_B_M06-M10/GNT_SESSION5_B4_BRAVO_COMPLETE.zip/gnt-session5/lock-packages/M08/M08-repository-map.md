# M08 Repository Map
# Module: Sales Management
# Directory: backend/src/modules/m08-sales/

## Structure
m08-sales/
├── controllers/
│   └── (API controllers)
├── services/
│   ├── internal/     # Private business logic
│   └── public/       # Public service interfaces
├── repositories/
│   └── (Prisma/data access)
├── models/
│   └── (DTOs, entities)
├── events/
│   ├── publishers/
│   └── handlers/
├── validators/
│   └── (Joi/Zod schemas)
├── routes.ts
├── module.ts
└── index.ts

## Total Files: 76
## Repository Files: 10
