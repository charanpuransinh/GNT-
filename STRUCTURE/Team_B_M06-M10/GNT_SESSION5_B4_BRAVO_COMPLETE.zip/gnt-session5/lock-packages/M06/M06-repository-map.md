# M06 Repository Map
# Module: Inventory & Stock Management
# Directory: backend/src/modules/m06-inventory/

## Structure
m06-inventory/
├── controllers/
│   └── (API controllers)
├── services/
│   ├── internal/     # Private business logic
│   └── public/       # Public service interfaces
├── repositories/
│   └── (Prisma/data access)
├── models/
│   └── (DTOs, entities)
├── events/
│   ├── publishers/
│   └── handlers/
├── validators/
│   └── (Joi/Zod schemas)
├── routes.ts
├── module.ts
└── index.ts

## Total Files: 66
## Repository Files: 6
