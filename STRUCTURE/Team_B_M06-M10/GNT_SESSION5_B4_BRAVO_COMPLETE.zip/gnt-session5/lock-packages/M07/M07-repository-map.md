# M07 Repository Map
# Module: Purchase Management
# Directory: backend/src/modules/m07-purchase/

## Structure
m07-purchase/
├── controllers/
│   └── (API controllers)
├── services/
│   ├── internal/     # Private business logic
│   └── public/       # Public service interfaces
├── repositories/
│   └── (Prisma/data access)
├── models/
│   └── (DTOs, entities)
├── events/
│   ├── publishers/
│   └── handlers/
├── validators/
│   └── (Joi/Zod schemas)
├── routes.ts
├── module.ts
└── index.ts

## Total Files: 56
## Repository Files: 7
