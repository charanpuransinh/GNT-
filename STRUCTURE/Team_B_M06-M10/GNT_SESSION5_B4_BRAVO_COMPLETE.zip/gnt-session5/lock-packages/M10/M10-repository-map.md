# M10 Repository Map
# Module: Accounting & Ledger
# Directory: backend/src/modules/m10-accounting/

## Structure
m10-accounting/
├── controllers/
│   └── (API controllers)
├── services/
│   ├── internal/     # Private business logic
│   └── public/       # Public service interfaces
├── repositories/
│   └── (Prisma/data access)
├── models/
│   └── (DTOs, entities)
├── events/
│   ├── publishers/
│   └── handlers/
├── validators/
│   └── (Joi/Zod schemas)
├── routes.ts
├── module.ts
└── index.ts

## Total Files: 62
## Repository Files: 7
