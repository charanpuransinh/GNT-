# M09 Repository Map
# Module: GST & Taxation
# Directory: backend/src/modules/m09-gst/

## Structure
m09-gst/
├── controllers/
│   └── (API controllers)
├── services/
│   ├── internal/     # Private business logic
│   └── public/       # Public service interfaces
├── repositories/
│   └── (Prisma/data access)
├── models/
│   └── (DTOs, entities)
├── events/
│   ├── publishers/
│   └── handlers/
├── validators/
│   └── (Joi/Zod schemas)
├── routes.ts
├── module.ts
└── index.ts

## Total Files: 49
## Repository Files: 6
