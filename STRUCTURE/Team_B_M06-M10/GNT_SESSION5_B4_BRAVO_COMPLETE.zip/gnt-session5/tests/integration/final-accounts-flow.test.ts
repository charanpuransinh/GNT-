import request from 'supertest';
import { app } from '../../src/app';
import { prisma } from '../../src/lib/prisma';
import { generateToken } from '../helpers/auth';

describe('INTEGRATION: Final Accounts Flow (M10→M07→M08→M11→M12)', () => {
  let adminToken: string;
  let accountantToken: string;
  let companyId: string;
  let supplierId: string;
  let customerId: string;
  let productId: string;
  let bankAccountId: string;

  beforeAll(async () => {
    adminToken = generateToken({ userId: 'admin-1', role: 'admin', permissions: ['*'] });
    accountantToken = generateToken({ userId: 'acc-1', role: 'accountant', permissions: ['accounting_view', 'voucher_create', 'ledger_view', 'report_view'] });
    companyId = 'comp-test-007';

    const supRes = await request(app).post('/api/v1/parties/suppliers').set('Authorization', `Bearer ${adminToken}`).set('X-Company-Id', companyId).send({ name: 'FA Supplier', gstin: '27AABCU9603R1ZX', contact: { email: 'fas@test.com', phone: '3333333333' }, address: { line1: 'E', city: 'Kolkata', state: 'WB', pincode: '700001' }, opening_balance: 0, credit_limit: 100000 });
    supplierId = supRes.body.data.id;

    const custRes = await request(app).post('/api/v1/parties/customers').set('Authorization', `Bearer ${adminToken}`).set('X-Company-Id', companyId).send({ name: 'FA Customer', gstin: '27AADCB2230M1ZT', contact: { email: 'fac@test.com', phone: '2222222222' }, address: { line1: 'F', city: 'Ahmedabad', state: 'GJ', pincode: '380001' }, opening_balance: 0, credit_limit: 100000 });
    customerId = custRes.body.data.id;

    const prodRes = await request(app).post('/api/v1/inventory/products').set('Authorization', `Bearer ${adminToken}`).set('X-Company-Id', companyId).send({ sku: 'FA-PROD-001', name: 'FA Item', category_id: 'cat-misc', unit: 'pcs', hsn_code: '9999', gst_slab_id: 'gst-18', reorder_level: 10, opening_stock: 500, valuation_method: 'FIFO' });
    productId = prodRes.body.data.id;

    // Create bank account in M10
    const bankRes = await request(app).post('/api/v1/accounting/bank-accounts').set('Authorization', `Bearer ${adminToken}`).set('X-Company-Id', companyId).send({
      account_name: 'HDFC Current', account_number: '1234567890', ifsc: 'HDFC0001234', branch: 'Main Branch', opening_balance: 100000
    });
    bankAccountId = bankRes.body.data.id;

    // Step 1: Post purchase invoices (expense)
    for (let i = 0; i < 2; i++) {
      const res = await request(app).post('/api/v1/purchase/invoices').set('Authorization', `Bearer ${adminToken}`).set('X-Company-Id', companyId).send({
        supplier_id: supplierId, invoice_date: '2026-08-01', due_date: '2026-09-01',
        items: [{ product_id: productId, quantity: 20, rate: 500, discount: 0, tax_rate: 18 }]
      });
      const pid = res.body.data.id;
      await request(app).post(`/api/v1/purchase/invoices/${pid}/approve`).set('Authorization', `Bearer ${adminToken}`).set('X-Company-Id', companyId);
      await request(app).post(`/api/v1/purchase/invoices/${pid}/post`).set('Authorization', `Bearer ${adminToken}`).set('X-Company-Id', companyId);
    }

    // Step 2: Post sales invoices (income)
    for (let i = 0; i < 2; i++) {
      const res = await request(app).post('/api/v1/sales/invoices').set('Authorization', `Bearer ${adminToken}`).set('X-Company-Id', companyId).send({
        customer_id: customerId, invoice_date: '2026-08-05', due_date: '2026-09-05',
        items: [{ product_id: productId, quantity: 15, rate: 800, discount: 0, tax_rate: 18 }]
      });
      const sid = res.body.data.id;
      await request(app).post(`/api/v1/sales/invoices/${sid}/approve`).set('Authorization', `Bearer ${adminToken}`).set('X-Company-Id', companyId);
      await request(app).post(`/api/v1/sales/invoices/${sid}/post`).set('Authorization', `Bearer ${adminToken}`).set('X-Company-Id', companyId);
    }

    // Step 3: Post payments (bank/cash)
    const payRes = await request(app).post('/api/v1/payments/received').set('Authorization', `Bearer ${adminToken}`).set('X-Company-Id', companyId).send({
      party_id: customerId, amount: 5000, payment_date: '2026-08-10', mode: 'BANK_TRANSFER', bank_account_id: bankAccountId, reference_no: 'UTR-FA-001'
    });
    const paymentId = payRes.body.data.id;
    await request(app).post(`/api/v1/payments/received/${paymentId}/allocate`).set('Authorization', `Bearer ${adminToken}`).set('X-Company-Id', companyId).send({
      allocations: [{ invoice_type: 'SALES', invoice_id: (await prisma.sales_invoice.findFirst({ where: { company_id: companyId } }))?.id, amount: 5000 }]
    });

    // Step 4: Post salary vouchers (M12→M10)
    const salaryRes = await request(app).post('/api/v1/payroll/salary-vouchers').set('Authorization', `Bearer ${adminToken}`).set('X-Company-Id', companyId).send({
      month: '2026-08', year: 2026, employee_ids: ['emp-001', 'emp-002'], payment_date: '2026-08-31', bank_account_id: bankAccountId
    });
    const voucherId = salaryRes.body.data.id;
    await request(app).post(`/api/v1/payroll/salary-vouchers/${voucherId}/post`).set('Authorization', `Bearer ${adminToken}`).set('X-Company-Id', companyId);
  });

  it('Step 5: Generate Trial Balance in M10', async () => {
    const tbRes = await request(app)
      .get('/api/v1/accounting/trial-balance')
      .set('Authorization', `Bearer ${accountantToken}`)
      .set('X-Company-Id', companyId)
      .query({ as_of: '2026-08-31' });
    expect(tbRes.status).toBe(200);
    expect(tbRes.body.data.debit_total).toBeDefined();
    expect(tbRes.body.data.credit_total).toBeDefined();
  });

  it('Step 6: Generate P&L in M10', async () => {
    const plRes = await request(app)
      .get('/api/v1/accounting/profit-loss')
      .set('Authorization', `Bearer ${accountantToken}`)
      .set('X-Company-Id', companyId)
      .query({ from: '2026-08-01', to: '2026-08-31' });
    expect(plRes.status).toBe(200);
    expect(plRes.body.data.income_total).toBeGreaterThan(0);
    expect(plRes.body.data.expense_total).toBeGreaterThan(0);
  });

  it('Step 7: Generate Balance Sheet in M10', async () => {
    const bsRes = await request(app)
      .get('/api/v1/accounting/balance-sheet')
      .set('Authorization', `Bearer ${accountantToken}`)
      .set('X-Company-Id', companyId)
      .query({ as_of: '2026-08-31' });
    expect(bsRes.status).toBe(200);
    expect(bsRes.body.data.assets_total).toBeGreaterThan(0);
    expect(bsRes.body.data.liabilities_total).toBeGreaterThan(0);
  });

  it('Step 8: VERIFY TB debit = credit', async () => {
    const tb = await request(app).get('/api/v1/accounting/trial-balance').set('Authorization', `Bearer ${accountantToken}`).set('X-Company-Id', companyId).query({ as_of: '2026-08-31' });
    expect(parseFloat(tb.body.data.debit_total)).toBeCloseTo(parseFloat(tb.body.data.credit_total), 2);
  });

  it('Step 9: VERIFY P&L net = Income - Expense', async () => {
    const pl = await request(app).get('/api/v1/accounting/profit-loss').set('Authorization', `Bearer ${accountantToken}`).set('X-Company-Id', companyId).query({ from: '2026-08-01', to: '2026-08-31' });
    const expectedNet = parseFloat(pl.body.data.income_total) - parseFloat(pl.body.data.expense_total);
    expect(parseFloat(pl.body.data.net_profit)).toBeCloseTo(expectedNet, 2);
  });

  it('Step 10: VERIFY BS Assets = Liabilities + Equity', async () => {
    const bs = await request(app).get('/api/v1/accounting/balance-sheet').set('Authorization', `Bearer ${accountantToken}`).set('X-Company-Id', companyId).query({ as_of: '2026-08-31' });
    const lhs = parseFloat(bs.body.data.assets_total);
    const rhs = parseFloat(bs.body.data.liabilities_total) + parseFloat(bs.body.data.equity_total);
    expect(lhs).toBeCloseTo(rhs, 2);
  });

  it('ASSERT: All transactions reflected', async () => {
    const entries = await prisma.ledger_entry.count({ where: { company_id: companyId } });
    expect(entries).toBeGreaterThan(10); // Purchase, sales, payment, salary entries
  });

  it('ASSERT: Opening balances carried forward', async () => {
    const bankLedger = await prisma.ledger_account.findFirst({ where: { company_id: companyId, code: 'BANK_HDFC_CURRENT' } });
    expect(parseFloat(bankLedger?.opening_balance || '0')).toBeGreaterThan(0);
  });

  it('ASSERT: No orphan ledger entries', async () => {
    const orphans = await prisma.ledger_entry.count({
      where: {
        company_id: companyId,
        OR: [
          { voucher_id: null, reference_type: null },
          { debit_amount: 0, credit_amount: 0 }
        ]
      }
    });
    expect(orphans).toBe(0);
  });
});
