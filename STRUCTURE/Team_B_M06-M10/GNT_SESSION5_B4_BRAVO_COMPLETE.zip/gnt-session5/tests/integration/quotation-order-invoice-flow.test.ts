import request from 'supertest';
import { app } from '../../src/app';
import { prisma } from '../../src/lib/prisma';
import { generateToken } from '../helpers/auth';

describe('INTEGRATION: Quotation→Order→Invoice Flow (M08 internal)', () => {
  let salesToken: string;
  let companyId: string;
  let customerId: string;
  let productId: string;
  let quotationId: string;
  let orderId: string;
  let invoiceId: string;

  beforeAll(async () => {
    salesToken = generateToken({ userId: 'sales-1', role: 'sales_exec', permissions: ['sales_create', 'sales_approve', 'sales_post', 'quotation_create', 'order_create'] });
    companyId = 'comp-test-005';

    const custRes = await request(app)
      .post('/api/v1/parties/customers')
      .set('Authorization', `Bearer ${salesToken}`)
      .set('X-Company-Id', companyId)
      .send({ name: 'QO Customer', gstin: '27AADCB2230M1ZT', contact: { email: 'qo@test.com', phone: '6666666666' }, address: { line1: 'B', city: 'Bangalore', state: 'KA', pincode: '560001' }, opening_balance: 0, credit_limit: 50000 });
    customerId = custRes.body.data.id;

    const prodRes = await request(app)
      .post('/api/v1/inventory/products')
      .set('Authorization', `Bearer ${salesToken}`)
      .set('X-Company-Id', companyId)
      .send({ sku: 'TEST-PROD-005', name: 'QO Item', category_id: 'cat-misc', unit: 'pcs', hsn_code: '9999', gst_slab_id: 'gst-12', reorder_level: 10, opening_stock: 200, valuation_method: 'FIFO' });
    productId = prodRes.body.data.id;
  });

  it('Step 1: Create quotation in M08', async () => {
    const qRes = await request(app)
      .post('/api/v1/sales/quotations')
      .set('Authorization', `Bearer ${salesToken}`)
      .set('X-Company-Id', companyId)
      .send({
        customer_id: customerId,
        quotation_date: '2026-08-24',
        valid_until: '2026-09-24',
        items: [{ product_id: productId, quantity: 20, rate: 500, discount: 0, tax_rate: 12 }],
        terms: 'Net 30 days'
      });
    expect(qRes.status).toBe(201);
    quotationId = qRes.body.data.id;
  });

  it('ASSERT: Quotation does NOT affect stock', async () => {
    const stockBefore = await prisma.stock_master.findFirst({ where: { product_id: productId, company_id: companyId } });
    // Quotation creation should not create stock_movement
    const movements = await prisma.stock_movement.count({
      where: { reference_type: 'QUOTATION', reference_id: quotationId }
    });
    expect(movements).toBe(0);
  });

  it('Step 2: Convert quotation to order', async () => {
    const oRes = await request(app)
      .post(`/api/v1/sales/quotations/${quotationId}/convert-to-order`)
      .set('Authorization', `Bearer ${salesToken}`)
      .set('X-Company-Id', companyId)
      .send({ order_date: '2026-08-25', delivery_date: '2026-09-05' });
    expect(oRes.status).toBe(201);
    orderId = oRes.body.data.id;
    expect(oRes.body.data.quotation_id).toBe(quotationId);
  });

  it('ASSERT: Order does NOT affect stock', async () => {
    const movements = await prisma.stock_movement.count({
      where: { reference_type: 'SALES_ORDER', reference_id: orderId }
    });
    expect(movements).toBe(0);
  });

  it('Step 3: Convert order to invoice', async () => {
    const iRes = await request(app)
      .post(`/api/v1/sales/orders/${orderId}/convert-to-invoice`)
      .set('Authorization', `Bearer ${salesToken}`)
      .set('X-Company-Id', companyId)
      .send({ invoice_date: '2026-08-26', due_date: '2026-09-26' });
    expect(iRes.status).toBe(201);
    invoiceId = iRes.body.data.id;
    expect(iRes.body.data.order_id).toBe(orderId);
  });

  it('Step 4: Post invoice', async () => {
    await request(app).post(`/api/v1/sales/invoices/${invoiceId}/approve`).set('Authorization', `Bearer ${salesToken}`).set('X-Company-Id', companyId);
    const postRes = await request(app).post(`/api/v1/sales/invoices/${invoiceId}/post`).set('Authorization', `Bearer ${salesToken}`).set('X-Company-Id', companyId);
    expect(postRes.status).toBe(200);
  });

  it('ASSERT: Only posted invoice affects stock', async () => {
    const movement = await prisma.stock_movement.findFirst({
      where: { reference_type: 'SALES_INVOICE', reference_id: invoiceId }
    });
    expect(movement).toBeTruthy();
    expect(movement?.quantity).toBe(-20);
  });

  it('Step 5: VERIFY All documents linked', async () => {
    const invoice = await prisma.sales_invoice.findUnique({ where: { id: invoiceId } });
    expect(invoice?.quotation_id).toBe(quotationId);
    expect(invoice?.order_id).toBe(orderId);

    const order = await prisma.sales_order.findUnique({ where: { id: orderId } });
    expect(order?.quotation_id).toBe(quotationId);
  });
});
