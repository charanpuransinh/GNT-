import request from 'supertest';
import { app } from '../../src/app';
import { prisma } from '../../src/lib/prisma';
import { eventBus } from '../../src/lib/event-bus';
import { generateToken } from '../helpers/auth';

describe('INTEGRATION: Sales Invoice Complete Flow (M08→M06→M09→M10→M11→M16)', () => {
  let adminToken: string;
  let salesToken: string;
  let companyId: string;
  let customerId: string;
  let productId: string;
  let invoiceId: string;

  beforeAll(async () => {
    adminToken = generateToken({ userId: 'admin-1', role: 'admin', permissions: ['*'] });
    salesToken = generateToken({ userId: 'sales-1', role: 'sales_exec', permissions: ['sales_create', 'sales_approve', 'sales_post'] });
    companyId = 'comp-test-002';

    // Step 1: Create customer in M05
    const customerRes = await request(app)
      .post('/api/v1/parties/customers')
      .set('Authorization', `Bearer ${adminToken}`)
      .set('X-Company-Id', companyId)
      .send({
        name: 'Test Customer Pvt Ltd',
        gstin: '27AADCB2230M1ZT',
        contact: { email: 'customer@test.com', phone: '8888888888' },
        address: { line1: 'Customer Road', city: 'Pune', state: 'MH', pincode: '411001' },
        opening_balance: 0,
        credit_limit: 200000
      });
    expect(customerRes.status).toBe(201);
    customerId = customerRes.body.data.id;

    // Step 2: Create product in M06 with stock
    const productRes = await request(app)
      .post('/api/v1/inventory/products')
      .set('Authorization', `Bearer ${adminToken}`)
      .set('X-Company-Id', companyId)
      .send({
        sku: 'TEST-PROD-002',
        name: 'Test Gadget',
        category_id: 'cat-electronics',
        unit: 'pcs',
        hsn_code: '8471',
        gst_slab_id: 'gst-18',
        reorder_level: 5,
        opening_stock: 500,
        valuation_method: 'FIFO'
      });
    expect(productRes.status).toBe(201);
    productId = productRes.body.data.id;
  });

  afterAll(async () => {
    await prisma.$disconnect();
  });

  it('Step 3-5: Create, Approve & Post Sales Invoice in M08', async () => {
    // Credit limit check & stock availability check happen at posting
    const createRes = await request(app)
      .post('/api/v1/sales/invoices')
      .set('Authorization', `Bearer ${salesToken}`)
      .set('X-Company-Id', companyId)
      .send({
        customer_id: customerId,
        invoice_date: '2026-08-24',
        due_date: '2026-09-24',
        items: [
          { product_id: productId, quantity: 50, rate: 1000, discount: 5, tax_rate: 18 }
        ],
        notes: 'Test sales invoice'
      });
    expect(createRes.status).toBe(201);
    invoiceId = createRes.body.data.id;

    // Approve
    const approveRes = await request(app)
      .post(`/api/v1/sales/invoices/${invoiceId}/approve`)
      .set('Authorization', `Bearer ${salesToken}`)
      .set('X-Company-Id', companyId);
    expect(approveRes.status).toBe(200);

    // Post — this triggers credit limit + stock checks
    const postRes = await request(app)
      .post(`/api/v1/sales/invoices/${invoiceId}/post`)
      .set('Authorization', `Bearer ${salesToken}`)
      .set('X-Company-Id', companyId);
    expect(postRes.status).toBe(200);
    expect(postRes.body.data.status).toBe('POSTED');
  });

  it('ASSERT: Credit limit check passed before posting', async () => {
    const party = await prisma.party.findFirst({ where: { id: customerId, company_id: companyId } });
    const outstanding = parseFloat(party?.outstanding_amount || '0');
    const limit = parseFloat(party?.credit_limit || '0');
    expect(outstanding).toBeLessThanOrEqual(limit);
  });

  it('ASSERT: Stock availability check passed before posting', async () => {
    const stock = await prisma.stock_master.findFirst({
      where: { product_id: productId, company_id: companyId }
    });
    expect(parseFloat(stock?.quantity || '0')).toBeGreaterThanOrEqual(0);
  });

  it('Step 6: VERIFY M06 stock decreased (stock_movement record)', async () => {
    const movement = await prisma.stock_movement.findFirst({
      where: {
        company_id: companyId,
        reference_type: 'SALES_INVOICE',
        reference_id: invoiceId,
        product_id: productId
      }
    });
    expect(movement).toBeTruthy();
    expect(movement?.quantity).toBe(-50);
    expect(movement?.movement_type).toBe('OUT');
  });

  it('Step 7: VERIFY M09 GST transaction created (output tax)', async () => {
    const gstTxn = await prisma.gst_transaction.findFirst({
      where: {
        company_id: companyId,
        reference_type: 'SALES_INVOICE',
        reference_id: invoiceId
      }
    });
    expect(gstTxn).toBeTruthy();
    expect(gstTxn?.transaction_type).toBe('OUTPUT_TAX');
  });

  it('Step 8: VERIFY M10 ledger entries (Customer A/c Dr, Sales A/c Cr, GST Output Cr)', async () => {
    const entries = await prisma.ledger_entry.findMany({
      where: {
        company_id: companyId,
        reference_type: 'SALES_INVOICE',
        reference_id: invoiceId
      }
    });
    const customerDr = entries.find(e => e.account_code.startsWith('CUSTOMER_') && e.debit_amount > 0);
    const salesCr = entries.find(e => e.account_code === 'SALES_AC' && e.credit_amount > 0);
    const gstCr = entries.find(e => e.account_code === 'GST_OUTPUT_18' && e.credit_amount > 0);
    expect(customerDr).toBeTruthy();
    expect(salesCr).toBeTruthy();
    expect(gstCr).toBeTruthy();
  });

  it('Step 9: VERIFY M11 due created', async () => {
    const due = await prisma.due.findFirst({
      where: {
        company_id: companyId,
        reference_type: 'SALES_INVOICE',
        reference_id: invoiceId
      }
    });
    expect(due).toBeTruthy();
    expect(due?.party_id).toBe(customerId);
  });

  it('Step 10: VERIFY M16 notification event published', async () => {
    const events = await eventBus.getPublishedEvents();
    const notifEvent = events.find(e => e.name === 'sales.invoice.created' && e.payload.invoice_id === invoiceId);
    expect(notifEvent).toBeTruthy();
    expect(notifEvent?.payload.customer_id).toBe(customerId);
  });

  it('Step 11: VERIFY M17 report update event published', async () => {
    const events = await eventBus.getPublishedEvents();
    const reportEvent = events.find(e => e.name === 'sales.invoice.created');
    expect(reportEvent?.consumed_by).toContain('M17');
  });

  it('ASSERT: All side effects atomic', async () => {
    // If any side effect failed, invoice status would not be POSTED
    const inv = await prisma.sales_invoice.findUnique({ where: { id: invoiceId } });
    expect(inv?.status).toBe('POSTED');
    // Verify all modules have records
    const stockCount = await prisma.stock_movement.count({ where: { reference_id: invoiceId } });
    const ledgerCount = await prisma.ledger_entry.count({ where: { reference_id: invoiceId } });
    const gstCount = await prisma.gst_transaction.count({ where: { reference_id: invoiceId } });
    expect(stockCount).toBeGreaterThan(0);
    expect(ledgerCount).toBeGreaterThanOrEqual(3);
    expect(gstCount).toBeGreaterThan(0);
  });
});
