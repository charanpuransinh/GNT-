import request from 'supertest';
import { app } from '../../src/app';
import { prisma } from '../../src/lib/prisma';
import { generateToken } from '../helpers/auth';

describe('INTEGRATION: GST Return Compilation Flow (M09→M07→M08→M17)', () => {
  let adminToken: string;
  let gstToken: string;
  let companyId: string;
  let supplierId: string;
  let customerId: string;
  let productId: string;
  let purchaseInvoiceIds: string[] = [];
  let salesInvoiceIds: string[] = [];

  beforeAll(async () => {
    adminToken = generateToken({ userId: 'admin-1', role: 'admin', permissions: ['*'] });
    gstToken = generateToken({ userId: 'gst-1', role: 'gst_admin', permissions: ['gst_view', 'gst_file', 'invoice_view'] });
    companyId = 'comp-test-006';

    // Setup parties
    const supRes = await request(app).post('/api/v1/parties/suppliers').set('Authorization', `Bearer ${adminToken}`).set('X-Company-Id', companyId).send({ name: 'GST Supplier', gstin: '27AABCU9603R1ZX', contact: { email: 'gs@test.com', phone: '5555555555' }, address: { line1: 'C', city: 'Chennai', state: 'TN', pincode: '600001' }, opening_balance: 0, credit_limit: 100000 });
    supplierId = supRes.body.data.id;

    const custRes = await request(app).post('/api/v1/parties/customers').set('Authorization', `Bearer ${adminToken}`).set('X-Company-Id', companyId).send({ name: 'GST Customer', gstin: '27AADCB2230M1ZT', contact: { email: 'gc@test.com', phone: '4444444444' }, address: { line1: 'D', city: 'Hyderabad', state: 'TS', pincode: '500001' }, opening_balance: 0, credit_limit: 100000 });
    customerId = custRes.body.data.id;

    const prodRes = await request(app).post('/api/v1/inventory/products').set('Authorization', `Bearer ${adminToken}`).set('X-Company-Id', companyId).send({ sku: 'GST-PROD-001', name: 'GST Test Item', category_id: 'cat-misc', unit: 'pcs', hsn_code: '8471', gst_slab_id: 'gst-18', reorder_level: 10, opening_stock: 1000, valuation_method: 'FIFO' });
    productId = prodRes.body.data.id;

    // Step 1: Create multiple purchase invoices (posted)
    for (let i = 0; i < 3; i++) {
      const res = await request(app).post('/api/v1/purchase/invoices').set('Authorization', `Bearer ${adminToken}`).set('X-Company-Id', companyId).send({
        supplier_id: supplierId, invoice_date: '2026-08-01', due_date: '2026-09-01',
        items: [{ product_id: productId, quantity: 10 + i, rate: 1000, discount: 0, tax_rate: 18 }]
      });
      const pid = res.body.data.id;
      await request(app).post(`/api/v1/purchase/invoices/${pid}/approve`).set('Authorization', `Bearer ${adminToken}`).set('X-Company-Id', companyId);
      await request(app).post(`/api/v1/purchase/invoices/${pid}/post`).set('Authorization', `Bearer ${adminToken}`).set('X-Company-Id', companyId);
      purchaseInvoiceIds.push(pid);
    }

    // Step 2: Create multiple sales invoices (posted)
    for (let i = 0; i < 3; i++) {
      const res = await request(app).post('/api/v1/sales/invoices').set('Authorization', `Bearer ${adminToken}`).set('X-Company-Id', companyId).send({
        customer_id: customerId, invoice_date: '2026-08-05', due_date: '2026-09-05',
        items: [{ product_id: productId, quantity: 5 + i, rate: 1500, discount: 0, tax_rate: 18 }]
      });
      const sid = res.body.data.id;
      await request(app).post(`/api/v1/sales/invoices/${sid}/approve`).set('Authorization', `Bearer ${adminToken}`).set('X-Company-Id', companyId);
      await request(app).post(`/api/v1/sales/invoices/${sid}/post`).set('Authorization', `Bearer ${adminToken}`).set('X-Company-Id', companyId);
      salesInvoiceIds.push(sid);
    }

    // Create one cancelled invoice (should be excluded)
    const cancelRes = await request(app).post('/api/v1/sales/invoices').set('Authorization', `Bearer ${adminToken}`).set('X-Company-Id', companyId).send({
      customer_id: customerId, invoice_date: '2026-08-10', due_date: '2026-09-10',
      items: [{ product_id: productId, quantity: 1, rate: 100, discount: 0, tax_rate: 18 }]
    });
    const cancelId = cancelRes.body.data.id;
    await request(app).delete(`/api/v1/sales/invoices/${cancelId}`).set('Authorization', `Bearer ${adminToken}`).set('X-Company-Id', companyId);
  });

  it('Step 3: Generate GSTR-1 in M09', async () => {
    const gstr1Res = await request(app)
      .post('/api/v1/gst/returns/gstr1')
      .set('Authorization', `Bearer ${gstToken}`)
      .set('X-Company-Id', companyId)
      .send({ period: '2026-08', filing_type: 'MONTHLY' });
    expect(gstr1Res.status).toBe(201);
    expect(gstr1Res.body.data.return_period).toBe('2026-08');
  });

  it('Step 4: Generate GSTR-3B in M09', async () => {
    const gstr3bRes = await request(app)
      .post('/api/v1/gst/returns/gstr3b')
      .set('Authorization', `Bearer ${gstToken}`)
      .set('X-Company-Id', companyId)
      .send({ period: '2026-08' });
    expect(gstr3bRes.status).toBe(201);
    expect(gstr3bRes.body.data.tax_liability).toBeDefined();
  });

  it('Step 5: VERIFY GSTR-1 includes all B2B sales with correct HSN/tax', async () => {
    const gstr1 = await prisma.gst_return.findFirst({
      where: { company_id: companyId, return_type: 'GSTR1', return_period: '2026-08' }
    });
    expect(gstr1).toBeTruthy();
    const details = await prisma.gst_return_detail.findMany({ where: { return_id: gstr1?.id } });
    expect(details.length).toBeGreaterThanOrEqual(3); // 3 posted sales invoices

    // All should have HSN 8471 and 18% tax
    for (const d of details) {
      expect(d.hsn_code).toBe('8471');
      expect(parseFloat(d.tax_rate || '0')).toBe(18);
    }
  });

  it('Step 6: VERIFY GSTR-3B auto-calculates tax liability', async () => {
    const gstr3b = await prisma.gst_return.findFirst({
      where: { company_id: companyId, return_type: 'GSTR3B', return_period: '2026-08' }
    });
    expect(gstr3b).toBeTruthy();
    const liability = parseFloat(gstr3b?.tax_liability || '0');
    const inputTax = parseFloat(gstr3b?.input_tax_credit || '0');
    expect(liability).toBeGreaterThan(0);
    expect(inputTax).toBeGreaterThan(0);
    // Net tax = output - input
    expect(parseFloat(gstr3b?.net_tax_payable || '0')).toBeCloseTo(liability - inputTax, 2);
  });

  it('Step 7: VERIFY M17 report includes GST summary', async () => {
    const report = await request(app)
      .get('/api/v1/reports/gst-summary')
      .set('Authorization', `Bearer ${gstToken}`)
      .set('X-Company-Id', companyId)
      .query({ period: '2026-08' });
    expect(report.status).toBe(200);
    expect(report.body.data.total_output_tax).toBeGreaterThan(0);
    expect(report.body.data.total_input_tax).toBeGreaterThan(0);
  });

  it('ASSERT: Only posted invoices included', async () => {
    const gstr1Details = await prisma.gst_return_detail.findMany({
      where: {
        return: { company_id: companyId, return_type: 'GSTR1', return_period: '2026-08' }
      }
    });
    for (const d of gstr1Details) {
      const inv = await prisma.sales_invoice.findUnique({ where: { id: d.invoice_id } });
      expect(inv?.status).toBe('POSTED');
    }
  });

  it('ASSERT: Cancelled invoices excluded', async () => {
    const gstr1Details = await prisma.gst_return_detail.findMany({
      where: {
        return: { company_id: companyId, return_type: 'GSTR1', return_period: '2026-08' }
      }
    });
    const detailInvoiceIds = gstr1Details.map(d => d.invoice_id);
    const cancelledInv = await prisma.sales_invoice.findFirst({
      where: { company_id: companyId, status: 'CANCELLED' }
    });
    if (cancelledInv) {
      expect(detailInvoiceIds).not.toContain(cancelledInv.id);
    }
  });

  it('ASSERT: Tax amounts match invoice totals', async () => {
    const gstr3b = await prisma.gst_return.findFirst({
      where: { company_id: companyId, return_type: 'GSTR3B', return_period: '2026-08' }
    });
    const salesTotal = await prisma.sales_invoice.aggregate({
      where: { company_id: companyId, status: 'POSTED', invoice_date: { gte: new Date('2026-08-01'), lte: new Date('2026-08-31') } },
      _sum: { tax_amount: true }
    });
    expect(parseFloat(gstr3b?.output_tax || '0')).toBeCloseTo(parseFloat(salesTotal._sum.tax_amount || '0'), 2);
  });
});
