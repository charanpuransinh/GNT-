import { eventBus } from '../../src/lib/event-bus';
import { prisma } from '../../src/lib/prisma';

describe('EVENT BUS: Publishing, Consumption, Idempotency & DLQ', () => {
  beforeEach(async () => {
    await eventBus.clearTestEvents();
  });

  const testEvents = [
    {
      name: 'sales.invoice.created',
      publisher: 'M08',
      consumers: ['M06', 'M09', 'M10', 'M11', 'M16', 'M17', 'M19'],
      payload: { invoice_id: 'inv-test-001', customer_id: 'cust-001', total_amount: 11800 }
    },
    {
      name: 'purchase.invoice.approved',
      publisher: 'M07',
      consumers: ['M06', 'M09', 'M10', 'M11', 'M16', 'M19'],
      payload: { invoice_id: 'pi-test-001', supplier_id: 'sup-001', total_amount: 59000 }
    },
    {
      name: 'payment.received',
      publisher: 'M11',
      consumers: ['M08', 'M10', 'M05', 'M16', 'M19'],
      payload: { payment_id: 'pay-test-001', party_id: 'cust-001', amount: 5000 }
    },
    {
      name: 'stock.low',
      publisher: 'M06',
      consumers: ['M13', 'M16'],
      payload: { product_id: 'prod-test-001', current_quantity: 3, reorder_level: 10 }
    },
    {
      name: 'stock.updated',
      publisher: 'M06',
      consumers: ['M07', 'M08', 'M17'],
      payload: { product_id: 'prod-test-001', movement_type: 'IN', quantity: 100 }
    },
    {
      name: 'gst.einvoice.generated',
      publisher: 'M09',
      consumers: ['M08', 'M19'],
      payload: { invoice_id: 'inv-test-001', irn: 'ABC123XYZ', ack_no: '123456' }
    },
    {
      name: 'ledger.entry.created',
      publisher: 'M10',
      consumers: ['M17', 'M19'],
      payload: { entry_id: 'le-test-001', voucher_id: 'vch-001', amount: 10000 }
    }
  ];

  for (const evt of testEvents) {
    it(`Event "${evt.name}" published by ${evt.publisher} → consumed by [${evt.consumers.join(', ')}]`, async () => {
      await eventBus.publish(evt.name, evt.payload, { module: evt.publisher, idempotencyKey: `idmp-${evt.name}-001` });

      const published = await eventBus.getPublishedEvents();
      const found = published.find(e => e.name === evt.name);
      expect(found).toBeTruthy();
      expect(found?.publisher).toBe(evt.publisher);

      for (const consumer of evt.consumers) {
        const consumed = await eventBus.getConsumedEvents(consumer);
        const consumerEvent = consumed.find(e => e.name === evt.name);
        expect(consumerEvent).toBeTruthy();
        expect(consumerEvent?.status).toBe('SUCCESS');
      }
    });
  }

  it('All events have idempotency keys', async () => {
    for (const evt of testEvents) {
      const key = `idmp-${evt.name}-${Date.now()}`;
      await eventBus.publish(evt.name, evt.payload, { module: evt.publisher, idempotencyKey: key });

      const published = await eventBus.getPublishedEvents();
      const found = published.find(e => e.name === evt.name && e.idempotency_key === key);
      expect(found?.idempotency_key).toBe(key);
    }
  });

  it('Failed event handlers retry with backoff', async () => {
    // Simulate a consumer that fails twice then succeeds
    let attempts = 0;
    eventBus.registerConsumer('M06', 'stock.updated', async () => {
      attempts++;
      if (attempts < 3) throw new Error('Simulated failure');
      return { success: true };
    });

    await eventBus.publish('stock.updated', { product_id: 'retry-test' }, { module: 'M06', idempotencyKey: 'retry-001' });

    // Wait for retries
    await new Promise(r => setTimeout(r, 3000));

    const consumed = await eventBus.getConsumedEvents('M06');
    const evt = consumed.find(e => e.idempotency_key === 'retry-001');
    expect(evt?.attempt_count).toBe(3);
    expect(evt?.status).toBe('SUCCESS');
    expect(evt?.retry_delays_ms.length).toBe(2); // 2 retries before success
  });

  it('Dead letter queue captures persistent failures', async () => {
    eventBus.registerConsumer('M06', 'stock.updated', async () => {
      throw new Error('Persistent failure');
    });

    await eventBus.publish('stock.updated', { product_id: 'dlq-test' }, { module: 'M06', idempotencyKey: 'dlq-001' });

    await new Promise(r => setTimeout(r, 5000)); // Wait for max retries

    const dlqEntry = await prisma.event_dead_letter.findFirst({
      where: { event_name: 'stock.updated', idempotency_key: 'dlq-001' }
    });
    expect(dlqEntry).toBeTruthy();
    expect(dlqEntry?.failure_reason).toContain('Persistent failure');
    expect(dlqEntry?.retry_count).toBeGreaterThanOrEqual(3);
  });

  it('All published events have registered consumers', async () => {
    const registry = require('../../wiring-maps/event-registry/event-definitions.json');
    const allEvents = await eventBus.getPublishedEvents();

    for (const evt of allEvents) {
      const registered = registry.events.find((e: any) => e.name === evt.name);
      expect(registered).toBeTruthy();
      expect(registered.consumers.length).toBeGreaterThan(0);
    }
  });
});
