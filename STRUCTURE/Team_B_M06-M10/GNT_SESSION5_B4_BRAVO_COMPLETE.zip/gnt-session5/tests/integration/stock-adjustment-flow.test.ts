import request from 'supertest';
import { app } from '../../src/app';
import { prisma } from '../../src/lib/prisma';
import { generateToken } from '../helpers/auth';

describe('INTEGRATION: Stock Adjustment Flow (M06→M10→M19)', () => {
  let adminToken: string;
  let companyId: string;
  let productId: string;
  let adjustmentId: string;

  beforeAll(async () => {
    adminToken = generateToken({ userId: 'admin-1', role: 'admin', permissions: ['*'] });
    companyId = 'comp-test-004';

    const prodRes = await request(app)
      .post('/api/v1/inventory/products')
      .set('Authorization', `Bearer ${adminToken}`)
      .set('X-Company-Id', companyId)
      .send({ sku: 'TEST-PROD-004', name: 'Adjustment Test Item', category_id: 'cat-misc', unit: 'pcs', hsn_code: '9999', gst_slab_id: 'gst-5', reorder_level: 20, opening_stock: 100, valuation_method: 'WAC' });
    productId = prodRes.body.data.id;
  });

  it('Step 3: Create stock adjustment (increase) in M06', async () => {
    const adjRes = await request(app)
      .post('/api/v1/inventory/stock-adjustments')
      .set('Authorization', `Bearer ${adminToken}`)
      .set('X-Company-Id', companyId)
      .send({
        product_id: productId,
        warehouse_id: 'WH-MAIN-001',
        adjustment_type: 'INCREASE',
        quantity: 50,
        reason: 'Physical stock count surplus',
        valuation_rate: 200,
        notes: 'Annual stock audit adjustment'
      });
    expect(adjRes.status).toBe(201);
    adjustmentId = adjRes.body.data.id;
  });

  it('ASSERT: Adjustment reason mandatory', async () => {
    const failRes = await request(app)
      .post('/api/v1/inventory/stock-adjustments')
      .set('Authorization', `Bearer ${adminToken}`)
      .set('X-Company-Id', companyId)
      .send({
        product_id: productId,
        warehouse_id: 'WH-MAIN-001',
        adjustment_type: 'INCREASE',
        quantity: 10,
        reason: '',
        valuation_rate: 100
      });
    expect(failRes.status).toBe(400);
    expect(failRes.body.error.details).toContain('reason is required');
  });

  it('Step 4: VERIFY stock_movement record with reason', async () => {
    const movement = await prisma.stock_movement.findFirst({
      where: {
        company_id: companyId,
        reference_type: 'STOCK_ADJUSTMENT',
        reference_id: adjustmentId
      }
    });
    expect(movement).toBeTruthy();
    expect(movement?.quantity).toBe(50);
    expect(movement?.reason).toBe('Physical stock count surplus');
  });

  it('ASSERT: Before/after quantities recorded', async () => {
    const adjustment = await prisma.stock_adjustment.findUnique({ where: { id: adjustmentId } });
    expect(adjustment?.quantity_before).toBeDefined();
    expect(adjustment?.quantity_after).toBeDefined();
    expect(adjustment?.quantity_after - adjustment?.quantity_before).toBe(50);
  });

  it('Step 5: VERIFY M10 ledger entry if adjustment affects valuation', async () => {
    const entries = await prisma.ledger_entry.findMany({
      where: {
        company_id: companyId,
        reference_type: 'STOCK_ADJUSTMENT',
        reference_id: adjustmentId
      }
    });
    // Increase in stock value → Stock A/c Dr, Stock Adjustment A/c Cr
    expect(entries.length).toBeGreaterThanOrEqual(2);
  });

  it('Step 6: VERIFY M19 audit log entry', async () => {
    const audit = await prisma.audit_log.findFirst({
      where: {
        company_id: companyId,
        entity_type: 'STOCK_ADJUSTMENT',
        entity_id: adjustmentId,
        action: 'CREATE'
      }
    });
    expect(audit).toBeTruthy();
    expect(audit?.module).toBe('M06');
    expect(audit?.user_id).toBe('admin-1');
  });
});
