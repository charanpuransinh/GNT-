import request from 'supertest';
import { app } from '../../src/app';
import { prisma } from '../../src/lib/prisma';
import { eventBus } from '../../src/lib/event-bus';
import { generateToken } from '../helpers/auth';

describe('INTEGRATION: Payment Allocation Flow (M11→M08→M10→M05)', () => {
  let adminToken: string;
  let accountantToken: string;
  let companyId: string;
  let customerId: string;
  let productId: string;
  let invoiceId: string;
  let paymentId: string;

  beforeAll(async () => {
    adminToken = generateToken({ userId: 'admin-1', role: 'admin', permissions: ['*'] });
    accountantToken = generateToken({ userId: 'acc-1', role: 'accountant', permissions: ['payment_create', 'payment_allocate', 'ledger_view'] });
    companyId = 'comp-test-003';

    // Setup customer
    const custRes = await request(app)
      .post('/api/v1/parties/customers')
      .set('Authorization', `Bearer ${adminToken}`)
      .set('X-Company-Id', companyId)
      .send({ name: 'Payment Test Customer', gstin: '27AADCB2230M1ZT', contact: { email: 'ptc@test.com', phone: '7777777777' }, address: { line1: 'A', city: 'Delhi', state: 'DL', pincode: '110001' }, opening_balance: 0, credit_limit: 100000 });
    customerId = custRes.body.data.id;

    // Setup product
    const prodRes = await request(app)
      .post('/api/v1/inventory/products')
      .set('Authorization', `Bearer ${adminToken}`)
      .set('X-Company-Id', companyId)
      .send({ sku: 'TEST-PROD-003', name: 'Payment Test Item', category_id: 'cat-misc', unit: 'pcs', hsn_code: '9999', gst_slab_id: 'gst-18', reorder_level: 10, opening_stock: 1000, valuation_method: 'FIFO' });
    productId = prodRes.body.data.id;

    // Step 1: Create posted sales invoice (unpaid)
    const invRes = await request(app)
      .post('/api/v1/sales/invoices')
      .set('Authorization', `Bearer ${adminToken}`)
      .set('X-Company-Id', companyId)
      .send({ customer_id: customerId, invoice_date: '2026-08-01', due_date: '2026-08-31', items: [{ product_id: productId, quantity: 10, rate: 1000, discount: 0, tax_rate: 18 }] });
    invoiceId = invRes.body.data.id;
    await request(app).post(`/api/v1/sales/invoices/${invoiceId}/approve`).set('Authorization', `Bearer ${adminToken}`).set('X-Company-Id', companyId);
    await request(app).post(`/api/v1/sales/invoices/${invoiceId}/post`).set('Authorization', `Bearer ${adminToken}`).set('X-Company-Id', companyId);
  });

  it('Step 2: Record customer payment in M11', async () => {
    const paymentRes = await request(app)
      .post('/api/v1/payments/received')
      .set('Authorization', `Bearer ${accountantToken}`)
      .set('X-Company-Id', companyId)
      .send({
        party_id: customerId,
        amount: 5900, // Partial payment
        payment_date: '2026-08-15',
        mode: 'BANK_TRANSFER',
        bank_account_id: 'bank-001',
        reference_no: 'UTR123456'
      });
    expect(paymentRes.status).toBe(201);
    paymentId = paymentRes.body.data.id;
  });

  it('Step 3: Allocate payment to invoice', async () => {
    const allocRes = await request(app)
      .post(`/api/v1/payments/received/${paymentId}/allocate`)
      .set('Authorization', `Bearer ${accountantToken}`)
      .set('X-Company-Id', companyId)
      .send({
        allocations: [
          { invoice_type: 'SALES', invoice_id: invoiceId, amount: 5900 }
        ]
      });
    expect(allocRes.status).toBe(200);
  });

  it('ASSERT: Payment amount ≤ invoice balance', async () => {
    const invoice = await prisma.sales_invoice.findUnique({ where: { id: invoiceId } });
    const total = parseFloat(invoice?.total_amount || '0');
    const paid = parseFloat(invoice?.paid_amount || '0');
    expect(paid).toBeLessThanOrEqual(total);
  });

  it('ASSERT: Over-payment blocked or handled as advance', async () => {
    // Attempt over-payment
    const overPayRes = await request(app)
      .post('/api/v1/payments/received')
      .set('Authorization', `Bearer ${accountantToken}`)
      .set('X-Company-Id', companyId)
      .send({
        party_id: customerId,
        amount: 999999,
        payment_date: '2026-08-20',
        mode: 'CASH',
        reference_no: 'CASH-001'
      });
    // Should either block or create advance
    expect([201, 400, 422]).toContain(overPayRes.status);
    if (overPayRes.status === 201) {
      expect(overPayRes.body.data.is_advance).toBe(true);
    }
  });

  it('Step 4: VERIFY M10 ledger entry (Bank A/c Dr, Customer A/c Cr)', async () => {
    const entries = await prisma.ledger_entry.findMany({
      where: {
        company_id: companyId,
        reference_type: 'PAYMENT_RECEIVED',
        reference_id: paymentId
      }
    });
    const bankDr = entries.find(e => e.account_code.startsWith('BANK_') && e.debit_amount > 0);
    const customerCr = entries.find(e => e.account_code.startsWith('CUSTOMER_') && e.credit_amount > 0);
    expect(bankDr).toBeTruthy();
    expect(customerCr).toBeTruthy();
  });

  it('Step 5: VERIFY M08 invoice payment_status updated', async () => {
    const invoice = await prisma.sales_invoice.findUnique({ where: { id: invoiceId } });
    expect(invoice?.payment_status).toBe('PARTIAL'); // 5900 paid out of 11800 total
  });

  it('Step 6: VERIFY M05 party outstanding reduced', async () => {
    const party = await prisma.party.findUnique({ where: { id: customerId } });
    expect(parseFloat(party?.outstanding_amount || '0')).toBeGreaterThan(0);
    expect(parseFloat(party?.outstanding_amount || '0')).toBeLessThan(11800);
  });

  it('ASSERT: Event payment.received published and consumed', async () => {
    const events = await eventBus.getPublishedEvents();
    const paymentEvent = events.find(e => e.name === 'payment.received' && e.payload.payment_id === paymentId);
    expect(paymentEvent).toBeTruthy();
    expect(paymentEvent?.consumed_by).toContain('M08');
    expect(paymentEvent?.consumed_by).toContain('M10');
    expect(paymentEvent?.consumed_by).toContain('M05');
  });
});
