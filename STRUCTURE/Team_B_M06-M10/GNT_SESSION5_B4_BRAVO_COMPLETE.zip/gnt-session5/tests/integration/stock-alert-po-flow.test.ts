import request from 'supertest';
import { app } from '../../src/app';
import { prisma } from '../../src/lib/prisma';
import { eventBus } from '../../src/lib/event-bus';
import { generateToken } from '../helpers/auth';

describe('INTEGRATION: Low Stock→Auto PO Flow (M06→M13→M07)', () => {
  let adminToken: string;
  let companyId: string;
  let productId: string;
  let supplierId: string;

  beforeAll(async () => {
    adminToken = generateToken({ userId: 'admin-1', role: 'admin', permissions: ['*'] });
    companyId = 'comp-test-008';

    const supRes = await request(app).post('/api/v1/parties/suppliers').set('Authorization', `Bearer ${adminToken}`).set('X-Company-Id', companyId).send({
      name: 'Auto PO Supplier', gstin: '27AABCU9603R1ZX', contact: { email: 'apo@test.com', phone: '1111111111' },
      address: { line1: 'G', city: 'Indore', state: 'MP', pincode: '452001' }, opening_balance: 0, credit_limit: 100000
    });
    supplierId = supRes.body.data.id;

    // Step 1: Create product with reorder_level=10
    const prodRes = await request(app).post('/api/v1/inventory/products').set('Authorization', `Bearer ${adminToken}`).set('X-Company-Id', companyId).send({
      sku: 'AUTO-PROD-001', name: 'Auto Reorder Item', category_id: 'cat-misc', unit: 'pcs', hsn_code: '9999',
      gst_slab_id: 'gst-18', reorder_level: 10, opening_stock: 50, preferred_supplier_id: supplierId, valuation_method: 'FIFO'
    });
    productId = prodRes.body.data.id;
  });

  it('Step 2: Reduce stock below reorder_level', async () => {
    // Create sales invoice to deduct 45 units (leaving 5 < reorder_level 10)
    const custRes = await request(app).post('/api/v1/parties/customers').set('Authorization', `Bearer ${adminToken}`).set('X-Company-Id', companyId).send({
      name: 'Stock Alert Customer', gstin: '27AADCB2230M1ZT', contact: { email: 'sac@test.com', phone: '0000000000' },
      address: { line1: 'H', city: 'Jaipur', state: 'RJ', pincode: '302001' }, opening_balance: 0, credit_limit: 100000
    });
    const customerId = custRes.body.data.id;

    const invRes = await request(app).post('/api/v1/sales/invoices').set('Authorization', `Bearer ${adminToken}`).set('X-Company-Id', companyId).send({
      customer_id: customerId, invoice_date: '2026-08-24', due_date: '2026-09-24',
      items: [{ product_id: productId, quantity: 45, rate: 100, discount: 0, tax_rate: 18 }]
    });
    const invId = invRes.body.data.id;
    await request(app).post(`/api/v1/sales/invoices/${invId}/approve`).set('Authorization', `Bearer ${adminToken}`).set('X-Company-Id', companyId);
    await request(app).post(`/api/v1/sales/invoices/${invId}/post`).set('Authorization', `Bearer ${adminToken}`).set('X-Company-Id', companyId);

    // Verify stock is now below reorder
    const stock = await prisma.stock_master.findFirst({ where: { product_id: productId, company_id: companyId } });
    expect(parseFloat(stock?.quantity || '0')).toBeLessThan(10);
  });

  it('Step 3: VERIFY M06 emits stock.low event', async () => {
    const events = await eventBus.getPublishedEvents();
    const lowStockEvent = events.find(e => e.name === 'stock.low' && e.payload.product_id === productId);
    expect(lowStockEvent).toBeTruthy();
    expect(lowStockEvent?.payload.current_quantity).toBeLessThan(10);
    expect(lowStockEvent?.payload.reorder_level).toBe(10);
  });

  it('ASSERT: Event payload correct', async () => {
    const events = await eventBus.getPublishedEvents();
    const evt = events.find(e => e.name === 'stock.low' && e.payload.product_id === productId);
    expect(evt?.payload).toMatchObject({
      product_id: productId,
      company_id: companyId,
      reorder_level: 10,
      preferred_supplier_id: supplierId
    });
    expect(evt?.payload.current_quantity).toBeDefined();
    expect(evt?.idempotency_key).toBeTruthy();
  });

  it('Step 4: VERIFY M13 (Automation) receives event', async () => {
    const automationLog = await prisma.automation_log.findFirst({
      where: {
        company_id: companyId,
        trigger_event: 'stock.low',
        payload: { path: ['product_id'], equals: productId }
      }
    });
    expect(automationLog).toBeTruthy();
    expect(automationLog?.status).toBe('PROCESSED');
  });

  it('Step 5: VERIFY M13 creates purchase-order DRAFT in M07', async () => {
    const po = await prisma.purchase_order.findFirst({
      where: {
        company_id: companyId,
        source: 'AUTOMATION',
        status: 'DRAFT'
      }
    });
    expect(po).toBeTruthy();
    expect(po?.supplier_id).toBe(supplierId);

    const poItems = await prisma.purchase_order_item.findMany({ where: { order_id: po?.id } });
    expect(poItems.length).toBeGreaterThan(0);
    expect(poItems[0].product_id).toBe(productId);
    expect(poItems[0].quantity).toBeGreaterThan(0); // Should suggest reorder qty
  });

  it('ASSERT: PO draft created with correct supplier/product/qty', async () => {
    const po = await prisma.purchase_order.findFirst({
      where: { company_id: companyId, source: 'AUTOMATION' }
    });
    expect(po?.supplier_id).toBe(supplierId);
    const items = await prisma.purchase_order_item.findMany({ where: { order_id: po?.id } });
    const item = items.find(i => i.product_id === productId);
    expect(item).toBeTruthy();
    expect(item?.quantity).toBeGreaterThanOrEqual(10); // Reorder level or more
  });

  it('ASSERT: PO remains DRAFT (requires approval)', async () => {
    const po = await prisma.purchase_order.findFirst({
      where: { company_id: companyId, source: 'AUTOMATION' }
    });
    expect(po?.status).toBe('DRAFT');
    expect(po?.approved_by).toBeNull();
    expect(po?.approved_at).toBeNull();
  });

  it('Step 6: VERIFY M16 notification sent', async () => {
    const notification = await prisma.notification.findFirst({
      where: {
        company_id: companyId,
        module: 'M16',
        event_type: 'stock.low',
        entity_id: productId
      }
    });
    expect(notification).toBeTruthy();
    expect(notification?.channel).toBe('IN_APP');
    expect(notification?.status).toBe('SENT');
  });
});
