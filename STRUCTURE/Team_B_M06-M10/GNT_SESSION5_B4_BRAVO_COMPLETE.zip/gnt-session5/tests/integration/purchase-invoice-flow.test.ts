import request from 'supertest';
import { app } from '../../src/app';
import { prisma } from '../../src/lib/prisma';
import { eventBus } from '../../src/lib/event-bus';
import { generateToken } from '../helpers/auth';

describe('INTEGRATION: Purchase Invoice Complete Flow (M07→M06→M09→M10→M11)', () => {
  let adminToken: string;
  let purchaseClerkToken: string;
  let companyId: string;
  let supplierId: string;
  let productId: string;
  let invoiceId: string;

  beforeAll(async () => {
    adminToken = generateToken({ userId: 'admin-1', role: 'admin', permissions: ['*'] });
    purchaseClerkToken = generateToken({ userId: 'clerk-1', role: 'purchase_clerk', permissions: ['purchase_create', 'purchase_approve', 'purchase_post'] });
    companyId = 'comp-test-001';

    // Step 1: Create supplier in M05 via public API
    const supplierRes = await request(app)
      .post('/api/v1/parties/suppliers')
      .set('Authorization', `Bearer ${adminToken}`)
      .set('X-Company-Id', companyId)
      .send({
        name: 'Test Supplier Pvt Ltd',
        gstin: '27AABCU9603R1ZX',
        contact: { email: 'supplier@test.com', phone: '9999999999' },
        address: { line1: 'Test Street', city: 'Mumbai', state: 'MH', pincode: '400001' },
        opening_balance: 0,
        credit_limit: 500000
      });
    expect(supplierRes.status).toBe(201);
    supplierId = supplierRes.body.data.id;

    // Step 2: Create product in M06 via public API
    const productRes = await request(app)
      .post('/api/v1/inventory/products')
      .set('Authorization', `Bearer ${adminToken}`)
      .set('X-Company-Id', companyId)
      .send({
        sku: 'TEST-PROD-001',
        name: 'Test Widget',
        category_id: 'cat-electronics',
        unit: 'pcs',
        hsn_code: '8471',
        gst_slab_id: 'gst-18',
        reorder_level: 10,
        opening_stock: 0,
        valuation_method: 'FIFO'
      });
    expect(productRes.status).toBe(201);
    productId = productRes.body.data.id;
  });

  afterAll(async () => {
    await prisma.$disconnect();
  });

  it('Step 3-5: Create, Approve & Post Purchase Invoice in M07', async () => {
    // Create
    const createRes = await request(app)
      .post('/api/v1/purchase/invoices')
      .set('Authorization', `Bearer ${purchaseClerkToken}`)
      .set('X-Company-Id', companyId)
      .send({
        supplier_id: supplierId,
        invoice_date: '2026-08-24',
        due_date: '2026-09-24',
        items: [
          { product_id: productId, quantity: 100, rate: 500, discount: 0, tax_rate: 18 }
        ],
        notes: 'Test purchase invoice'
      });
    expect(createRes.status).toBe(201);
    invoiceId = createRes.body.data.id;
    expect(createRes.body.data.status).toBe('DRAFT');

    // Approve
    const approveRes = await request(app)
      .post(`/api/v1/purchase/invoices/${invoiceId}/approve`)
      .set('Authorization', `Bearer ${purchaseClerkToken}`)
      .set('X-Company-Id', companyId);
    expect(approveRes.status).toBe(200);
    expect(approveRes.body.data.status).toBe('APPROVED');

    // Post
    const postRes = await request(app)
      .post(`/api/v1/purchase/invoices/${invoiceId}/post`)
      .set('Authorization', `Bearer ${purchaseClerkToken}`)
      .set('X-Company-Id', companyId);
    expect(postRes.status).toBe(200);
    expect(postRes.body.data.status).toBe('POSTED');
  });

  it('Step 6: VERIFY M06 stock increased (stock_movement record exists)', async () => {
    const stockMovement = await prisma.stock_movement.findFirst({
      where: {
        company_id: companyId,
        reference_type: 'PURCHASE_INVOICE',
        reference_id: invoiceId,
        product_id: productId
      }
    });
    expect(stockMovement).toBeTruthy();
    expect(stockMovement?.quantity).toBe(100);
    expect(stockMovement?.movement_type).toBe('IN');
  });

  it('Step 7: VERIFY M09 GST transaction created (input tax recorded)', async () => {
    const gstTxn = await prisma.gst_transaction.findFirst({
      where: {
        company_id: companyId,
        reference_type: 'PURCHASE_INVOICE',
        reference_id: invoiceId
      }
    });
    expect(gstTxn).toBeTruthy();
    expect(gstTxn?.transaction_type).toBe('INPUT_TAX');
    expect(parseFloat(gstTxn?.cgst_amount || '0')).toBeGreaterThan(0);
    expect(parseFloat(gstTxn?.sgst_amount || '0')).toBeGreaterThan(0);
  });

  it('Step 8: VERIFY M10 ledger entries created (Purchase A/c Dr, Supplier A/c Cr)', async () => {
    const ledgerEntries = await prisma.ledger_entry.findMany({
      where: {
        company_id: companyId,
        reference_type: 'PURCHASE_INVOICE',
        reference_id: invoiceId
      }
    });
    expect(ledgerEntries.length).toBeGreaterThanOrEqual(2);

    const purchaseDr = ledgerEntries.find(e => e.account_code === 'PURCHASE_AC' && e.debit_amount > 0);
    const supplierCr = ledgerEntries.find(e => e.account_code.startsWith('SUPPLIER_') && e.credit_amount > 0);
    expect(purchaseDr).toBeTruthy();
    expect(supplierCr).toBeTruthy();
  });

  it('Step 9: VERIFY M11 payable created', async () => {
    const payable = await prisma.payable.findFirst({
      where: {
        company_id: companyId,
        reference_type: 'PURCHASE_INVOICE',
        reference_id: invoiceId
      }
    });
    expect(payable).toBeTruthy();
    expect(payable?.party_id).toBe(supplierId);
    expect(parseFloat(payable?.balance_amount || '0')).toBeGreaterThan(0);
  });

  it('Step 10: VERIFY Events published: purchase.invoice.approved, stock.updated', async () => {
    const events = await eventBus.getPublishedEvents();
    const approvedEvent = events.find(e => e.name === 'purchase.invoice.approved' && e.payload.invoice_id === invoiceId);
    const stockEvent = events.find(e => e.name === 'stock.updated' && e.payload.product_id === productId);
    expect(approvedEvent).toBeTruthy();
    expect(stockEvent).toBeTruthy();
    expect(approvedEvent?.idempotency_key).toBeTruthy();
  });

  it('ASSERT: No direct M07→M06 repository access (only public service)', async () => {
    // Verified by architecture linting rule: no module imports another module's repository
    const importCheck = require('../../scripts/verify-module-boundaries');
    const violations = importCheck.detectCrossModuleRepoImports();
    const m07ToM06 = violations.filter((v: any) => v.fromModule === 'M07' && v.toModule === 'M06');
    expect(m07ToM06.length).toBe(0);
  });

  it('ASSERT: Audit log entry exists in M19 (via event)', async () => {
    const auditLog = await prisma.audit_log.findFirst({
      where: {
        company_id: companyId,
        entity_type: 'PURCHASE_INVOICE',
        entity_id: invoiceId,
        action: 'POST'
      }
    });
    expect(auditLog).toBeTruthy();
    expect(auditLog?.module).toBe('M07');
  });
});
