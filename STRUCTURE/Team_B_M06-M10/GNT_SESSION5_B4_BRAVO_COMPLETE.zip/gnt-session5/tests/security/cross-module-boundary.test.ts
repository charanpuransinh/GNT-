import * as fs from 'fs';
import * as path from 'path';
import { globSync } from 'glob';

describe('SECURITY: Cross-Module Direct Access Blocked', () => {
  const srcDir = path.join(__dirname, '../../src');

  const forbiddenPatterns = [
    { from: 'M08', to: 'M06', pattern: /modules\/m08-sales\/.*\.ts/ },
    { from: 'M07', to: 'M10', pattern: /modules\/m07-purchase\/.*\.ts/ },
    { from: 'M09', to: 'M08', pattern: /modules\/m09-gst\/.*\.ts/ },
  ];

  it('M08 controller CANNOT import M06 stock.repository.ts', () => {
    const m08Files = globSync('modules/m08-sales/**/*.ts', { cwd: srcDir });
    for (const file of m08Files) {
      const content = fs.readFileSync(path.join(srcDir, file), 'utf-8');
      const hasDirectRepoImport = content.includes('m06-inventory/stock.repository') ||
        content.includes('m06-inventory/repositories/stock.repository');
      expect(hasDirectRepoImport).toBe(false);
    }
  });

  it('M07 service CANNOT import M10 ledger.repository.ts', () => {
    const m07Files = globSync('modules/m07-purchase/**/*.ts', { cwd: srcDir });
    for (const file of m07Files) {
      const content = fs.readFileSync(path.join(srcDir, file), 'utf-8');
      const hasDirectRepoImport = content.includes('m10-accounting/ledger.repository') ||
        content.includes('m10-accounting/repositories/ledger.repository');
      expect(hasDirectRepoImport).toBe(false);
    }
  });

  it('M09 controller CANNOT import M08 sales.repository.ts', () => {
    const m09Files = globSync('modules/m09-gst/**/*.ts', { cwd: srcDir });
    for (const file of m09Files) {
      const content = fs.readFileSync(path.join(srcDir, file), 'utf-8');
      const hasDirectRepoImport = content.includes('m08-sales/sales.repository') ||
        content.includes('m08-sales/repositories/sales.repository');
      expect(hasDirectRepoImport).toBe(false);
    }
  });

  it('Only public service imports allowed between modules', () => {
    const allModuleFiles = globSync('modules/**/*.ts', { cwd: srcDir });
    const publicServicePattern = /\.\/\.\.\/m\d{2}-\w+\/(public-service|services\/public)/;

    for (const file of allModuleFiles) {
      const content = fs.readFileSync(path.join(srcDir, file), 'utf-8');
      const moduleMatch = file.match(/modules\/(m\d{2}-\w+)/);
      if (!moduleMatch) continue;

      const currentModule = moduleMatch[1];
      const importLines = content.split('\n').filter(line => line.includes('from ') && line.includes('modules/'));

      for (const line of importLines) {
        const importedModule = line.match(/modules\/(m\d{2}-\w+)/)?.[1];
        if (importedModule && importedModule !== currentModule) {
          // Must be public service import
          const isPublic = line.includes('public-service') || line.includes('/public/') || line.includes('public.api');
          expect(isPublic).toBe(true);
        }
      }
    }
  });

  it('Direct Prisma queries to another module\'s table blocked by tenant middleware', async () => {
    // Tenant middleware injects company_id filter on all queries
    const middlewarePath = path.join(srcDir, 'middleware/tenant-isolation.middleware.ts');
    const content = fs.readFileSync(middlewarePath, 'utf-8');
    expect(content).toContain('company_id');
    expect(content).toContain('X-Company-Id');
  });
});
