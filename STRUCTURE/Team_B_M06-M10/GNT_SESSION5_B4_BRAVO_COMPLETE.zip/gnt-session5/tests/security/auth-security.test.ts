import request from 'supertest';
import { app } from '../../src/app';
import { generateToken, generateExpiredToken, generateInvalidToken } from '../helpers/auth';

describe('SECURITY: Authentication & Session', () => {
  let companyId = 'comp-auth-001';

  it('Invalid JWT returns 401', async () => {
    const res = await request(app)
      .get('/api/v1/inventory/products')
      .set('Authorization', 'Bearer invalidtoken123')
      .set('X-Company-Id', companyId);
    expect(res.status).toBe(401);
    expect(res.body.error.code).toBe('INVALID_TOKEN');
  });

  it('Expired JWT returns 401', async () => {
    const expiredToken = generateExpiredToken({ userId: 'user-1', role: 'admin' });
    const res = await request(app)
      .get('/api/v1/inventory/products')
      .set('Authorization', `Bearer ${expiredToken}`)
      .set('X-Company-Id', companyId);
    expect(res.status).toBe(401);
    expect(res.body.error.code).toBe('TOKEN_EXPIRED');
  });

  it('Missing JWT returns 401', async () => {
    const res = await request(app)
      .get('/api/v1/inventory/products')
      .set('X-Company-Id', companyId);
    expect(res.status).toBe(401);
    expect(res.body.error.code).toBe('MISSING_TOKEN');
  });

  it('Refresh token rotation works', async () => {
    const loginRes = await request(app)
      .post('/api/v1/auth/login')
      .send({ email: 'test@example.com', password: 'SecurePass123!' });
    expect(loginRes.status).toBe(200);
    const refreshToken = loginRes.body.data.refresh_token;

    // Use refresh token
    const refreshRes = await request(app)
      .post('/api/v1/auth/refresh')
      .send({ refresh_token: refreshToken });
    expect(refreshRes.status).toBe(200);
    expect(refreshRes.body.data.access_token).toBeTruthy();
    expect(refreshRes.body.data.refresh_token).not.toBe(refreshToken); // Rotated
  });

  it('Logout invalidates session', async () => {
    const token = generateToken({ userId: 'user-1', role: 'admin', permissions: ['*'] });

    const logoutRes = await request(app)
      .post('/api/v1/auth/logout')
      .set('Authorization', `Bearer ${token}`);
    expect(logoutRes.status).toBe(200);

    // Token should now be blacklisted
    const afterLogout = await request(app)
      .get('/api/v1/inventory/products')
      .set('Authorization', `Bearer ${token}`)
      .set('X-Company-Id', companyId);
    expect(afterLogout.status).toBe(401);
    expect(afterLogout.body.error.code).toBe('TOKEN_REVOKED');
  });

  it('Rate limiting blocks brute force', async () => {
    // Attempt multiple failed logins
    for (let i = 0; i < 10; i++) {
      await request(app)
        .post('/api/v1/auth/login')
        .send({ email: 'test@example.com', password: 'wrongpassword' });
    }

    // Next attempt should be rate limited
    const res = await request(app)
      .post('/api/v1/auth/login')
      .send({ email: 'test@example.com', password: 'wrongpassword' });
    expect(res.status).toBe(429);
    expect(res.body.error.code).toBe('RATE_LIMIT_EXCEEDED');
  });
});
