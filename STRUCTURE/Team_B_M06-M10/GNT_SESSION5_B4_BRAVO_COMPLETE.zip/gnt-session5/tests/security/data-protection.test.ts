import request from 'supertest';
import { app } from '../../src/app';
import { prisma } from '../../src/lib/prisma';
import { generateToken } from '../helpers/auth';
import * as bcrypt from 'bcrypt';

describe('SECURITY: Data Protection', () => {
  let adminToken = generateToken({ userId: 'admin-1', role: 'admin', permissions: ['*'] });
  let companyId = 'comp-dp-001';

  it('Passwords hashed (not plaintext)', async () => {
    const user = await prisma.user.create({
      data: {
        id: 'user-dp-001',
        email: 'dp@test.com',
        password: 'PlainPassword123!', // Service should hash this
        role: 'user',
        company_id: companyId
      }
    });
    const stored = await prisma.user.findUnique({ where: { id: 'user-dp-001' } });
    expect(stored?.password).not.toBe('PlainPassword123!');
    expect(stored?.password).toContain('$2'); // bcrypt hash prefix
    const isHash = await bcrypt.compare('PlainPassword123!', stored?.password || '');
    expect(isHash).toBe(true);
  });

  it('Bank account numbers masked in API responses', async () => {
    await prisma.bank_account.create({
      data: {
        id: 'bank-dp-001',
        company_id: companyId,
        account_name: 'Test Bank',
        account_number: '123456789012',
        ifsc: 'TEST0001234',
        branch: 'Main'
      }
    });

    const res = await request(app)
      .get('/api/v1/accounting/bank-accounts')
      .set('Authorization', `Bearer ${adminToken}`)
      .set('X-Company-Id', companyId);
    expect(res.status).toBe(200);
    const bank = res.body.data.find((b: any) => b.id === 'bank-dp-001');
    expect(bank.account_number).not.toBe('123456789012');
    expect(bank.account_number).toMatch(/\*{6,}/); // Masked with asterisks
  });

  it('GSTIN visible only to authorized users', async () => {
    await prisma.party.create({
      data: {
        id: 'party-dp-001',
        company_id: companyId,
        name: 'GST Test Party',
        gstin: '27AABCU9603R1ZX',
        party_type: 'SUPPLIER'
      }
    });

    // Admin can see GSTIN
    const adminRes = await request(app)
      .get('/api/v1/parties/suppliers/party-dp-001')
      .set('Authorization', `Bearer ${adminToken}`)
      .set('X-Company-Id', companyId);
    expect(adminRes.body.data.gstin).toBe('27AABCU9603R1ZX');

    // Unauthorized user gets masked GSTIN
    const userToken = generateToken({ userId: 'user-dp', role: 'clerk', permissions: ['sales_create'] });
    const userRes = await request(app)
      .get('/api/v1/parties/suppliers/party-dp-001')
      .set('Authorization', `Bearer ${userToken}`)
      .set('X-Company-Id', companyId);
    expect(userRes.body.data.gstin).toMatch(/\*{4,}/);
  });

  it('No sensitive data in logs', async () => {
    const logPath = '/var/log/gnt/application.log';
    const fs = require('fs');
    if (fs.existsSync(logPath)) {
      const logs = fs.readFileSync(logPath, 'utf-8');
      expect(logs).not.toContain('password');
      expect(logs).not.toContain('credit_card');
      expect(logs).not.toContain('cvv');
      expect(logs).not.toMatch(/\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b/); // No card numbers
    }
  });

  it('SQL injection attempts blocked', async () => {
    const maliciousInputs = [
      "'; DROP TABLE users; --",
      "1' OR '1'='1",
      "1; DELETE FROM products WHERE '1'='1",
      "' UNION SELECT * FROM passwords --"
    ];

    for (const payload of maliciousInputs) {
      const res = await request(app)
        .get('/api/v1/inventory/products')
        .set('Authorization', `Bearer ${adminToken}`)
        .set('X-Company-Id', companyId)
        .query({ search: payload });

      // Should not crash or expose DB structure
      expect([200, 400, 422]).toContain(res.status);
      expect(res.body.error?.details).not.toContain('SQL');
      expect(res.body.error?.details).not.toContain('syntax');
    }
  });
});
