import request from 'supertest';
import { app } from '../../src/app';
import { generateToken } from '../helpers/auth';

describe('SECURITY: RBAC & Permission Tests', () => {
  let companyId = 'comp-sec-001';

  it('User without purchase_create permission cannot POST /purchase/invoices', async () => {
    const token = generateToken({ userId: 'user-1', role: 'viewer', permissions: ['sales_view'] });
    const res = await request(app)
      .post('/api/v1/purchase/invoices')
      .set('Authorization', `Bearer ${token}`)
      .set('X-Company-Id', companyId)
      .send({ supplier_id: 'sup-001', items: [] });
    expect(res.status).toBe(403);
    expect(res.body.error.code).toBe('INSUFFICIENT_PERMISSIONS');
  });

  it('User without sales_post permission cannot POST /sales/invoices/:id/post', async () => {
    const token = generateToken({ userId: 'user-2', role: 'sales_clerk', permissions: ['sales_create', 'sales_view'] });
    const res = await request(app)
      .post('/api/v1/sales/invoices/inv-001/post')
      .set('Authorization', `Bearer ${token}`)
      .set('X-Company-Id', companyId);
    expect(res.status).toBe(403);
  });

  it('User without accounting_view permission cannot GET /accounting/ledger', async () => {
    const token = generateToken({ userId: 'user-3', role: 'sales_exec', permissions: ['sales_create', 'sales_post'] });
    const res = await request(app)
      .get('/api/v1/accounting/ledger')
      .set('Authorization', `Bearer ${token}`)
      .set('X-Company-Id', companyId);
    expect(res.status).toBe(403);
  });

  it('User without gst_admin permission cannot POST /gst/tax-slabs', async () => {
    const token = generateToken({ userId: 'user-4', role: 'accountant', permissions: ['accounting_view', 'voucher_create'] });
    const res = await request(app)
      .post('/api/v1/gst/tax-slabs')
      .set('Authorization', `Bearer ${token}`)
      .set('X-Company-Id', companyId)
      .send({ name: '28%', cgst: 14, sgst: 14, igst: 28 });
    expect(res.status).toBe(403);
  });

  it('Manager can approve invoices; clerk cannot', async () => {
    const managerToken = generateToken({ userId: 'mgr-1', role: 'manager', permissions: ['purchase_approve', 'sales_approve'] });
    const clerkToken = generateToken({ userId: 'clk-1', role: 'clerk', permissions: ['purchase_create', 'sales_create'] });

    const mgrRes = await request(app)
      .post('/api/v1/purchase/invoices/inv-001/approve')
      .set('Authorization', `Bearer ${managerToken}`)
      .set('X-Company-Id', companyId);
    // May be 200 or 404, but NOT 403
    expect(mgrRes.status).not.toBe(403);

    const clkRes = await request(app)
      .post('/api/v1/purchase/invoices/inv-001/approve')
      .set('Authorization', `Bearer ${clerkToken}`)
      .set('X-Company-Id', companyId);
    expect(clkRes.status).toBe(403);
  });

  it('Admin can delete; user cannot', async () => {
    const adminToken = generateToken({ userId: 'adm-1', role: 'admin', permissions: ['*'] });
    const userToken = generateToken({ userId: 'usr-1', role: 'user', permissions: ['sales_view', 'purchase_view'] });

    const adminRes = await request(app)
      .delete('/api/v1/sales/invoices/inv-001')
      .set('Authorization', `Bearer ${adminToken}`)
      .set('X-Company-Id', companyId);
    expect(adminRes.status).not.toBe(403);

    const userRes = await request(app)
      .delete('/api/v1/sales/invoices/inv-001')
      .set('Authorization', `Bearer ${userToken}`)
      .set('X-Company-Id', companyId);
    expect(userRes.status).toBe(403);
  });
});
