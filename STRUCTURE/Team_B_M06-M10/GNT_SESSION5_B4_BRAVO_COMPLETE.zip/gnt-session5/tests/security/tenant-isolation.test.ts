import request from 'supertest';
import { app } from '../../src/app';
import { prisma } from '../../src/lib/prisma';
import { generateToken } from '../helpers/auth';

describe('SECURITY: Multi-Tenant Isolation', () => {
  let companyA = 'comp-tenant-A';
  let companyB = 'comp-tenant-B';
  let adminToken = generateToken({ userId: 'admin-1', role: 'admin', permissions: ['*'] });

  beforeAll(async () => {
    // Seed data for both companies
    await prisma.product_master.createMany({
      data: [
        { id: 'prod-A-001', company_id: companyA, sku: 'A-001', name: 'Product A', unit: 'pcs', hsn_code: '9999' },
        { id: 'prod-B-001', company_id: companyB, sku: 'B-001', name: 'Product B', unit: 'pcs', hsn_code: '9999' }
      ]
    });
  });

  it('Company A user cannot see Company B products', async () => {
    const res = await request(app)
      .get('/api/v1/inventory/products')
      .set('Authorization', `Bearer ${adminToken}`)
      .set('X-Company-Id', companyA);
    expect(res.status).toBe(200);
    expect(res.body.data.some((p: any) => p.id === 'prod-B-001')).toBe(false);
    expect(res.body.data.some((p: any) => p.id === 'prod-A-001')).toBe(true);
  });

  it('Company A user cannot see Company B invoices', async () => {
    // Create invoice for Company B
    await prisma.sales_invoice.create({
      data: { id: 'inv-B-001', company_id: companyB, customer_id: 'cust-B', invoice_no: 'INV-B-001', invoice_date: new Date(), total_amount: '1000', status: 'POSTED' }
    });

    const res = await request(app)
      .get('/api/v1/sales/invoices')
      .set('Authorization', `Bearer ${adminToken}`)
      .set('X-Company-Id', companyA);
    expect(res.status).toBe(200);
    expect(res.body.data.some((i: any) => i.id === 'inv-B-001')).toBe(false);
  });

  it('Cross-company API calls return 403', async () => {
    // Attempt to access Company B resource with Company A context
    const res = await request(app)
      .get('/api/v1/sales/invoices/inv-B-001')
      .set('Authorization', `Bearer ${adminToken}`)
      .set('X-Company-Id', companyA);
    expect([403, 404]).toContain(res.status);
  });

  it('Tenant middleware injects correct company_id', async () => {
    const res = await request(app)
      .get('/api/v1/inventory/products')
      .set('Authorization', `Bearer ${adminToken}`)
      .set('X-Company-Id', companyA);
    expect(res.status).toBe(200);
    // All returned items should have company_id = companyA
    for (const item of res.body.data) {
      expect(item.company_id).toBe(companyA);
    }
  });

  it('Missing X-Company-Id header returns 400', async () => {
    const res = await request(app)
      .get('/api/v1/inventory/products')
      .set('Authorization', `Bearer ${adminToken}`);
    expect(res.status).toBe(400);
    expect(res.body.error.code).toBe('MISSING_COMPANY_ID');
  });
});
