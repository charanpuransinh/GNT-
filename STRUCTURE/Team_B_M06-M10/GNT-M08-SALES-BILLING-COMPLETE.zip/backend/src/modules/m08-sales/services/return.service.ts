/**
 * M08 SALES & BILLING — Sales Return Service
 * Module: m08-sales | Team: B4-BRAVO
 */

import { PrismaClient, SalesReturn } from '@prisma/client';
import { returnRepository } from '../repositories/return.repository';
import { salesRepository } from '../repositories/sales.repository';
import {
  SalesReturnDTO,
  ReturnQueryParams,
  SalesReturnCreatedEvent,
} from '../types/sales.types';
import { calculateReturnTotals, generateReturnNumber } from './sales.internal';
import { eventBus } from '../../../core/event-bus';

const prisma = new PrismaClient();

interface StockService {
  addBackStock(items: Array<{ productId: string; quantity: number }>, branchId: string): Promise<void>;
}
interface GstService {
  calculateTax(items: Array<{ hsnCode: string; amount: number; taxRate: number }>, customerState: string, companyState: string): Promise<any>;
}
interface LedgerService {
  createEntry(entry: any): Promise<void>;
}

let stockService: StockService;
let gstService: GstService;
let ledgerService: LedgerService;

export function injectReturnDependencies(deps: {
  stockService: StockService;
  gstService: GstService;
  ledgerService: LedgerService;
}) {
  stockService = deps.stockService;
  gstService = deps.gstService;
  ledgerService = deps.ledgerService;
}

export class ReturnService {
  // ─── CREATE RETURN ───
  async createReturn(dto: SalesReturnDTO): Promise<SalesReturn> {
    const invoice = await salesRepository.getInvoiceById(dto.salesInvoiceId, dto.companyId);
    if (!invoice) throw new Error('Original sales invoice not found');

    const totals = calculateReturnTotals(dto.items);
    const returnNumber = dto.returnNumber || await returnRepository.getNextReturnNumber(dto.companyId);

    const returnData = {
      companyId: dto.companyId,
      salesInvoiceId: dto.salesInvoiceId,
      customerId: dto.customerId,
      returnNumber,
      returnDate: new Date(dto.returnDate),
      totalAmount: totals.totalAmount,
      taxAmount: totals.totalTax,
      netAmount: totals.netAmount,
      reason: dto.reason || null,
      status: 'draft' as const,
      items: dto.items.map((item) => ({
        productId: item.productId,
        quantity: Number(item.quantity),
        rate: Number(item.rate),
        amount: Number((item as any).amount),
        taxAmount: Number((item as any).taxAmount),
        netAmount: Number((item as any).netAmount),
      })),
    };

    return returnRepository.createReturn(returnData as any);
  }

  // ─── GET RETURNS ───
  async getReturns(params: ReturnQueryParams): Promise<{ data: SalesReturn[]; total: number }> {
    return returnRepository.getReturns(params);
  }

  // ─── GET RETURN BY ID ───
  async getReturnById(id: string, companyId: string): Promise<SalesReturn & { items: any[] } | null> {
    return returnRepository.getReturnById(id, companyId);
  }

  // ─── APPROVE RETURN ───
  async approveReturn(id: string, companyId: string): Promise<SalesReturn> {
    const salesReturn = await returnRepository.getReturnById(id, companyId);
    if (!salesReturn) throw new Error('Return not found');
    if (salesReturn.status !== 'draft') throw new Error('Only draft returns can be approved');

    return returnRepository.updateReturnStatus(id, companyId, 'approved');
  }

  // ─── POST RETURN (ATOMIC — triggers stock add-back + GST reversal + ledger reversal) ───
  async postReturn(id: string, companyId: string): Promise<SalesReturn> {
    const salesReturn = await returnRepository.getReturnById(id, companyId);
    if (!salesReturn) throw new Error('Return not found');
    if (salesReturn.status !== 'approved') throw new Error('Return must be approved before posting');

    const invoice = await salesRepository.getInvoiceById(salesReturn.salesInvoiceId, companyId);
    if (!invoice) throw new Error('Original invoice not found');

    await prisma.$transaction(async (tx) => {
      // a. Add back stock (M06)
      if (stockService) {
        const stockItems = salesReturn.items.map((i: any) => ({
          productId: i.productId,
          quantity: Number(i.quantity),
        }));
        await stockService.addBackStock(stockItems, invoice.branchId);
      }

      // b. GST reversal (M09)
      if (gstService) {
        const gstItems = salesReturn.items.map((i: any) => ({
          hsnCode: '',
          amount: Number(i.amount),
          taxRate: 18, // Simplified
        }));
        await gstService.calculateTax(gstItems, 'CUSTOMER_STATE', 'COMPANY_STATE');
      }

      // c. Ledger reversal (M10)
      if (ledgerService) {
        await ledgerService.createEntry({
          returnId: salesReturn.id,
          customerId: salesReturn.customerId,
          amount: Number(salesReturn.netAmount),
          type: 'SALES_RETURN',
          date: new Date(),
        });
      }

      // d. Update return status
      await tx.salesReturn.update({
        where: { id },
        data: { status: 'posted' },
      });
    });

    // Publish event
    const eventPayload: SalesReturnCreatedEvent = {
      returnId: salesReturn.id,
      invoiceId: salesReturn.salesInvoiceId,
      customerId: salesReturn.customerId,
      netAmount: Number(salesReturn.netAmount),
      companyId: salesReturn.companyId,
    };
    eventBus.publish('sales.return.created', eventPayload);

    return returnRepository.getReturnById(id, companyId) as Promise<any>;
  }
}

export const returnService = new ReturnService();
