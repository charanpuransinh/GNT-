// ============================================================================
// M07 PURCHASE MANAGEMENT — OCR Service (M07 OWNS THIS FEATURE)
// ============================================================================

import { OCRResultDTO, OCRProposedFieldDTO, OCRProposedItemDTO } from '../types/purchase.types';
import { parseOCRText } from './purchase.internal';

export class OCRService {
  /**
   * Process uploaded bill image and return proposed structured data
   * In production: Integrate with Tesseract.js, Google Vision, or AWS Textract
   */
  async processImage(imageBuffer: Buffer): Promise<OCRResultDTO> {
    // Mock OCR processing — in production, call actual OCR engine
    const mockRawText = this.mockOCRText();
    const parsed = parseOCRText(mockRawText);

    return this.buildOCRResult(parsed);
  }

  /**
   * Build structured OCR result with confidence scores per field
   */
  private buildOCRResult(parsed: ReturnType<typeof parseOCRText>): OCRResultDTO {
    const buildField = (field: string, value: string | number | Date, confidence: number): OCRProposedFieldDTO => ({
      field,
      value,
      confidence,
      accepted: false, // MANDATORY: User must review and approve
    });

    const buildItem = (item: { product_name: string; quantity: number; rate: number; amount: number }, confidence: number): OCRProposedItemDTO => ({
      product_name: item.product_name,
      quantity: item.quantity,
      rate: item.rate,
      amount: item.amount,
      confidence,
      accepted: false,
    });

    return {
      supplier_name: buildField('supplier_name', parsed.supplier_name, parsed.confidence > 20 ? 85 : 45),
      invoice_number: buildField('invoice_number', parsed.invoice_number, parsed.confidence > 20 ? 90 : 50),
      invoice_date: buildField('invoice_date', new Date(parsed.invoice_date), parsed.confidence > 20 ? 88 : 55),
      total_amount: buildField('total_amount', parsed.total_amount, parsed.confidence > 20 ? 92 : 60),
      total_tax: buildField('total_tax', parsed.total_tax, parsed.confidence > 20 ? 80 : 40),
      items: parsed.items.map((item, idx) => buildItem(item, 75 + (idx % 3) * 5)),
      overall_confidence: parsed.confidence,
    };
  }

  /**
   * Validate that all fields have been reviewed and accepted
   * MANDATORY per business rules — no auto-posting
   */
  validateOCRReview(ocrResult: OCRResultDTO): { valid: boolean; errors: string[] } {
    const errors: string[] = [];

    const requiredFields: (keyof OCRResultDTO)[] = ['supplier_name', 'invoice_number', 'invoice_date', 'total_amount'];
    for (const field of requiredFields) {
      const fieldData = ocrResult[field] as OCRProposedFieldDTO | undefined;
      if (!fieldData || !fieldData.accepted) {
        errors.push(`Field "${field}" must be reviewed and accepted`);
      }
    }

    if (ocrResult.items.length === 0) {
      errors.push('At least one item must be extracted');
    }

    for (let i = 0; i < ocrResult.items.length; i++) {
      if (!ocrResult.items[i].accepted) {
        errors.push(`Item ${i + 1} must be reviewed and accepted`);
      }
    }

    return { valid: errors.length === 0, errors };
  }

  private mockOCRText(): string {
    return `
SUPPLIER: ABC TRADERS PVT LTD
Invoice #: INV-2024-00123
Date: 15/08/2024

Item          Qty    Rate    Amount
Widget A      10     150.00  1500.00
Widget B      5      200.00  1000.00

Subtotal: 2500.00
Tax (18%): 450.00
Total: 2950.00
    `.trim();
  }
}
