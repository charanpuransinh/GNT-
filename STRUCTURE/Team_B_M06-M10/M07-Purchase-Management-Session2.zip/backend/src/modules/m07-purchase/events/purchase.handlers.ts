// ============================================================================
// M07 PURCHASE MANAGEMENT — Event Handlers
// ============================================================================

import { PURCHASE_EVENTS, EventPayload } from './purchase.events';
import { PurchaseInvoiceApprovedEvent, PurchaseOrderCreatedEvent } from '../types/purchase.types';

// ─── External Service Stubs (Wiring Contracts) ───
// These are PUBLIC API calls to other modules per wiring map

interface StockService {
  addStock(data: { product_id: string; quantity: number; rate: number; batch_id?: string; reference: string }): Promise<void>;
  deductStock(data: { product_id: string; quantity: number; reference: string }): Promise<void>;
}

interface GSTService {
  calculateInputTax(data: { invoice_id: string; items: Array<{ product_id: string; tax_amount: number; hsn_code?: string }> }): Promise<void>;
  reverseInputTax(data: { return_id: string; items: Array<{ product_id: string; tax_amount: number }> }): Promise<void>;
}

interface LedgerService {
  createPurchaseEntry(data: { invoice_id: string; supplier_id: string; amount: number; tax_amount: number; reference: string }): Promise<void>;
  createPurchaseReturnEntry(data: { return_id: string; supplier_id: string; amount: number; tax_amount: number; reference: string }): Promise<void>;
}

interface EventBus {
  publish(event: string, payload: unknown): Promise<void>;
}

// ─── Handler Registry ───

export class PurchaseEventHandlers {
  constructor(
    private stockService: StockService,
    private gstService: GSTService,
    private ledgerService: LedgerService,
    private eventBus: EventBus,
  ) {}

  async handleInvoiceApproved(payload: EventPayload<PurchaseInvoiceApprovedEvent>): Promise<void> {
    console.log(`[M07] Handling ${PURCHASE_EVENTS.INVOICE_APPROVED} for invoice ${payload.payload.invoice_id}`);
    // Approval workflow complete — ready for posting
    // No stock/ledger impact yet — that happens on POST
  }

  async handleInvoicePosted(payload: EventPayload<PurchaseInvoiceApprovedEvent>): Promise<void> {
    console.log(`[M07] Handling ${PURCHASE_EVENTS.INVOICE_POSTED} for invoice ${payload.payload.invoice_id}`);

    const { invoice_id, items, supplier_id, total_amount, tax_amount } = payload.payload;

    // 1. Stock Update via M06 PUBLIC API
    for (const item of items) {
      await this.stockService.addStock({
        product_id: item.product_id,
        quantity: item.quantity,
        rate: item.rate,
        reference: `PI-${invoice_id}`,
      });
    }

    // 2. GST Input Tax via M09 PUBLIC API
    await this.gstService.calculateInputTax({
      invoice_id,
      items: items.map(i => ({ product_id: i.product_id, tax_amount: i.tax_amount, hsn_code: undefined })),
    });

    // 3. Ledger Entry via M10 PUBLIC API (through Central Transaction Engine)
    await this.ledgerService.createPurchaseEntry({
      invoice_id,
      supplier_id,
      amount: total_amount,
      tax_amount,
      reference: `PI-${invoice_id}`,
    });

    console.log(`[M07] Invoice ${invoice_id} posted successfully — stock, GST, ledger updated`);
  }

  async handleOrderCreated(payload: EventPayload<PurchaseOrderCreatedEvent>): Promise<void> {
    console.log(`[M07] Handling ${PURCHASE_EVENTS.ORDER_CREATED} for PO ${payload.payload.po_id}`);
    // PO created — no immediate stock/ledger impact
    // M17 (Reporting) may consume this event
  }

  async handleReturnPosted(payload: EventPayload<unknown>): Promise<void> {
    console.log(`[M07] Handling purchase return posted`);
    // Reverse stock, reverse GST input, reverse ledger
    // Implementation similar to invoice posted but with deductions
  }
}

// ─── Factory ───
export function createPurchaseEventHandlers(
  stockService: StockService,
  gstService: GSTService,
  ledgerService: LedgerService,
  eventBus: EventBus,
): PurchaseEventHandlers {
  return new PurchaseEventHandlers(stockService, gstService, ledgerService, eventBus);
}
