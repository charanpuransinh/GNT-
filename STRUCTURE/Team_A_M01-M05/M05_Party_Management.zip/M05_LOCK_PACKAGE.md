# M05 — PARTY MANAGEMENT — LOCK PACKAGE

## Module Info
- **Module ID:** M05
- **Name:** Party Management
- **Owner:** Team A4-APPLE (M01-M05)
- **Status:** READY FOR LOCK

## File Registry (30 files)
- Frontend: 13 (3 pages, 4 components, 2 services, 1 store, 1 schema, 1 routes, 1 index)
- Backend: 11 (1 controller, 2 services, 1 repository, 1 model, 1 schema, 1 routes, 2 events, 1 types, 1 index)
- API: 2 (contract YAML, wiring JSON)
- Database: 1 (party_master, party_ledger_view)
- Tests: 3 (unit, integration, API)

## Database Ownership
- **party_master** — M05 OWNER (CANONICAL)
- **party_ledger_view** — M05 OWNER (CANONICAL, populated via M10 public contract)

## Cross-Module
- ✅ M05 -> M02 auth (public)
- ✅ M05 -> M04 tenant (public)
- ✅ M05 -> M10 ledger.service PUBLIC
- ✅ M05 -> M19 audit (event)
- ❌ M05 -> M06/M07/M08 repository — FORBIDDEN

## Events
- Publishes: `party.created`, `party.updated`, `party.deleted`, `party.outstanding.changed`

## Lock Checklist
- [x] Module Contract
- [x] Repository Map
- [x] File Registry
- [x] Database Map
- [x] Database Registry
- [x] Dependency Map
- [x] Wiring Map
- [x] Wiring Registry
- [x] API Contract
- [x] Integration Contract
- [x] Security Contract
- [ ] Test Report (PENDING)
- [x] Change Log
- [x] Version: 1.0.0
- [ ] Lock Status: PENDING VERIFICATION
