-- M05 PARTY MANAGEMENT — DATABASE SCHEMA
-- Owner: Team A (M01-M05)
-- Tables: party_master, party_ledger_view

CREATE TABLE party_master (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    company_id UUID NOT NULL REFERENCES company_master(id) ON DELETE CASCADE,
    name VARCHAR(200) NOT NULL,
    type VARCHAR(20) NOT NULL CHECK (type IN ('customer', 'supplier')),
    phone VARCHAR(20),
    email VARCHAR(255),
    gstin VARCHAR(15),
    address TEXT,
    credit_limit DECIMAL(15,2) NOT NULL DEFAULT 0,
    outstanding DECIMAL(15,2) NOT NULL DEFAULT 0,
    is_active BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMPTZ
);

CREATE INDEX idx_party_company ON party_master(company_id);
CREATE INDEX idx_party_type ON party_master(type);
CREATE INDEX idx_party_name ON party_master(name);
CREATE INDEX idx_party_gstin ON party_master(gstin);
CREATE INDEX idx_party_active ON party_master(is_active) WHERE deleted_at IS NULL;

-- party_ledger_view: owned by M05, populated via M10 public contract / events
CREATE TABLE party_ledger_view (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    party_id UUID NOT NULL REFERENCES party_master(id) ON DELETE CASCADE,
    company_id UUID NOT NULL REFERENCES company_master(id) ON DELETE CASCADE,
    voucher_type VARCHAR(50) NOT NULL,
    voucher_no VARCHAR(100) NOT NULL,
    date DATE NOT NULL,
    debit DECIMAL(15,2) NOT NULL DEFAULT 0,
    credit DECIMAL(15,2) NOT NULL DEFAULT 0,
    balance DECIMAL(15,2) NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_ledger_party ON party_ledger_view(party_id);
CREATE INDEX idx_ledger_company ON party_ledger_view(company_id);
CREATE INDEX idx_ledger_date ON party_ledger_view(date);

-- RLS
ALTER TABLE party_master ENABLE ROW LEVEL SECURITY;
ALTER TABLE party_ledger_view ENABLE ROW LEVEL SECURITY;

CREATE POLICY party_tenant ON party_master USING (company_id = current_setting('app.current_company_id')::UUID);
CREATE POLICY ledger_tenant ON party_ledger_view USING (company_id = current_setting('app.current_company_id')::UUID);
