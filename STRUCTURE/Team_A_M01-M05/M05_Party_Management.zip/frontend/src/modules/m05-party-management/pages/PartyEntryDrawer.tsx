import React, { useState } from "react";
import { Drawer, Input, Button, Toggle } from "../../../components/ui";
import { usePartyStore } from "../state/party.store";

export const PartyEntryDrawer: React.FC<{ open: boolean; onClose: () => void; }> = ({ open, onClose }) => {
  const { createParty, loading } = usePartyStore();
  const [form, setForm] = useState({ name: "", type: "customer", phone: "", email: "", gstin: "", address: "", creditLimit: 0 });
  const handleSubmit = async () => { await createParty(form); onClose(); };
  return (
    <Drawer open={open} onClose={onClose} title="Add Party">
      <div className="space-y-4 p-4">
        <Input label="Name" value={form.name} onChange={e => setForm({...form, name: e.target.value})} />
        <div className="flex gap-4">
          <label className="flex items-center gap-2"><input type="radio" checked={form.type === "customer"} onChange={() => setForm({...form, type: "customer"})} /> Customer</label>
          <label className="flex items-center gap-2"><input type="radio" checked={form.type === "supplier"} onChange={() => setForm({...form, type: "supplier"})} /> Supplier</label>
        </div>
        <Input label="Phone" value={form.phone} onChange={e => setForm({...form, phone: e.target.value})} />
        <Input label="Email" value={form.email} onChange={e => setForm({...form, email: e.target.value})} />
        <Input label="GSTIN" value={form.gstin} onChange={e => setForm({...form, gstin: e.target.value})} />
        <Input label="Address" value={form.address} onChange={e => setForm({...form, address: e.target.value})} />
        <Input type="number" label="Credit Limit" value={form.creditLimit} onChange={e => setForm({...form, creditLimit: Number(e.target.value)})} />
        <Button variant="primary" onClick={handleSubmit} disabled={loading || !form.name}>{loading ? "Saving…" : "Save Party"}</Button>
      </div>
    </Drawer>
  );
};