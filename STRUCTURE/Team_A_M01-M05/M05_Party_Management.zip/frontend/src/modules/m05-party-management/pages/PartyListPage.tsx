import React, { useEffect } from "react";
import { usePartyStore } from "../state/party.store";
import { Card, Button, Input, Table, Badge } from "../../../components/ui";

export const PartyListPage: React.FC = () => {
  const { parties, loading, fetchParties, setSearch } = usePartyStore();
  useEffect(() => { fetchParties(); }, [fetchParties]);
  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Party Master</h1>
        <Button variant="primary" onClick={() => window.location.href = "/party/new"}>+ Add Party</Button>
      </div>
      <Input placeholder="Search by name, phone, GSTIN…" onChange={e => setSearch(e.target.value)} />
      <Card>
        <Table columns={[
          { key: "name", header: "Name" },
          { key: "type", header: "Type", render: (r: any) => <Badge variant={r.type === "customer" ? "success" : "info"}>{r.type}</Badge> },
          { key: "phone", header: "Phone" },
          { key: "gstin", header: "GSTIN" },
          { key: "outstanding", header: "Outstanding", render: (r: any) => <span className={r.outstanding > 0 ? "text-red-600" : ""}>₹{r.outstanding?.toFixed(2) || "0.00"}</span> },
          { key: "actions", header: "", render: (r: any) => <Button size="sm" variant="secondary" onClick={() => window.location.href = `/party/${r.id}`}>View</Button> },
        ]} data={parties} />
      </Card>
    </div>
  );
};