import React, { useEffect } from "react";
import { useParams } from "react-router-dom";
import { usePartyStore } from "../state/party.store";
import { Card, Badge, Table } from "../../../components/ui";

export const PartyDetailHubPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { party, ledger, aging, fetchPartyDetail } = usePartyStore();
  useEffect(() => { if (id) fetchPartyDetail(id); }, [id, fetchPartyDetail]);
  if (!party) return <div className="p-8 text-center">Loading…</div>;
  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">{party.name}</h1>
        <Badge variant={party.type === "customer" ? "success" : "info"}>{party.type}</Badge>
      </div>
      <div className="grid grid-cols-3 gap-4">
        <Card><p className="text-sm text-slate-500">Outstanding</p><p className="text-xl font-bold text-red-600">₹{party.outstanding?.toFixed(2)}</p></Card>
        <Card><p className="text-sm text-slate-500">Credit Limit</p><p className="text-xl font-bold">₹{party.creditLimit?.toFixed(2)}</p></Card>
        <Card><p className="text-sm text-slate-500">Credit Used</p><p className="text-xl font-bold">{party.creditLimit ? ((party.outstanding / party.creditLimit) * 100).toFixed(1) : 0}%</p></Card>
      </div>
      <Card><h3 className="font-semibold mb-2">Aging Analysis</h3>
        <div className="grid grid-cols-4 gap-2 text-center">
          <div><p className="text-xs text-slate-500">0-30 days</p><p className="font-bold">₹{aging?.d0_30 || 0}</p></div>
          <div><p className="text-xs text-slate-500">31-60 days</p><p className="font-bold">₹{aging?.d31_60 || 0}</p></div>
          <div><p className="text-xs text-slate-500">61-90 days</p><p className="font-bold">₹{aging?.d61_90 || 0}</p></div>
          <div><p className="text-xs text-slate-500">90+ days</p><p className="font-bold text-red-600">₹{aging?.d90_plus || 0}</p></div>
        </div>
      </Card>
      <Card><h3 className="font-semibold mb-2">Ledger</h3>
        <Table columns={[
          { key: "date", header: "Date" },
          { key: "voucher", header: "Voucher" },
          { key: "debit", header: "Debit" },
          { key: "credit", header: "Credit" },
          { key: "balance", header: "Balance" },
        ]} data={ledger || []} />
      </Card>
    </div>
  );
};