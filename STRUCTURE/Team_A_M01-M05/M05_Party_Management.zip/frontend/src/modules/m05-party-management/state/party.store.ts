import { create } from "zustand";
import { PartyService } from "../services/party.service";
import { Party, PartyAging, PartyLedgerEntry } from "../services/party.types";

interface PartyState {
  parties: Party[]; party: Party | null; ledger: PartyLedgerEntry[] | null; aging: PartyAging | null;
  loading: boolean; error: string | null; search: string; typeFilter: string;
  fetchParties: () => Promise<void>; setSearch: (v: string) => void; setTypeFilter: (v: string) => void;
  fetchPartyDetail: (id: string) => Promise<void>;
  createParty: (d: any) => Promise<void>; updateParty: (id: string, d: any) => Promise<void>;
  deleteParty: (id: string) => Promise<void>;
}

export const usePartyStore = create<PartyState>((set, get) => ({
  parties: [], party: null, ledger: null, aging: null, loading: false, error: null, search: "", typeFilter: "",
  fetchParties: async () => {
    set({ loading: true });
    try { const p = await PartyService.getParties({ search: get().search, type: get().typeFilter }); set({ parties: p, loading: false }); }
    catch(e: any){ set({ error: e.message, loading: false }); }
  },
  setSearch: (v) => { set({ search: v }); get().fetchParties(); },
  setTypeFilter: (v) => { set({ typeFilter: v }); get().fetchParties(); },
  fetchPartyDetail: async (id) => {
    set({ loading: true });
    try { const [party, ledger, aging] = await Promise.all([PartyService.getParty(id), PartyService.getLedger(id), PartyService.getAging(id)]); set({ party, ledger, aging, loading: false }); }
    catch(e: any){ set({ error: e.message, loading: false }); }
  },
  createParty: async (d) => { set({ loading: true }); try { await PartyService.createParty(d); await get().fetchParties(); set({ loading: false }); } catch(e: any){ set({ error: e.message, loading: false }); } },
  updateParty: async (id, d) => { set({ loading: true }); try { await PartyService.updateParty(id, d); await get().fetchParties(); set({ loading: false }); } catch(e: any){ set({ error: e.message, loading: false }); } },
  deleteParty: async (id) => { set({ loading: true }); try { await PartyService.deleteParty(id); await get().fetchParties(); set({ loading: false }); } catch(e: any){ set({ error: e.message, loading: false }); } },
}));