import { lazy } from "react";
export const partyRoutes = [
  { path: "/party", component: lazy(() => import("../pages/PartyListPage")), exact: true, meta: { title: "Party Master", module: "M05" } },
  { path: "/party/new", component: lazy(() => import("../pages/PartyEntryDrawer")), exact: true, meta: { title: "Add Party", module: "M05" } },
  { path: "/party/:id", component: lazy(() => import("../pages/PartyDetailHubPage")), exact: true, meta: { title: "Party Detail", module: "M05" } },
];