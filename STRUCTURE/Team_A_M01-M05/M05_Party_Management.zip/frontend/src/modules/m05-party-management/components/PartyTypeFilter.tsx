import React from "react";
interface Props { value: string; onChange: (v: string) => void; }
export const PartyTypeFilter: React.FC<Props> = ({ value, onChange }) => (
  <select value={value} onChange={e => onChange(e.target.value)} className="border rounded px-3 py-2">
    <option value="">All</option><option value="customer">Customer</option><option value="supplier">Supplier</option>
  </select>
);