import React from "react";
import { Input } from "../../../components/ui";
interface Props { value: string; onChange: (v: string) => void; }
export const PartySearchBar: React.FC<Props> = ({ value, onChange }) => (
  <Input placeholder="Search party…" value={value} onChange={e => onChange(e.target.value)} className="max-w-md" />
);