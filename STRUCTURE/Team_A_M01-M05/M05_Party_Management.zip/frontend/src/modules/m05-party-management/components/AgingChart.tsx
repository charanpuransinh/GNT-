import React from "react";
interface Props { data: { d0_30: number; d31_60: number; d61_90: number; d90_plus: number; }; }
export const AgingChart: React.FC<Props> = ({ data }) => {
  const max = Math.max(data.d0_30, data.d31_60, data.d61_90, data.d90_plus, 1);
  const bar = (val: number, color: string) => (
    <div className="flex items-center gap-2"><div className="w-24 bg-slate-200 rounded h-4 overflow-hidden"><div className="h-full" style={{ width: `${(val/max)*100}%`, backgroundColor: color }} /></div><span className="text-xs w-16 text-right">₹{val}</span></div>
  );
  return <div className="space-y-2">{bar(data.d0_30, "#16A34A")}{bar(data.d31_60, "#F59E0B")}{bar(data.d61_90, "#EA580C")}{bar(data.d90_plus, "#DC2626")}</div>;
};