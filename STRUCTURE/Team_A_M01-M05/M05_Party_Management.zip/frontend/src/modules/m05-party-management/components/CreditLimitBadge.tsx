import React from "react";
import { Badge } from "../../../components/ui";
interface Props { used: number; limit: number; }
export const CreditLimitBadge: React.FC<Props> = ({ used, limit }) => {
  const pct = limit ? (used / limit) * 100 : 0;
  return <Badge variant={pct > 90 ? "danger" : pct > 70 ? "warning" : "success"}>{pct.toFixed(0)}% used</Badge>;
};