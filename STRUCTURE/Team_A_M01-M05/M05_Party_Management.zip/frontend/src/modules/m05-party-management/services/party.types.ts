export interface Party {
  id: string; companyId: string; name: string; type: "customer" | "supplier";
  phone?: string; email?: string; gstin?: string; address?: string;
  creditLimit: number; outstanding: number; createdAt: string; updatedAt: string;
}
export interface PartyCreatePayload {
  name: string; type: "customer" | "supplier"; phone?: string; email?: string;
  gstin?: string; address?: string; creditLimit?: number;
}
export interface PartyAging {
  partyId: string; d0_30: number; d31_60: number; d61_90: number; d90_plus: number; total: number;
}
export interface PartyLedgerEntry {
  id: string; date: string; voucherType: string; voucherNo: string; debit: number; credit: number; balance: number;
}
