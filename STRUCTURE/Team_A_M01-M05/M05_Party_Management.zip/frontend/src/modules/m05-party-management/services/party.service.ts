import apiClient from "../../../core/api-client";
import { Party, PartyCreatePayload, PartyAging, PartyLedgerEntry } from "./party.types";
const BASE = "/api/v1/party";
export const PartyService = {
  async getParties(params?: { search?: string; type?: string }): Promise<Party[]> {
    const r = await apiClient.get(BASE, { params });
    return r.data.data;
  },
  async getParty(id: string): Promise<Party> {
    const r = await apiClient.get(`${BASE}/${id}`);
    return r.data.data;
  },
  async createParty(data: PartyCreatePayload): Promise<Party> {
    const r = await apiClient.post(BASE, data);
    return r.data.data;
  },
  async updateParty(id: string, data: Partial<PartyCreatePayload>): Promise<Party> {
    const r = await apiClient.put(`${BASE}/${id}`, data);
    return r.data.data;
  },
  async deleteParty(id: string): Promise<void> {
    await apiClient.delete(`${BASE}/${id}`);
  },
  async getAging(id: string): Promise<PartyAging> {
    const r = await apiClient.get(`${BASE}/${id}/aging`);
    return r.data.data;
  },
  async getLedger(id: string): Promise<PartyLedgerEntry[]> {
    const r = await apiClient.get(`${BASE}/${id}/ledger`);
    return r.data.data;
  },
};