import { PartyRepository } from "../repositories/party.repository";
import { PartyInternal } from "./party.internal";
import { EventBus } from "../../../common/events/event-bus";
import { AuditLogger } from "../../../common/logging/audit-logger";
import { AppError } from "../../../common/errors/error-classes";

export class PartyService {
  constructor(
    private readonly repo: PartyRepository,
    private readonly internal: PartyInternal,
    private readonly eventBus: EventBus,
    private readonly audit: AuditLogger,
  ) {}

  async list(companyId: string, filters: any) { return this.repo.findAll(companyId, filters); }

  async get(id: string, companyId: string) {
    const p = await this.repo.findById(id, companyId);
    if (!p) throw new AppError("GNT-ERR-0501", "Party not found", 404);
    return p;
  }

  async create(companyId: string, data: any) {
    if (data.gstin && !(await this.internal.validateGSTIN(data.gstin))) {
      throw new AppError("GNT-ERR-0502", "Invalid GSTIN", 400);
    }
    const party = await this.repo.create({ ...data, companyId, outstanding: 0 });
    this.eventBus.publish("party.created", { partyId: party.id, companyId, type: data.type });
    this.audit.log({ action: "PARTY_CREATED", target: party.id });
    return party;
  }

  async update(id: string, companyId: string, data: any) {
    if (data.gstin && !(await this.internal.validateGSTIN(data.gstin))) {
      throw new AppError("GNT-ERR-0502", "Invalid GSTIN", 400);
    }
    const party = await this.repo.update(id, companyId, data);
    this.audit.log({ action: "PARTY_UPDATED", target: id });
    return party;
  }

  async delete(id: string, companyId: string) {
    await this.repo.softDelete(id, companyId);
    this.eventBus.publish("party.deleted", { partyId: id, companyId });
    this.audit.log({ action: "PARTY_DELETED", target: id });
  }

  async getAging(id: string, companyId: string) { return this.internal.calculateAging(id, companyId, this.repo); }

  async getLedger(id: string, companyId: string) {
    // Reads from M10 ledger through PUBLIC contract — NOT direct DB
    return this.internal.fetchLedgerFromAccounting(id, companyId);
  }

  async checkCreditLimit(partyId: string, companyId: string): Promise<{ allowed: boolean; remaining: number }> {
    const party = await this.get(partyId, companyId);
    const remaining = (party.creditLimit || 0) - (party.outstanding || 0);
    return { allowed: remaining > 0, remaining };
  }
}