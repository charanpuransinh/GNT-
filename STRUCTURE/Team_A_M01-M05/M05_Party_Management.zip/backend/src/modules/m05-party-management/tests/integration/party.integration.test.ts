import request from "supertest";
import { app } from "../../../../app";

describe("M05 Party Integration", () => {
  const t = "Bearer test-jwt-token";
  const c = "550e8400-e29b-41d4-a716-446655440000";

  it("GET /api/v1/party returns list", async () => {
    const r = await request(app).get("/api/v1/party").set("Authorization", t).set("X-Company-Id", c);
    expect(r.status).toBe(200);
    expect(r.body.success).toBe(true);
    expect(Array.isArray(r.body.data)).toBe(true);
  });

  it("POST /api/v1/party creates party", async () => {
    const r = await request(app).post("/api/v1/party").set("Authorization", t).set("X-Company-Id", c).send({
      name: "Test Customer", type: "customer", phone: "9876543210", creditLimit: 50000
    });
    expect([200, 201]).toContain(r.status);
    expect(r.body.data).toHaveProperty("id");
  });

  it("returns 401 without auth", async () => {
    const r = await request(app).get("/api/v1/party");
    expect(r.status).toBe(401);
  });
});
