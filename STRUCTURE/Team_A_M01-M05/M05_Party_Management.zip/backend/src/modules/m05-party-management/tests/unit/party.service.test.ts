import { PartyService } from "../../services/party.service";
import { PartyRepository } from "../../repositories/party.repository";
import { PartyInternal } from "../../services/party.internal";
import { EventBus } from "../../../../common/events/event-bus";
import { AuditLogger } from "../../../../common/logging/audit-logger";

describe("PartyService", () => {
  let svc: PartyService;
  let mockRepo: jest.Mocked<PartyRepository>;
  let mockInternal: jest.Mocked<PartyInternal>;
  let mockEvent: jest.Mocked<EventBus>;
  let mockAudit: jest.Mocked<AuditLogger>;

  beforeEach(() => {
    mockRepo = {
      findAll: jest.fn(), findById: jest.fn(), create: jest.fn(), update: jest.fn(),
      softDelete: jest.fn(), findInvoicesForAging: jest.fn(), updateOutstanding: jest.fn(),
    } as any;
    mockInternal = { validateGSTIN: jest.fn(), calculateAging: jest.fn(), fetchLedgerFromAccounting: jest.fn() } as any;
    mockEvent = { publish: jest.fn() } as any;
    mockAudit = { log: jest.fn() } as any;
    svc = new PartyService(mockRepo, mockInternal, mockEvent, mockAudit);
  });

  it("creates party with valid GSTIN", async () => {
    mockInternal.validateGSTIN.mockResolvedValue(true);
    mockRepo.create.mockResolvedValue({ id: "p1", name: "Test" } as any);
    const r = await svc.create("c1", { name: "Test", type: "customer", gstin: "27AABCU9603R1ZM" });
    expect(r.id).toBe("p1");
    expect(mockEvent.publish).toHaveBeenCalledWith("party.created", expect.any(Object));
  });

  it("throws on invalid GSTIN", async () => {
    mockInternal.validateGSTIN.mockResolvedValue(false);
    await expect(svc.create("c1", { name: "Test", type: "customer", gstin: "BAD" })).rejects.toThrow();
  });
});
