import request from "supertest";
import { app } from "../../../../app";

describe("M05 API Contract", () => {
  const t = "Bearer test-jwt-token";
  const c = "550e8400-e29b-41d4-a716-446655440000";

  it("GET /party schema matches", async () => {
    const r = await request(app).get("/api/v1/party").set("Authorization", t).set("X-Company-Id", c);
    expect(r.status).toBe(200);
    if (r.body.data.length > 0) {
      expect(r.body.data[0]).toMatchObject({ id: expect.any(String), name: expect.any(String), type: expect.any(String) });
    }
  });

  it("GET /party/:id/aging returns aging object", async () => {
    // create first
    const create = await request(app).post("/api/v1/party").set("Authorization", t).set("X-Company-Id", c).send({ name: "Aging Test", type: "customer" });
    const id = create.body.data?.id;
    if (!id) return;
    const r = await request(app).get(`/api/v1/party/${id}/aging`).set("Authorization", t).set("X-Company-Id", c);
    expect(r.status).toBe(200);
    expect(r.body.data).toMatchObject({ partyId: expect.any(String), total: expect.any(Number) });
  });
});
