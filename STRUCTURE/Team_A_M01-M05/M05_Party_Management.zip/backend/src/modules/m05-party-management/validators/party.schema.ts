import { z } from "zod";
export const partyCreateSchema = z.object({
  name: z.string().min(1).max(200), type: z.enum(["customer", "supplier"]),
  phone: z.string().max(20).optional(), email: z.string().email().optional().or(z.literal("")),
  gstin: z.string().regex(/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/, "Invalid GSTIN").optional().or(z.literal("")),
  address: z.string().max(500).optional(), creditLimit: z.number().min(0).default(0),
});
export const partyUpdateSchema = partyCreateSchema.partial();
