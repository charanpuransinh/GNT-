import { Router } from "express";
import { PartyController } from "../controllers/party.controller";
import { PartyService } from "../services/party.service";
import { PartyInternal } from "../services/party.internal";
import { PartyRepository } from "../repositories/party.repository";
import { authMiddleware } from "../../../common/middleware/auth-middleware";
import { tenantMiddleware } from "../../../common/middleware/tenant-middleware";
import { requestTracer } from "../../../common/middleware/request-tracer";
import { validationMiddleware } from "../../../common/middleware/validation-middleware";
import { partyCreateSchema, partyUpdateSchema } from "../validators/party.schema";
import { prisma } from "../../../common/config/prisma";
import { EventBus } from "../../../common/events/event-bus";
import { AuditLogger } from "../../../common/logging/audit-logger";

const router = Router();
const repo = new PartyRepository(prisma);
const internal = new PartyInternal();
const eventBus = new EventBus();
const audit = new AuditLogger();
const service = new PartyService(repo, internal, eventBus, audit);
const controller = new PartyController(service);

router.use(authMiddleware); router.use(tenantMiddleware); router.use(requestTracer);
router.get("/", (req, res, next) => controller.list(req, res, next));
router.get("/:id", (req, res, next) => controller.get(req, res, next));
router.post("/", validationMiddleware(partyCreateSchema), (req, res, next) => controller.create(req, res, next));
router.put("/:id", validationMiddleware(partyUpdateSchema), (req, res, next) => controller.update(req, res, next));
router.delete("/:id", (req, res, next) => controller.remove(req, res, next));
router.get("/:id/aging", (req, res, next) => controller.aging(req, res, next));
router.get("/:id/ledger", (req, res, next) => controller.ledger(req, res, next));

export default router;
