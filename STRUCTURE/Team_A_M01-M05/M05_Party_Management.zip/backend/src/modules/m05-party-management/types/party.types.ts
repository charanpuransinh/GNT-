export interface PartyDTO {
  id: string; companyId: string; name: string; type: "customer" | "supplier";
  phone?: string; email?: string; gstin?: string; address?: string;
  creditLimit: number; outstanding: number; isActive: boolean;
}
export interface PartyAgingDTO {
  partyId: string; d0_30: number; d31_60: number; d61_90: number; d90_plus: number; total: number;
}
export interface CreditLimitCheckDTO {
  allowed: boolean; remaining: number;
}
