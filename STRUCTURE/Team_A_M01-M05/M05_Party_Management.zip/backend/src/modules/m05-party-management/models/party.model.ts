export interface PartyMasterModel {
  id: string; companyId: string; name: string; type: "customer" | "supplier";
  phone?: string; email?: string; gstin?: string; address?: string;
  creditLimit: number; outstanding: number; isActive: boolean;
  createdAt: Date; updatedAt: Date; deletedAt?: Date;
}
export interface PartyLedgerViewModel {
  id: string; partyId: string; companyId: string; voucherType: string; voucherNo: string;
  date: Date; debit: number; credit: number; balance: number;
}
