export const PARTY_EVENTS = {
  PARTY_CREATED: "party.created",
  PARTY_UPDATED: "party.updated",
  PARTY_DELETED: "party.deleted",
  OUTSTANDING_CHANGED: "party.outstanding.changed",
} as const;
