import { PrismaClient } from "@prisma/client";

export class PartyRepository {
  constructor(private readonly prisma: PrismaClient) {}

  async findAll(companyId: string, filters: any) {
    const where: any = { companyId, deletedAt: null };
    if (filters.search) {
      where.OR = [
        { name: { contains: filters.search, mode: "insensitive" } },
        { phone: { contains: filters.search } },
        { gstin: { contains: filters.search } },
      ];
    }
    if (filters.type) where.type = filters.type;
    return this.prisma.party_master.findMany({ where, orderBy: { name: "asc" } });
  }

  async findById(id: string, companyId: string) {
    return this.prisma.party_master.findFirst({ where: { id, companyId, deletedAt: null } });
  }

  async create(data: any) { return this.prisma.party_master.create({ data }); }

  async update(id: string, companyId: string, data: any) {
    return this.prisma.party_master.update({ where: { id }, data: { ...data, updatedAt: new Date() } });
  }

  async softDelete(id: string, companyId: string) {
    return this.prisma.party_master.update({ where: { id, companyId }, data: { deletedAt: new Date(), isActive: false } });
  }

  async findInvoicesForAging(partyId: string, companyId: string) {
    // Reads from party_ledger_view (owned by M05) or calls M08/M07 public service
    return this.prisma.party_ledger_view.findMany({ where: { partyId, companyId, balance: { gt: 0 } } });
  }

  async updateOutstanding(partyId: string, companyId: string, amount: number) {
    return this.prisma.party_master.update({
      where: { id: partyId, companyId },
      data: { outstanding: { increment: amount }, updatedAt: new Date() },
    });
  }
}