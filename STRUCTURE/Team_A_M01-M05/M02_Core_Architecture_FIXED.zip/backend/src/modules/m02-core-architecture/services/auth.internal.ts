import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import { logger } from '@/common/logging/logger';

const ACCESS_TOKEN_SECRET = process.env.ACCESS_TOKEN_SECRET || 'dev-access-secret';
const REFRESH_TOKEN_SECRET = process.env.REFRESH_TOKEN_SECRET || 'dev-refresh-secret';
const ACCESS_TOKEN_EXPIRY = '15m';
const REFRESH_TOKEN_EXPIRY = '7d';
const OTP_EXPIRY_MINUTES = 10;

// In-memory OTP store (replace with Redis in production)
const otpStore = new Map<string, { otp: string; expiresAt: Date }>();

export const authInternal = {
  async hashPassword(password: string): Promise<string> {
    return bcrypt.hash(password, 12);
  },

  async verifyPassword(password: string, hash: string): Promise<boolean> {
    return bcrypt.compare(password, hash);
  },

  generateTokenPair(payload: {
    userId: string;
    companyId: string;
    roles: string[];
  }): { accessToken: string; refreshToken: string } {
    const accessToken = jwt.sign(
      { ...payload, type: 'access' },
      ACCESS_TOKEN_SECRET,
      { expiresIn: ACCESS_TOKEN_EXPIRY, algorithm: 'RS256' }
    );

    const refreshToken = jwt.sign(
      { userId: payload.userId, type: 'refresh' },
      REFRESH_TOKEN_SECRET,
      { expiresIn: REFRESH_TOKEN_EXPIRY, algorithm: 'RS256' }
    );

    return { accessToken, refreshToken };
  },

  verifyAccessToken(token: string): any {
    return jwt.verify(token, ACCESS_TOKEN_SECRET, { algorithms: ['RS256'] });
  },

  verifyRefreshToken(token: string): any {
    return jwt.verify(token, REFRESH_TOKEN_SECRET, { algorithms: ['RS256'] });
  },

  async sendOtp(userId: string, email: string): Promise<void> {
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    const expiresAt = new Date(Date.now() + OTP_EXPIRY_MINUTES * 60 * 1000);

    otpStore.set(userId, { otp, expiresAt });

    // In production, send via SMS/Email through M16
    logger.info(`OTP generated for user ${userId}`, { expiresAt });
  },

  async verifyOtp(userId: string, otp: string): Promise<boolean> {
    const record = otpStore.get(userId);
    if (!record) return false;

    if (new Date() > record.expiresAt) {
      otpStore.delete(userId);
      return false;
    }

    const isValid = record.otp === otp;
    if (isValid) {
      otpStore.delete(userId);
    }

    return isValid;
  },

  async verifyPin(userId: string, pin: string): Promise<boolean> {
    // In production, verify against stored session PIN hash
    // Simplified for M02 — would use proper PIN storage
    return pin.length >= 4;
  },

  isHighRiskLogin(user: any): boolean {
    // High risk if: new device, unusual time, different IP pattern
    // Simplified logic
    return false;
  },

  async revokeTokens(userId: string): Promise<void> {
    // In production, add to Redis blacklist
    logger.info(`Tokens revoked for user ${userId}`);
  },
};
