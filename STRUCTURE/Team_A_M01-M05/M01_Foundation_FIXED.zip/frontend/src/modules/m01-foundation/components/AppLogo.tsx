import { useAppStore } from '../state/app.store';

interface AppLogoProps {
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export const AppLogo = ({ size = 'md', className = '' }: AppLogoProps) => {
  const { config } = useAppStore();
  const logoUrl = config?.branding?.logoUrl;

  const sizeClasses = {
    sm: 'h-6 w-6',
    md: 'h-8 w-8',
    lg: 'h-12 w-12',
  };

  if (logoUrl) {
    return (
      <img
        src={logoUrl}
        alt={config?.appName || 'GNT'}
        className={`${sizeClasses[size]} object-contain ${className}`}
      />
    );
  }

  return (
    <div
      className={`${sizeClasses[size]} rounded-lg bg-[#2563EB] flex items-center justify-center text-white font-bold ${className}`}
    >
      G
    </div>
  );
};
