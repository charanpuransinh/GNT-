# PART 1 — TASK ASSIGNMENT
**Module:** M<XX> — <module name>
**Class:** A / B / C / D
**Assigned to:** <Aider / Claude Code / Qodo / etc.>
**Assigned by:** Claude
**Date:** <date>

## Task
<Plain-language description of exactly what must be built or fixed.>

## Files in scope
- <path 1>
- <path 2>

## Contract (5-part header — must appear at top of every file)
- **OWN:** <what this file/module owns>
- **USE:** <what it's allowed to read from other modules — PUBLIC only>
- **PROVIDE:** <what it exposes to other modules>
- **DATABASE:** <tables/schema it owns>
- **FORBIDDEN:** <what it must never do — e.g. write another module's table>

## Data rules
- No fake/mock/random data. Missing input → raise `DataUnavailableError` (or module-appropriate equivalent).
- No hardcoded secrets.

## Acceptance criteria (how we'll know it's actually done)
- [ ] Matches file list and contract above
- [ ] Builds/runs without errors
- [ ] Passes tests written by Qodo
- [ ] No boundary violations (checked against ABCD Team Wiring Map)

## Dependencies
<Which other modules/files this depends on, per Master Wiring Map.>
