/**
 * M29 — api/mobile-api.routes.ts
 * OWN: Mobile-specific API surface.
 * Framework-agnostic route descriptors (Section 20 API Contract) — bound to
 * the real HTTP framework at wiring time.
 */

export interface MobileApiRouteDescriptor {
  method: 'GET' | 'POST' | 'PUT' | 'DELETE';
  path: string;
  permission: string | null; // null = public (auth endpoints only)
  description: string;
}

export const mobileApiRoutes: MobileApiRouteDescriptor[] = [
  { method: 'POST', path: '/api/v1/mobile/auth/login', permission: null, description: 'Mobile login' },
  { method: 'POST', path: '/api/v1/mobile/auth/refresh', permission: null, description: 'Refresh mobile tokens' },
  { method: 'POST', path: '/api/v1/mobile/sync/push', permission: 'M29.SYNC.MANAGE', description: 'Push queued client changes' },
  { method: 'GET', path: '/api/v1/mobile/sync/status', permission: 'M29.SYNC.READ', description: 'Get sync status for device' },
  { method: 'GET', path: '/api/v1/mobile/sessions', permission: 'M29.MOBILE.ADMIN', description: 'List active mobile sessions' },
  { method: 'DELETE', path: '/api/v1/mobile/sessions/:sessionId', permission: 'M29.MOBILE.ADMIN', description: 'Revoke a mobile session' },
];
