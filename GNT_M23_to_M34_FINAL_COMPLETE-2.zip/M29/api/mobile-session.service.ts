/**
 * M29 — api/mobile-session.service.ts
 * OWN: Mobile session lifecycle.
 * Backs table: mobile_session (proposed, tenant-owned).
 */

export interface MobileSession {
  sessionId: string;
  userId: string;
  tenantId: string;
  deviceId: string;
  createdAt: string;
  lastSeenAt: string;
  revoked: boolean;
}

export interface MobileSessionStore {
  save(session: MobileSession): Promise<void>;
  find(sessionId: string): Promise<MobileSession | null>;
  listForUser(userId: string, tenantId: string): Promise<MobileSession[]>;
}

export class MobileSessionService {
  constructor(private readonly store: MobileSessionStore) {}

  async createSession(userId: string, tenantId: string, deviceId: string): Promise<MobileSession> {
    const now = new Date().toISOString();
    const session: MobileSession = {
      sessionId: `msess_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`,
      userId,
      tenantId,
      deviceId,
      createdAt: now,
      lastSeenAt: now,
      revoked: false,
    };
    await this.store.save(session);
    return session;
  }

  async touch(sessionId: string): Promise<void> {
    const session = await this.store.find(sessionId);
    if (!session || session.revoked) return;
    session.lastSeenAt = new Date().toISOString();
    await this.store.save(session);
  }

  async revoke(sessionId: string): Promise<void> {
    const session = await this.store.find(sessionId);
    if (!session) return;
    session.revoked = true;
    await this.store.save(session);
  }

  async isActive(sessionId: string): Promise<boolean> {
    const session = await this.store.find(sessionId);
    return !!session && !session.revoked;
  }
}
