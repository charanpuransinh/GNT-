/**
 * M29 — api/mobile-auth.service.ts
 * OWN: Mobile authentication adapter.
 *
 * VERIFICATION NEEDED: real M01 auth flow. This adapts a mobile
 * login/refresh flow onto an injected AuthBackend rather than
 * reimplementing token issuance.
 */

export interface MobileLoginCredentials {
  username: string;
  password: string;
  deviceId: string;
}

export interface MobileAuthTokens {
  accessToken: string;
  refreshToken: string;
  expiresInSeconds: number;
}

export interface AuthBackend {
  login(username: string, password: string): Promise<{ userId: string; tenantId: string } | null>;
  issueTokens(userId: string, tenantId: string, deviceId: string): Promise<MobileAuthTokens>;
  refresh(refreshToken: string): Promise<MobileAuthTokens | null>;
}

export class MobileAuthError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'MobileAuthError';
  }
}

export class MobileAuthService {
  constructor(private readonly authBackend: AuthBackend) {}

  async login(credentials: MobileLoginCredentials): Promise<MobileAuthTokens> {
    const identity = await this.authBackend.login(credentials.username, credentials.password);
    if (!identity) {
      throw new MobileAuthError('Invalid credentials');
    }
    return this.authBackend.issueTokens(identity.userId, identity.tenantId, credentials.deviceId);
  }

  async refresh(refreshToken: string): Promise<MobileAuthTokens> {
    const tokens = await this.authBackend.refresh(refreshToken);
    if (!tokens) {
      throw new MobileAuthError('Invalid or expired refresh token');
    }
    return tokens;
  }
}
