/**
 * M29 — sync/conflict-resolution.service.ts
 * OWN: Deterministic conflict resolution.
 * Backs table: sync_conflict (proposed, tenant-owned).
 */

export type ConflictStrategy = 'LAST_WRITE_WINS' | 'SERVER_WINS' | 'MANUAL_REVIEW';

export interface ConflictCandidate {
  entityType: string;
  entityId: string;
  clientPayload: Record<string, unknown>;
  clientTimestamp: string;
  serverPayload: Record<string, unknown>;
  serverTimestamp: string;
}

export interface ConflictResolution {
  resolved: boolean;
  strategy: ConflictStrategy;
  winningPayload: Record<string, unknown> | null;
  reason: string;
}

const DEFAULT_STRATEGY: ConflictStrategy = 'LAST_WRITE_WINS';

export class ConflictResolutionService {
  resolve(candidate: ConflictCandidate, strategy: ConflictStrategy = DEFAULT_STRATEGY): ConflictResolution {
    switch (strategy) {
      case 'SERVER_WINS':
        return {
          resolved: true,
          strategy,
          winningPayload: candidate.serverPayload,
          reason: 'Server state is authoritative by policy',
        };

      case 'LAST_WRITE_WINS': {
        const clientTime = new Date(candidate.clientTimestamp).getTime();
        const serverTime = new Date(candidate.serverTimestamp).getTime();
        const winningPayload = clientTime >= serverTime ? candidate.clientPayload : candidate.serverPayload;
        return {
          resolved: true,
          strategy,
          winningPayload,
          reason: clientTime >= serverTime ? 'Client write is more recent' : 'Server write is more recent',
        };
      }

      case 'MANUAL_REVIEW':
      default:
        return {
          resolved: false,
          strategy: 'MANUAL_REVIEW',
          winningPayload: null,
          reason: 'Conflict requires human review — deferred, not auto-resolved',
        };
    }
  }
}

export const conflictResolutionService = new ConflictResolutionService();
