/**
 * M29 — sync/sync-status.service.ts
 * OWN: Sync state tracking per device.
 */

export interface SyncStatus {
  deviceId: string;
  tenantId: string;
  lastSyncedAt: string | null;
  pendingCount: number;
  conflictCount: number;
}

export interface SyncStatusStore {
  get(deviceId: string, tenantId: string): Promise<SyncStatus | null>;
  save(status: SyncStatus): Promise<void>;
}

export class SyncStatusService {
  constructor(private readonly store: SyncStatusStore) {}

  async getStatus(deviceId: string, tenantId: string): Promise<SyncStatus> {
    const existing = await this.store.get(deviceId, tenantId);
    return existing ?? { deviceId, tenantId, lastSyncedAt: null, pendingCount: 0, conflictCount: 0 };
  }

  async recordSyncCompleted(deviceId: string, tenantId: string, pendingCount: number, conflictCount: number): Promise<void> {
    await this.store.save({
      deviceId,
      tenantId,
      lastSyncedAt: new Date().toISOString(),
      pendingCount,
      conflictCount,
    });
  }
}
