/**
 * M29 — sync/sync-queue.service.ts
 * OWN: Durable sync queue.
 * Backs table: sync_queue (proposed, tenant-owned).
 * Rule 11 (Global Rules): sync operations must be idempotent.
 */

export interface SyncQueueItem {
  itemId: string;
  tenantId: string;
  userId: string;
  deviceId: string;
  entityType: string;
  entityId: string;
  operation: 'CREATE' | 'UPDATE' | 'DELETE';
  payload: Record<string, unknown>;
  clientTimestamp: string;
  idempotencyKey: string;
  status: 'PENDING' | 'APPLIED' | 'CONFLICT' | 'FAILED';
}

export interface SyncQueueStore {
  enqueue(item: SyncQueueItem): Promise<void>;
  findByIdempotencyKey(tenantId: string, idempotencyKey: string): Promise<SyncQueueItem | null>;
  listPending(tenantId: string, deviceId: string): Promise<SyncQueueItem[]>;
  updateStatus(itemId: string, status: SyncQueueItem['status']): Promise<void>;
}

export class SyncQueueService {
  constructor(private readonly store: SyncQueueStore) {}

  /** Enqueue is idempotent: a duplicate idempotencyKey is a no-op, not a new item. */
  async enqueue(item: Omit<SyncQueueItem, 'status'>): Promise<SyncQueueItem> {
    const existing = await this.store.findByIdempotencyKey(item.tenantId, item.idempotencyKey);
    if (existing) return existing;

    const full: SyncQueueItem = { ...item, status: 'PENDING' };
    await this.store.enqueue(full);
    return full;
  }

  async pendingFor(tenantId: string, deviceId: string): Promise<SyncQueueItem[]> {
    return this.store.listPending(tenantId, deviceId);
  }

  async markApplied(itemId: string): Promise<void> {
    await this.store.updateStatus(itemId, 'APPLIED');
  }

  async markConflict(itemId: string): Promise<void> {
    await this.store.updateStatus(itemId, 'CONFLICT');
  }

  async markFailed(itemId: string): Promise<void> {
    await this.store.updateStatus(itemId, 'FAILED');
  }
}
