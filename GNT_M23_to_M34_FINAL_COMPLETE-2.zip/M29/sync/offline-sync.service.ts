/**
 * M29 — sync/offline-sync.service.ts
 * OWN: Offline data synchronization orchestration.
 */

import { SyncQueueService, SyncQueueItem } from './sync-queue.service';
import { ConflictResolutionService, conflictResolutionService, ConflictCandidate } from './conflict-resolution.service';
import { SyncStatusService } from './sync-status.service';

export interface EntityRepository {
  getCurrent(tenantId: string, entityType: string, entityId: string): Promise<{ payload: Record<string, unknown>; updatedAt: string } | null>;
  apply(tenantId: string, entityType: string, entityId: string, payload: Record<string, unknown>): Promise<void>;
}

export interface SyncRunResult {
  applied: number;
  conflicts: number;
  failed: number;
}

export class OfflineSyncService {
  constructor(
    private readonly queue: SyncQueueService,
    private readonly repository: EntityRepository,
    private readonly statusService: SyncStatusService,
    private readonly conflictResolver: ConflictResolutionService = conflictResolutionService,
  ) {}

  async runSync(tenantId: string, deviceId: string): Promise<SyncRunResult> {
    const pending = await this.queue.pendingFor(tenantId, deviceId);
    let applied = 0;
    let conflicts = 0;
    let failed = 0;

    for (const item of pending) {
      try {
        const outcome = await this.processItem(item);
        if (outcome === 'APPLIED') applied += 1;
        else if (outcome === 'CONFLICT') conflicts += 1;
        else failed += 1;
      } catch {
        await this.queue.markFailed(item.itemId);
        failed += 1;
      }
    }

    await this.statusService.recordSyncCompleted(deviceId, tenantId, pending.length - applied - conflicts - failed, conflicts);
    return { applied, conflicts, failed };
  }

  private async processItem(item: SyncQueueItem): Promise<'APPLIED' | 'CONFLICT' | 'FAILED'> {
    const current = await this.repository.getCurrent(item.tenantId, item.entityType, item.entityId);

    if (!current || item.operation === 'CREATE') {
      await this.repository.apply(item.tenantId, item.entityType, item.entityId, item.payload);
      await this.queue.markApplied(item.itemId);
      return 'APPLIED';
    }

    const candidate: ConflictCandidate = {
      entityType: item.entityType,
      entityId: item.entityId,
      clientPayload: item.payload,
      clientTimestamp: item.clientTimestamp,
      serverPayload: current.payload,
      serverTimestamp: current.updatedAt,
    };

    const resolution = this.conflictResolver.resolve(candidate);
    if (!resolution.resolved || !resolution.winningPayload) {
      await this.queue.markConflict(item.itemId);
      return 'CONFLICT';
    }

    await this.repository.apply(item.tenantId, item.entityType, item.entityId, resolution.winningPayload);
    await this.queue.markApplied(item.itemId);
    return 'APPLIED';
  }
}
