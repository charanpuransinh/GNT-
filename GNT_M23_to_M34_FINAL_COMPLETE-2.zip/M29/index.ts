/**
 * M29 — Mobile, Offline & Sync
 * index.ts — Public M29 exports.
 */

export { mobileApiRoutes, type MobileApiRouteDescriptor } from './api/mobile-api.routes';
export { MobileAuthService, MobileAuthError, type MobileLoginCredentials, type MobileAuthTokens, type AuthBackend } from './api/mobile-auth.service';
export { MobileSessionService, type MobileSession, type MobileSessionStore } from './api/mobile-session.service';

export { OfflineSyncService, type EntityRepository, type SyncRunResult } from './sync/offline-sync.service';
export { SyncQueueService, type SyncQueueItem, type SyncQueueStore } from './sync/sync-queue.service';
export { ConflictResolutionService, conflictResolutionService, type ConflictCandidate, type ConflictResolution, type ConflictStrategy } from './sync/conflict-resolution.service';
export { SyncStatusService, type SyncStatus, type SyncStatusStore } from './sync/sync-status.service';

export { PushNotificationService, pushNotificationService, type PushMessage, type PushProvider } from './notification/push-notification.service';
