# GNT Advanced Blueprint — M23 से M34 तक — पूरी — READ ME FIRST

## पूरा हो गया — सारे 12 मॉड्यूल
M23, M24, M25, M26, M27, M28, M29, M30, M31, M32, M33, M34 — कुल 132 फाइलें
— सब strict TypeScript में compile हो चुकी हैं (`tsc --strict`, 0 errors, सारे 12 मॉड्यूल एक साथ भी)।
GNT_ADVANCED_MASTER_BLUEPRINT_M23_M34.md में जो भी मांगा गया था वो सब बन चुका है।

## डाउनलोड कैसे करें
ऊपर चैट में जो भी zip फाइल कार्ड (M23_Security_Governance.zip, M24_M25_M26_Modules.zip,
M27_M28_M29_Modules.zip, वगैरह) आए हैं — हर एक पर टैप करके "Download"/"Save" करें।
Android पर आम तौर पर यह आपके फोन के **Downloads** फोल्डर में सेव होता है।
अगर session यहीं खत्म हो जाए (limit की वजह से), तो जो zip cards ऊपर आ चुके हैं वो सब
पहले से आपके पास मौजूद रहेंगे — दोबारा माँगने की ज़रूरत नहीं।

## इसे चलाना कैसे है (Termux में)
1. हर zip को अपने फोन के Downloads से GNT repo के अंदर सही जगह भेजिए —
   हर मॉड्यूल अपने नाम के फोल्डर में जाना है, जैसे:
   `backend/src/modules/M23/`, `backend/src/modules/M24/`, ... वगैरह
   (असली repo का सटीक path आप confirm कर दें — मैंने blueprint में जो
   दिया था वही structure रखा है: `GNT/backend/src/modules/M2x/`)
2. Termux में:
   ```
   cd ~/GNT   (आपके repo का असली path)
   unzip -o /sdcard/Download/M23_Security_Governance.zip -d backend/src/modules/
   unzip -o /sdcard/Download/M24_M25_M26_Modules.zip -d backend/src/modules/
   unzip -o /sdcard/Download/M27_M28_M29_Modules.zip -d backend/src/modules/
   (M30-M32 वाली zip जब मिले वो भी इसी तरह)
   ```
3. फिर compile check खुद repo में भी कर लें:
   ```
   npx tsc --noEmit
   ```

## ज़रूरी — अभी इसे production में wire मत करना
हर मॉड्यूल के अंदर एक `*_INTEGRATION_NOTES.md` (या हर फाइल के ऊपर comment में)
लिखा है कि किन चीज़ों को असली repo से verify करना बाकी है — जैसे M01 का असली
user-object shape, M02 का permission format, shared EventBus class, आदि।
यह जानबूझकर है — blueprint के अपने Rule 1 ("No Guessing") के हिसाब से।
पहले M01-M22 से इन 5-6 चीज़ों को verify करना, फिर wire करना, तभी सुरक्षित रहेगा।

## Tests अभी नहीं बने
Token/समय limit की वजह से unit tests (blueprint का 10-scenario matrix) अभी
generate नहीं हुए — यह अगला ज़रूरी step है, code के बाद।

## अगला step
अब कोड-जनरेशन पूरा है। अगला ज़रूरी काम:
1. M01-M22 असली repo खोलकर ऊपर बताई 5-6 चीज़ें verify करना
2. हर मॉड्यूल के लिए unit tests बनाना (अभी नहीं बने — token limit)
3. Database migration (Prisma schema) — proposed tables हर मॉड्यूल की फाइल में comment में लिखी हैं
4. फिर Golden Call Chain के हिसाब से actual wiring

## अगर सेशन बीच में कट जाए
जो भी zip cards चैट में ऊपर आ चुके हैं, वो सुरक्षित हैं — आपको दोबारा माँगने की
ज़रूरत नहीं।
