/**
 * M27 — analytics/analytics-query.service.ts
 * OWN: Optimized analytics queries.
 *
 * VERIFICATION NEEDED: real data-source access for existing modules
 * (financial/inventory/sales figures). Depends on an injected
 * AnalyticsDataSource adapter per source module — M27 never reads another
 * module's private tables directly (Calling Rule, Section 19).
 */

import { MetricDefinition, MetricDataPoint } from './metrics.service';

export interface AnalyticsDataSource {
  fetchSeries(
    tenantId: string,
    sourceEntity: string,
    sourceField: string | undefined,
    fromDate: string,
    toDate: string,
  ): Promise<MetricDataPoint[]>;
}

export class AnalyticsQueryService {
  private sources = new Map<string, AnalyticsDataSource>();

  registerSource(sourceEntity: string, source: AnalyticsDataSource): void {
    this.sources.set(sourceEntity, source);
  }

  async fetchForMetric(
    definition: MetricDefinition,
    fromDate: string,
    toDate: string,
  ): Promise<MetricDataPoint[]> {
    const source = this.sources.get(definition.sourceEntity);
    if (!source) {
      // No verified source adapter — return empty rather than guessing a query.
      return [];
    }
    return source.fetchSeries(definition.tenantId, definition.sourceEntity, definition.sourceField, fromDate, toDate);
  }
}

export const analyticsQueryService = new AnalyticsQueryService();
