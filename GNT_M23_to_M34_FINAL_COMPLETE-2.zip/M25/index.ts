/**
 * M25 — Real-Time, Events & Notification Center
 * index.ts — Public M25 exports.
 * PROVIDE (per blueprint): WebSocket, event bus interface, notification interface.
 */

export { EventEmitter, eventEmitter, type GntEvent, type EmitInput, type EventTransport } from './events/event-emitter';
export { EventRouter, eventRouter, type EventHandler } from './events/event-router';
export { EventRegistry, eventRegistry, EventRegistryError, type RegisteredEventDefinition } from './events/event-registry';

export {
  WebSocketServer,
  type SocketConnection,
} from './websocket/websocket.server';
export {
  WebSocketAuthGuard,
  WebSocketAuthError,
  type VerifiedSocketIdentity,
  type TokenVerifier,
} from './websocket/websocket-auth.guard';
export { WebSocketRouter } from './websocket/websocket-router';

export {
  NotificationsService,
  type NotificationRecord,
  type NotificationStore,
  type CreateNotificationInput,
} from './notifications/notifications.service';
export {
  NotificationRouter,
  notificationRouter,
  type NotificationPayload,
  type ChannelSender,
} from './notifications/notification-router';
export {
  NotificationPreferencesService,
  type NotificationPreference,
  type NotificationPreferenceRepository,
  type NotificationChannel,
} from './notifications/notification-preferences.service';
