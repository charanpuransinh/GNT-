/**
 * M25 — events/event-emitter.ts
 * OWN: Publish application events, following the Event Contract (Section 22).
 *
 * VERIFICATION NEEDED: the project's real shared EventBus class (referenced
 * in project memory as already built in the common infrastructure layer).
 * This depends on an injected EventTransport adapter rather than importing
 * that class's internals directly.
 */

export interface GntEvent {
  eventId: string;
  eventName: string;
  occurredAt: string;
  tenantId: string;
  actorId: string;
  correlationId: string;
  entityType: string;
  entityId: string;
  payloadVersion: number;
  payload: Record<string, unknown>;
}

export interface EventTransport {
  publish(event: GntEvent): Promise<void>;
}

class InMemoryEventTransport implements EventTransport {
  async publish(): Promise<void> {
    // no-op fallback; real wiring must inject the verified shared EventBus
  }
}

export interface EmitInput {
  eventName: string;
  tenantId: string;
  actorId: string;
  correlationId: string;
  entityType: string;
  entityId: string;
  payload?: Record<string, unknown>;
}

export class EventEmitter {
  constructor(private readonly transport: EventTransport = new InMemoryEventTransport()) {}

  async emit(input: EmitInput): Promise<GntEvent> {
    const event: GntEvent = {
      eventId: `evt_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`,
      eventName: input.eventName,
      occurredAt: new Date().toISOString(),
      tenantId: input.tenantId,
      actorId: input.actorId,
      correlationId: input.correlationId,
      entityType: input.entityType,
      entityId: input.entityId,
      payloadVersion: 1,
      payload: input.payload ?? {},
    };
    await this.transport.publish(event);
    return event;
  }
}

export const eventEmitter = new EventEmitter();
