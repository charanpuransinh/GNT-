/**
 * M25 — events/event-registry.ts
 * OWN: Maintain approved event definitions.
 * Event Contract (Section 22): every event must carry eventId, eventName,
 * occurredAt, tenantId, actorId, correlationId, entityType, entityId,
 * payloadVersion, payload.
 */

export interface RegisteredEventDefinition {
  eventName: string;
  ownerModule: string;
  description: string;
  payloadVersion: number;
}

export class EventRegistryError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'EventRegistryError';
  }
}

export class EventRegistry {
  private definitions = new Map<string, RegisteredEventDefinition>();

  register(definition: RegisteredEventDefinition): void {
    if (this.definitions.has(definition.eventName)) {
      throw new EventRegistryError(`Event "${definition.eventName}" is already registered`);
    }
    this.definitions.set(definition.eventName, definition);
  }

  isRegistered(eventName: string): boolean {
    return this.definitions.has(eventName);
  }

  get(eventName: string): RegisteredEventDefinition | undefined {
    return this.definitions.get(eventName);
  }

  list(): RegisteredEventDefinition[] {
    return [...this.definitions.values()];
  }
}

export const eventRegistry = new EventRegistry();

// Pre-register M25's own events so publishers/subscribers can validate against it.
[
  'NOTIFICATION.CREATED',
  'NOTIFICATION.SENT',
  'NOTIFICATION.FAILED',
  'EVENT.PUBLISHED',
  'SOCKET.CONNECTED',
  'SOCKET.DISCONNECTED',
].forEach((eventName) =>
  eventRegistry.register({ eventName, ownerModule: 'M25', description: 'M25-owned event', payloadVersion: 1 }),
);
