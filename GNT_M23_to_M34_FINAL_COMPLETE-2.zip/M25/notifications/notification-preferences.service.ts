/**
 * M25 — notifications/notification-preferences.service.ts
 * OWN: Manage user/tenant notification preferences.
 * Backs table: notification_preference (proposed, tenant-owned).
 */

export type NotificationChannel = 'IN_APP' | 'EMAIL' | 'SMS' | 'PUSH';

export interface NotificationPreference {
  userId: string;
  tenantId: string;
  category: string;
  channels: NotificationChannel[];
  enabled: boolean;
}

export interface NotificationPreferenceRepository {
  find(userId: string, tenantId: string, category: string): Promise<NotificationPreference | null>;
  upsert(pref: NotificationPreference): Promise<void>;
}

const DEFAULT_CHANNELS: NotificationChannel[] = ['IN_APP'];

export class NotificationPreferencesService {
  constructor(private readonly repository: NotificationPreferenceRepository) {}

  async getEffectiveChannels(userId: string, tenantId: string, category: string): Promise<NotificationChannel[]> {
    const pref = await this.repository.find(userId, tenantId, category);
    if (!pref || !pref.enabled) return pref?.enabled === false ? [] : DEFAULT_CHANNELS;
    return pref.channels.length > 0 ? pref.channels : DEFAULT_CHANNELS;
  }

  async setPreference(pref: NotificationPreference): Promise<void> {
    await this.repository.upsert(pref);
  }
}
