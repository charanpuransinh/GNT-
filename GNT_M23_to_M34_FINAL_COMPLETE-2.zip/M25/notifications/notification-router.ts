/**
 * M25 — notifications/notification-router.ts
 * OWN: Route notification channels.
 *
 * VERIFICATION NEEDED: real email/SMS/push delivery providers. Depends on
 * injected ChannelSender adapters per channel — never guesses provider
 * credentials or APIs (Rule 26: secrets via the approved secret mechanism only).
 */

import { NotificationChannel } from './notification-preferences.service';

export interface NotificationPayload {
  title: string;
  body: string;
  data?: Record<string, unknown>;
}

export interface ChannelSender {
  send(userId: string, tenantId: string, payload: NotificationPayload): Promise<{ delivered: boolean; error?: string }>;
}

export class NotificationRouter {
  private senders = new Map<NotificationChannel, ChannelSender>();

  registerSender(channel: NotificationChannel, sender: ChannelSender): void {
    this.senders.set(channel, sender);
  }

  async routeToChannels(
    channels: NotificationChannel[],
    userId: string,
    tenantId: string,
    payload: NotificationPayload,
  ): Promise<Record<string, { delivered: boolean; error?: string }>> {
    const results: Record<string, { delivered: boolean; error?: string }> = {};

    await Promise.all(
      channels.map(async (channel) => {
        const sender = this.senders.get(channel);
        if (!sender) {
          results[channel] = { delivered: false, error: 'NO_SENDER_REGISTERED' };
          return;
        }
        try {
          results[channel] = await sender.send(userId, tenantId, payload);
        } catch (err) {
          results[channel] = { delivered: false, error: err instanceof Error ? err.message : 'UNKNOWN_ERROR' };
        }
      }),
    );

    return results;
  }
}

export const notificationRouter = new NotificationRouter();
