/**
 * M25 — notifications/notifications.service.ts
 * OWN: Create and track notifications.
 * Backs table: notification (proposed, tenant-owned).
 */

import { NotificationPreferencesService } from './notification-preferences.service';
import { NotificationRouter, NotificationPayload } from './notification-router';
import { EventEmitter } from '../events/event-emitter';

export interface NotificationRecord {
  id: string;
  tenantId: string;
  userId: string;
  category: string;
  title: string;
  body: string;
  status: 'PENDING' | 'SENT' | 'FAILED';
  createdAt: string;
}

export interface NotificationStore {
  insert(record: NotificationRecord): Promise<void>;
  updateStatus(id: string, status: NotificationRecord['status']): Promise<void>;
}

export interface CreateNotificationInput {
  tenantId: string;
  userId: string;
  category: string;
  payload: NotificationPayload;
  actorId: string;
  correlationId: string;
}

export class NotificationsService {
  constructor(
    private readonly store: NotificationStore,
    private readonly preferences: NotificationPreferencesService,
    private readonly router: NotificationRouter,
    private readonly events: EventEmitter,
  ) {}

  async create(input: CreateNotificationInput): Promise<NotificationRecord> {
    const record: NotificationRecord = {
      id: `notif_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`,
      tenantId: input.tenantId,
      userId: input.userId,
      category: input.category,
      title: input.payload.title,
      body: input.payload.body,
      status: 'PENDING',
      createdAt: new Date().toISOString(),
    };
    await this.store.insert(record);

    await this.events.emit({
      eventName: 'NOTIFICATION.CREATED',
      tenantId: input.tenantId,
      actorId: input.actorId,
      correlationId: input.correlationId,
      entityType: 'notification',
      entityId: record.id,
      payload: { category: input.category },
    });

    const channels = await this.preferences.getEffectiveChannels(input.userId, input.tenantId, input.category);
    if (channels.length === 0) {
      await this.store.updateStatus(record.id, 'FAILED');
      return { ...record, status: 'FAILED' };
    }

    const results = await this.router.routeToChannels(channels, input.userId, input.tenantId, input.payload);
    const anyDelivered = Object.values(results).some((r) => r.delivered);
    const finalStatus = anyDelivered ? 'SENT' : 'FAILED';
    await this.store.updateStatus(record.id, finalStatus);

    await this.events.emit({
      eventName: anyDelivered ? 'NOTIFICATION.SENT' : 'NOTIFICATION.FAILED',
      tenantId: input.tenantId,
      actorId: input.actorId,
      correlationId: input.correlationId,
      entityType: 'notification',
      entityId: record.id,
      payload: { channelResults: results },
    });

    return { ...record, status: finalStatus };
  }
}
