/**
 * M25 — websocket/websocket.server.ts
 * OWN: Manage real-time connections.
 *
 * VERIFICATION NEEDED: the actual WebSocket library used by the project
 * (e.g. ws, socket.io) is not confirmed. Written against a minimal
 * SocketConnection abstraction so it is library-agnostic until confirmed.
 */

import { VerifiedSocketIdentity, WebSocketAuthGuard } from './websocket-auth.guard';

export interface SocketConnection {
  id: string;
  send(payload: string): void;
  close(): void;
}

interface TrackedConnection {
  connection: SocketConnection;
  identity: VerifiedSocketIdentity;
  connectedAt: string;
}

export class WebSocketServer {
  private connections = new Map<string, TrackedConnection>();

  constructor(private readonly authGuard: WebSocketAuthGuard) {}

  async handleConnection(connection: SocketConnection, token: string | undefined): Promise<VerifiedSocketIdentity> {
    const identity = await this.authGuard.authenticateConnection(token);
    this.connections.set(connection.id, {
      connection,
      identity,
      connectedAt: new Date().toISOString(),
    });
    return identity;
  }

  handleDisconnection(connectionId: string): void {
    this.connections.delete(connectionId);
  }

  /** Send to a specific tenant's connections only — never cross-tenant broadcast. */
  broadcastToTenant(tenantId: string, payload: string): number {
    let count = 0;
    for (const tracked of this.connections.values()) {
      if (tracked.identity.tenantId === tenantId) {
        tracked.connection.send(payload);
        count += 1;
      }
    }
    return count;
  }

  sendToUser(userId: string, tenantId: string, payload: string): number {
    let count = 0;
    for (const tracked of this.connections.values()) {
      if (tracked.identity.userId === userId && tracked.identity.tenantId === tenantId) {
        tracked.connection.send(payload);
        count += 1;
      }
    }
    return count;
  }

  activeConnectionCount(tenantId?: string): number {
    if (!tenantId) return this.connections.size;
    return [...this.connections.values()].filter((c) => c.identity.tenantId === tenantId).length;
  }
}
