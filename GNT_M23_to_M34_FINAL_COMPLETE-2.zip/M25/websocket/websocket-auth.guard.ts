/**
 * M25 — websocket/websocket-auth.guard.ts
 * OWN: Authenticate and authorize socket connections.
 *
 * VERIFICATION NEEDED: real token-verification mechanism owned by M01/M03.
 * Depends on an injected TokenVerifier adapter — never guesses JWT secret
 * handling or session-store internals.
 */

export interface VerifiedSocketIdentity {
  userId: string;
  tenantId: string;
  role: string;
  permissions: string[];
}

export interface TokenVerifier {
  verify(token: string): Promise<VerifiedSocketIdentity | null>;
}

export class WebSocketAuthError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'WebSocketAuthError';
  }
}

export class WebSocketAuthGuard {
  constructor(private readonly tokenVerifier: TokenVerifier) {}

  async authenticateConnection(token: string | undefined): Promise<VerifiedSocketIdentity> {
    if (!token) {
      throw new WebSocketAuthError('Missing connection token');
    }
    const identity = await this.tokenVerifier.verify(token);
    if (!identity) {
      throw new WebSocketAuthError('Invalid or expired connection token');
    }
    return identity;
  }

  /** A connected socket may only join rooms/channels within its own tenant. */
  authorizeChannelJoin(identity: VerifiedSocketIdentity, channelTenantId: string): void {
    if (identity.tenantId !== channelTenantId) {
      throw new WebSocketAuthError('Cannot join a channel outside your tenant');
    }
  }
}
