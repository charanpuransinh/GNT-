/**
 * M26 — security/search-access-guard.ts
 * OWN: Tenant/permission filtering for search.
 * FORBIDDEN (per blueprint): Returning records outside tenant/scope.
 *
 * VERIFICATION NEEDED: exact M23 AuthorizationService/AuthContext shape —
 * imported by type here; actual instance must be the real M23 singleton
 * once M23 is wired into the shared app, not a re-implementation.
 */

export interface SearchAuthContext {
  userId: string;
  tenantId: string;
  permissions: string[];
}

export interface SearchAccessCheckInput {
  auth: SearchAuthContext;
  requestedTenantId: string;
  entityTypes: string[];
}

const SEARCH_USE_PERMISSION = 'M26.SEARCH.USE';
const SEARCH_ADVANCED_PERMISSION = 'M26.SEARCH.ADVANCED';

/** Entity types that require the advanced-search permission beyond basic use. */
const ADVANCED_ENTITY_TYPES = new Set(['payroll', 'salary', 'employee_confidential']);

export class SearchAccessDeniedError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'SearchAccessDeniedError';
  }
}

export class SearchAccessGuard {
  enforce(input: SearchAccessCheckInput): void {
    const { auth, requestedTenantId, entityTypes } = input;

    if (auth.tenantId !== requestedTenantId) {
      throw new SearchAccessDeniedError('Cross-tenant search denied');
    }
    if (!auth.permissions.includes(SEARCH_USE_PERMISSION)) {
      throw new SearchAccessDeniedError('Missing M26.SEARCH.USE permission');
    }
    const needsAdvanced = entityTypes.some((t) => ADVANCED_ENTITY_TYPES.has(t));
    if (needsAdvanced && !auth.permissions.includes(SEARCH_ADVANCED_PERMISSION)) {
      throw new SearchAccessDeniedError('Missing M26.SEARCH.ADVANCED permission for requested entity types');
    }
  }
}

export const searchAccessGuard = new SearchAccessGuard();
