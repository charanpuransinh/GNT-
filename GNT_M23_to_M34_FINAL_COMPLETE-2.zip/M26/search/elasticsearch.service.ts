/**
 * M26 — search/elasticsearch.service.ts
 * OWN: External search-engine adapter.
 *
 * VERIFICATION NEEDED: whether the project actually uses Elasticsearch or
 * another engine (Rule 1). Expressed against a SearchEngineClient interface
 * so the real client can be swapped in without touching callers.
 */

import { BuiltSearchQuery } from './search-query-builder';

export interface SearchDocument {
  id: string;
  entityType: string;
  tenantId: string;
  [field: string]: unknown;
}

export interface SearchEngineResult {
  items: SearchDocument[];
  total: number;
}

export interface SearchEngineClient {
  search(query: BuiltSearchQuery): Promise<SearchEngineResult>;
  indexDocument(doc: SearchDocument): Promise<void>;
  deleteDocument(entityType: string, id: string, tenantId: string): Promise<void>;
  rebuildIndex(tenantId: string): Promise<{ indexed: number }>;
}

/** In-memory fallback — replace with the verified real search engine when wiring. */
class InMemorySearchEngineClient implements SearchEngineClient {
  private documents: SearchDocument[] = [];

  async search(query: BuiltSearchQuery): Promise<SearchEngineResult> {
    const matches = this.documents.filter((doc) => {
      if (doc.tenantId !== query.tenantId) return false;
      if (query.entityTypes.length > 0 && !query.entityTypes.includes(doc.entityType)) return false;
      if (!query.query) return true;
      const haystack = JSON.stringify(doc).toLowerCase();
      return haystack.includes(query.query.toLowerCase());
    });
    return {
      items: matches.slice(query.from, query.from + query.size),
      total: matches.length,
    };
  }

  async indexDocument(doc: SearchDocument): Promise<void> {
    this.documents = this.documents.filter((d) => !(d.id === doc.id && d.entityType === doc.entityType));
    this.documents.push(doc);
  }

  async deleteDocument(entityType: string, id: string, tenantId: string): Promise<void> {
    this.documents = this.documents.filter(
      (d) => !(d.entityType === entityType && d.id === id && d.tenantId === tenantId),
    );
  }

  async rebuildIndex(tenantId: string): Promise<{ indexed: number }> {
    const count = this.documents.filter((d) => d.tenantId === tenantId).length;
    return { indexed: count };
  }
}

export class ElasticsearchService {
  constructor(private readonly client: SearchEngineClient = new InMemorySearchEngineClient()) {}

  search(query: BuiltSearchQuery): Promise<SearchEngineResult> {
    return this.client.search(query);
  }
  index(doc: SearchDocument): Promise<void> {
    return this.client.indexDocument(doc);
  }
  remove(entityType: string, id: string, tenantId: string): Promise<void> {
    return this.client.deleteDocument(entityType, id, tenantId);
  }
  rebuild(tenantId: string): Promise<{ indexed: number }> {
    return this.client.rebuildIndex(tenantId);
  }
}

export const elasticsearchService = new ElasticsearchService();
