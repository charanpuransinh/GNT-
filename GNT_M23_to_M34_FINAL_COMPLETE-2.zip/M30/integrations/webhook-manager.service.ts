/**
 * M30 — integrations/webhook-manager.service.ts
 * OWN: Webhook validation/routing.
 * Rule 11: idempotent. Security Test Matrix: webhook spoofing, replay attack.
 */

export interface IncomingWebhook {
  provider: string;
  tenantId: string;
  signature: string;
  rawBody: string;
  idempotencyKey: string;
}

export interface SignatureVerifier {
  verify(provider: string, rawBody: string, signature: string): boolean;
}

export interface WebhookHandler {
  handle(tenantId: string, payload: unknown): Promise<void>;
}

export class WebhookVerificationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'WebhookVerificationError';
  }
}

export class WebhookManagerService {
  private handlers = new Map<string, WebhookHandler>();
  private processedKeys = new Set<string>();

  constructor(private readonly verifier: SignatureVerifier) {}

  registerHandler(provider: string, handler: WebhookHandler): void {
    this.handlers.set(provider, handler);
  }

  async process(webhook: IncomingWebhook): Promise<{ processed: boolean; reason?: string }> {
    if (!this.verifier.verify(webhook.provider, webhook.rawBody, webhook.signature)) {
      throw new WebhookVerificationError('Invalid webhook signature');
    }

    const dedupeKey = `${webhook.provider}:${webhook.idempotencyKey}`;
    if (this.processedKeys.has(dedupeKey)) {
      return { processed: false, reason: 'DUPLICATE_WEBHOOK' };
    }

    const handler = this.handlers.get(webhook.provider);
    if (!handler) {
      return { processed: false, reason: 'NO_HANDLER_REGISTERED' };
    }

    await handler.handle(webhook.tenantId, JSON.parse(webhook.rawBody));
    this.processedKeys.add(dedupeKey);
    return { processed: true };
  }
}
