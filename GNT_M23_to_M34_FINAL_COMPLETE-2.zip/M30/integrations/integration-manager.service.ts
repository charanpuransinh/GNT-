/**
 * M30 — integrations/integration-manager.service.ts
 * OWN: Integration lifecycle.
 * Rule 26: secrets via the approved secret mechanism only — this service
 * stores only a secretRef, never a raw secret value.
 */

export interface IntegrationConnection {
  connectionId: string;
  tenantId: string;
  provider: string;
  secretRef: string; // reference into the approved secret store, never the raw secret
  status: 'ACTIVE' | 'DISCONNECTED' | 'ERROR';
  connectedAt: string;
}

export interface IntegrationRepository {
  save(connection: IntegrationConnection): Promise<void>;
  find(connectionId: string, tenantId: string): Promise<IntegrationConnection | null>;
  listForTenant(tenantId: string): Promise<IntegrationConnection[]>;
}

export class IntegrationManagerService {
  constructor(private readonly repository: IntegrationRepository) {}

  async connect(tenantId: string, provider: string, secretRef: string): Promise<IntegrationConnection> {
    const connection: IntegrationConnection = {
      connectionId: `intg_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`,
      tenantId,
      provider,
      secretRef,
      status: 'ACTIVE',
      connectedAt: new Date().toISOString(),
    };
    await this.repository.save(connection);
    return connection;
  }

  async disconnect(connectionId: string, tenantId: string): Promise<void> {
    const connection = await this.repository.find(connectionId, tenantId);
    if (!connection) return;
    connection.status = 'DISCONNECTED';
    await this.repository.save(connection);
  }

  async listForTenant(tenantId: string): Promise<IntegrationConnection[]> {
    return this.repository.listForTenant(tenantId);
  }
}
