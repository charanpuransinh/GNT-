/**
 * M30 — integrations/payment-gateway.service.ts
 * OWN: Payment gateway adapter.
 * Billing/Financial Safety (Section 28): may request financial operations
 * only through M08/M09/M10/M11's approved contracts — this service never
 * posts a ledger entry or invoice itself.
 */

import { IdempotencyService } from '../reliability/idempotency.service';
import { RetryService, retryService } from '../reliability/retry.service';

export interface PaymentGatewayRequest {
  tenantId: string;
  amount: number;
  currency: string;
  idempotencyKey: string;
  metadata?: Record<string, unknown>;
}

export interface PaymentGatewayResult {
  success: boolean;
  providerTransactionId?: string;
  errorCode?: string;
}

export interface PaymentGatewayClient {
  charge(request: PaymentGatewayRequest): Promise<PaymentGatewayResult>;
}

export class PaymentGatewayService {
  constructor(
    private readonly client: PaymentGatewayClient,
    private readonly idempotency: IdempotencyService,
    private readonly retry: RetryService = retryService,
  ) {}

  async charge(request: PaymentGatewayRequest): Promise<PaymentGatewayResult> {
    return this.idempotency.runOnce(request.tenantId, request.idempotencyKey, () =>
      this.retry.withRetry(() => this.client.charge(request), { maxAttempts: 2 }),
    );
  }
}
