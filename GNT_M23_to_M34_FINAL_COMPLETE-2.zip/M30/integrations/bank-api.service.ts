/**
 * M30 — integrations/bank-api.service.ts
 * OWN: Bank API adapter.
 *
 * VERIFICATION NEEDED: real bank integration provider. Never a live
 * financial-posting path itself — Rule (Billing/Financial Safety, Section
 * 28): M30 requests financial operations only through M08/M09/M11's
 * approved contracts, never by writing ledgers directly.
 */

import { RetryService, retryService } from '../reliability/retry.service';
import { TimeoutService, timeoutService } from '../reliability/timeout.service';

export interface BankStatementLine {
  externalRef: string;
  amount: number;
  currency: string;
  valueDate: string;
  description: string;
}

export interface BankApiClient {
  fetchStatement(tenantId: string, accountRef: string, fromDate: string, toDate: string): Promise<BankStatementLine[]>;
}

export class BankApiService {
  constructor(
    private readonly client: BankApiClient,
    private readonly retry: RetryService = retryService,
    private readonly timeout: TimeoutService = timeoutService,
  ) {}

  /** Read-only fetch — reconciliation/posting decisions belong to M11, not here. */
  async fetchStatement(tenantId: string, accountRef: string, fromDate: string, toDate: string): Promise<BankStatementLine[]> {
    return this.retry.withRetry(() =>
      this.timeout.withTimeout(() => this.client.fetchStatement(tenantId, accountRef, fromDate, toDate), 10000),
    );
  }
}
