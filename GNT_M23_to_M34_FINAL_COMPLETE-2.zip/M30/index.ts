/**
 * M30 — AI/ML & Decision Intelligence
 * index.ts — Public M30 exports.
 * FORBIDDEN (per blueprint): autonomous financial posting without configured
 * authorization; unrestricted AI database access — enforced by ai-data-guard.ts
 * and the fact that no file here writes to a financial ledger directly.
 */

export { AiDataGuard, aiDataGuard, AiDataGuardViolationError, type AiRequestContext } from './ai/ai-data-guard';
export { MlClassifierService, type ClassificationRequest, type ClassificationResult, type ClassifierProvider } from './ai/ml-classifier.service';
export { FraudDetectorService, type FraudScoringRequest, type FraudScore, type FraudModelProvider } from './ai/fraud-detector.service';
export { ForecastService, type ForecastRequest, type ForecastPoint, type ForecastProvider } from './ai/forecast.service';

export { BankApiService, type BankStatementLine, type BankApiClient } from './integrations/bank-api.service';
export { PaymentGatewayService, type PaymentGatewayRequest, type PaymentGatewayResult, type PaymentGatewayClient } from './integrations/payment-gateway.service';
export { IntegrationManagerService, type IntegrationConnection, type IntegrationRepository } from './integrations/integration-manager.service';
export { WebhookManagerService, WebhookVerificationError, type IncomingWebhook, type SignatureVerifier, type WebhookHandler } from './integrations/webhook-manager.service';

export { RetryService, retryService, RetryExhaustedError, type RetryOptions } from './reliability/retry.service';
export { TimeoutService, timeoutService, TimeoutError } from './reliability/timeout.service';
export { IdempotencyService, type IdempotencyRecord, type IdempotencyStore } from './reliability/idempotency.service';
