/**
 * M33 — reliability/retry-policy.service.ts
 * OWN: Controlled retry rules (integration-specific — M30 has its own
 * general-purpose retry.service.ts; M33 owns integration-specific policy
 * on top, e.g. per-connector overrides).
 */

export interface RetryPolicyConfig {
  connectorKey: string;
  maxAttempts: number;
  backoffMultiplier: number;
  retryableStatusCodes: number[];
}

const DEFAULT_POLICY: Omit<RetryPolicyConfig, 'connectorKey'> = {
  maxAttempts: 3,
  backoffMultiplier: 2,
  retryableStatusCodes: [429, 502, 503, 504],
};

export class RetryPolicyService {
  private policies = new Map<string, RetryPolicyConfig>();

  setPolicy(config: RetryPolicyConfig): void {
    this.policies.set(config.connectorKey, config);
  }

  getPolicy(connectorKey: string): RetryPolicyConfig {
    return this.policies.get(connectorKey) ?? { connectorKey, ...DEFAULT_POLICY };
  }

  isRetryable(connectorKey: string, statusCode: number): boolean {
    return this.getPolicy(connectorKey).retryableStatusCodes.includes(statusCode);
  }
}

export const retryPolicyService = new RetryPolicyService();
