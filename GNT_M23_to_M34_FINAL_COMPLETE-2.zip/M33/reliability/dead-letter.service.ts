/**
 * M33 — reliability/dead-letter.service.ts
 * OWN: Isolate permanently failed messages.
 * Backs table: dead_letter_event (proposed, tenant-owned).
 */

export interface DeadLetterEntry {
  entryId: string;
  tenantId: string;
  connectorKey: string;
  originalPayload: Record<string, unknown>;
  failureReason: string;
  attemptCount: number;
  deadLetteredAt: string;
}

export interface DeadLetterStore {
  insert(entry: DeadLetterEntry): Promise<void>;
  listForTenant(tenantId: string, connectorKey?: string): Promise<DeadLetterEntry[]>;
  remove(entryId: string, tenantId: string): Promise<void>;
}

export class DeadLetterService {
  constructor(private readonly store: DeadLetterStore) {}

  async record(
    tenantId: string,
    connectorKey: string,
    originalPayload: Record<string, unknown>,
    failureReason: string,
    attemptCount: number,
  ): Promise<DeadLetterEntry> {
    const entry: DeadLetterEntry = {
      entryId: `dlq_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`,
      tenantId,
      connectorKey,
      originalPayload,
      failureReason,
      attemptCount,
      deadLetteredAt: new Date().toISOString(),
    };
    await this.store.insert(entry);
    return entry;
  }

  async listForTenant(tenantId: string, connectorKey?: string): Promise<DeadLetterEntry[]> {
    return this.store.listForTenant(tenantId, connectorKey);
  }

  /** Human-initiated reprocessing removes the entry — never auto-replayed silently. */
  async discard(entryId: string, tenantId: string): Promise<void> {
    await this.store.remove(entryId, tenantId);
  }
}
