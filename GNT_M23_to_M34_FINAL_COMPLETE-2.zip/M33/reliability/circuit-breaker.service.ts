/**
 * M33 — reliability/circuit-breaker.service.ts
 * OWN: Stop repeated calls to failing services.
 * Rule 12: external service failure must not corrupt GNT transaction state.
 */

export type CircuitState = 'CLOSED' | 'OPEN' | 'HALF_OPEN';

export interface CircuitBreakerOptions {
  failureThreshold: number;
  resetTimeoutMs: number;
}

const DEFAULT_OPTIONS: CircuitBreakerOptions = { failureThreshold: 5, resetTimeoutMs: 30000 };

class CircuitBreaker {
  private state: CircuitState = 'CLOSED';
  private failureCount = 0;
  private lastFailureAt = 0;

  constructor(private readonly options: CircuitBreakerOptions) {}

  canAttempt(): boolean {
    if (this.state === 'OPEN') {
      if (Date.now() - this.lastFailureAt >= this.options.resetTimeoutMs) {
        this.state = 'HALF_OPEN';
        return true;
      }
      return false;
    }
    return true;
  }

  recordSuccess(): void {
    this.failureCount = 0;
    this.state = 'CLOSED';
  }

  recordFailure(): void {
    this.failureCount += 1;
    this.lastFailureAt = Date.now();
    if (this.failureCount >= this.options.failureThreshold) {
      this.state = 'OPEN';
    }
  }

  getState(): CircuitState {
    return this.state;
  }
}

export class CircuitOpenError extends Error {
  constructor(public readonly connectorKey: string) {
    super(`Circuit is open for "${connectorKey}" — external calls are paused`);
    this.name = 'CircuitOpenError';
  }
}

export class CircuitBreakerService {
  private breakers = new Map<string, CircuitBreaker>();

  private getBreaker(key: string, options: Partial<CircuitBreakerOptions> = {}): CircuitBreaker {
    if (!this.breakers.has(key)) {
      this.breakers.set(key, new CircuitBreaker({ ...DEFAULT_OPTIONS, ...options }));
    }
    return this.breakers.get(key)!;
  }

  async execute<T>(key: string, operation: () => Promise<T>, options?: Partial<CircuitBreakerOptions>): Promise<T> {
    const breaker = this.getBreaker(key, options);
    if (!breaker.canAttempt()) {
      throw new CircuitOpenError(key);
    }
    try {
      const result = await operation();
      breaker.recordSuccess();
      return result;
    } catch (err) {
      breaker.recordFailure();
      throw err;
    }
  }

  getState(key: string): CircuitState {
    return this.getBreaker(key).getState();
  }
}

export const circuitBreakerService = new CircuitBreakerService();
