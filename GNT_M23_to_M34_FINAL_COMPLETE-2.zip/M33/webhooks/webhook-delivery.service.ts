/**
 * M33 — webhooks/webhook-delivery.service.ts
 * OWN: Send outbound webhooks.
 * Backs table: webhook_delivery (proposed, tenant-owned).
 */

import { ExternalApiClientService } from '../api/external-api-client.service';

export interface OutboundWebhookSubscription {
  subscriptionId: string;
  tenantId: string;
  url: string;
  eventNames: string[];
  secretRef?: string;
}

export interface WebhookDeliveryRecord {
  deliveryId: string;
  subscriptionId: string;
  tenantId: string;
  eventName: string;
  statusCode?: number;
  delivered: boolean;
  attemptedAt: string;
}

export interface WebhookDeliveryStore {
  insert(record: WebhookDeliveryRecord): Promise<void>;
}

export class WebhookDeliveryService {
  constructor(
    private readonly apiClient: ExternalApiClientService,
    private readonly store: WebhookDeliveryStore,
  ) {}

  async deliver(subscription: OutboundWebhookSubscription, eventName: string, payload: Record<string, unknown>): Promise<WebhookDeliveryRecord> {
    let statusCode: number | undefined;
    let delivered = false;

    try {
      const response = await this.apiClient.call({
        connectorKey: `webhook-out:${subscription.subscriptionId}`,
        method: 'POST',
        url: subscription.url,
        body: payload,
      });
      statusCode = response.statusCode;
      delivered = response.statusCode >= 200 && response.statusCode < 300;
    } catch {
      delivered = false;
    }

    const record: WebhookDeliveryRecord = {
      deliveryId: `whd_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`,
      subscriptionId: subscription.subscriptionId,
      tenantId: subscription.tenantId,
      eventName,
      statusCode,
      delivered,
      attemptedAt: new Date().toISOString(),
    };
    await this.store.insert(record);
    return record;
  }
}
