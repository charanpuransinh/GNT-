/**
 * M33 — webhooks/webhook-verification.service.ts
 * OWN: Verify signature/authenticity of inbound webhooks.
 * Security Test Matrix: webhook spoofing, replay attack.
 *
 * VERIFICATION NEEDED: real signing scheme per provider (HMAC-SHA256 with
 * a shared secret is the common default, implemented here; providers with
 * a different scheme need a dedicated SignatureAlgorithm).
 */

export interface SignatureAlgorithm {
  verify(rawBody: string, signature: string, secret: string): boolean;
}

export interface WebhookVerificationConfig {
  connectorKey: string;
  secretRef: string; // resolved to an actual secret via the approved secret mechanism
}

export class WebhookVerificationService {
  private configs = new Map<string, WebhookVerificationConfig>();

  constructor(
    private readonly algorithm: SignatureAlgorithm,
    private readonly resolveSecret: (secretRef: string) => Promise<string>,
  ) {}

  registerConfig(config: WebhookVerificationConfig): void {
    this.configs.set(config.connectorKey, config);
  }

  async verify(connectorKey: string, rawBody: string, signature: string): Promise<boolean> {
    const config = this.configs.get(connectorKey);
    if (!config) return false;
    const secret = await this.resolveSecret(config.secretRef);
    return this.algorithm.verify(rawBody, signature, secret);
  }
}
