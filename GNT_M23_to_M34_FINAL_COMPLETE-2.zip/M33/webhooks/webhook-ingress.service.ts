/**
 * M33 — webhooks/webhook-ingress.service.ts
 * OWN: Receive external webhooks. Rule 11: idempotent.
 */

import { WebhookVerificationService } from './webhook-verification.service';
import { DeadLetterService } from '../reliability/dead-letter.service';

export interface IncomingWebhookPayload {
  tenantId: string;
  connectorKey: string;
  rawBody: string;
  signature: string;
  idempotencyKey: string;
}

export interface WebhookProcessor {
  process(tenantId: string, payload: unknown): Promise<void>;
}

export class WebhookIngressService {
  private processedKeys = new Set<string>();
  private processors = new Map<string, WebhookProcessor>();

  constructor(
    private readonly verificationService: WebhookVerificationService,
    private readonly deadLetterService: DeadLetterService,
  ) {}

  registerProcessor(connectorKey: string, processor: WebhookProcessor): void {
    this.processors.set(connectorKey, processor);
  }

  async ingest(webhook: IncomingWebhookPayload): Promise<{ accepted: boolean; reason?: string }> {
    const verified = await this.verificationService.verify(webhook.connectorKey, webhook.rawBody, webhook.signature);
    if (!verified) {
      return { accepted: false, reason: 'SIGNATURE_VERIFICATION_FAILED' };
    }

    const dedupeKey = `${webhook.connectorKey}:${webhook.idempotencyKey}`;
    if (this.processedKeys.has(dedupeKey)) {
      return { accepted: false, reason: 'DUPLICATE_WEBHOOK_REPLAY' };
    }

    const processor = this.processors.get(webhook.connectorKey);
    if (!processor) {
      await this.deadLetterService.record(webhook.tenantId, webhook.connectorKey, { rawBody: webhook.rawBody }, 'NO_PROCESSOR_REGISTERED', 1);
      return { accepted: false, reason: 'NO_PROCESSOR_REGISTERED' };
    }

    try {
      await processor.process(webhook.tenantId, JSON.parse(webhook.rawBody));
      this.processedKeys.add(dedupeKey);
      return { accepted: true };
    } catch (err) {
      await this.deadLetterService.record(
        webhook.tenantId,
        webhook.connectorKey,
        { rawBody: webhook.rawBody },
        err instanceof Error ? err.message : 'PROCESSING_FAILED',
        1,
      );
      return { accepted: false, reason: 'PROCESSING_FAILED' };
    }
  }
}
