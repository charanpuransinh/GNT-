/**
 * M33 — api/api-version.service.ts
 * OWN: Version compatibility for external API integrations.
 */

export interface ApiVersionInfo {
  connectorKey: string;
  currentVersion: string;
  minSupportedVersion: string;
  deprecatedAfter?: string; // ISO date
}

export class UnsupportedApiVersionError extends Error {
  constructor(connectorKey: string, version: string) {
    super(`API version "${version}" for connector "${connectorKey}" is no longer supported`);
    this.name = 'UnsupportedApiVersionError';
  }
}

export class ApiVersionService {
  private versions = new Map<string, ApiVersionInfo>();

  register(info: ApiVersionInfo): void {
    this.versions.set(info.connectorKey, info);
  }

  assertSupported(connectorKey: string, requestedVersion: string): void {
    const info = this.versions.get(connectorKey);
    if (!info) return; // unknown connector — no version policy configured

    if (this.compareVersions(requestedVersion, info.minSupportedVersion) < 0) {
      throw new UnsupportedApiVersionError(connectorKey, requestedVersion);
    }
  }

  private compareVersions(a: string, b: string): number {
    const partsA = a.split('.').map(Number);
    const partsB = b.split('.').map(Number);
    for (let i = 0; i < Math.max(partsA.length, partsB.length); i++) {
      const diff = (partsA[i] ?? 0) - (partsB[i] ?? 0);
      if (diff !== 0) return diff;
    }
    return 0;
  }
}

export const apiVersionService = new ApiVersionService();
