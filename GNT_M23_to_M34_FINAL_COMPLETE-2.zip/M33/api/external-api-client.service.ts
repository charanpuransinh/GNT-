/**
 * M33 — api/external-api-client.service.ts
 * OWN: Standard external API client — composes rate-limit, circuit-breaker
 * and retry-policy so every outbound integration call goes through the
 * same reliability layer.
 *
 * VERIFICATION NEEDED: real HTTP client used elsewhere in GNT (if any).
 * Depends on an injected HttpTransport rather than assuming a library.
 */

import { RateLimitService, rateLimitService } from './rate-limit.service';
import { CircuitBreakerService, circuitBreakerService } from '../reliability/circuit-breaker.service';
import { RetryPolicyService, retryPolicyService } from '../reliability/retry-policy.service';

export interface OutboundRequest {
  connectorKey: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE';
  url: string;
  headers?: Record<string, string>;
  body?: unknown;
}

export interface OutboundResponse {
  statusCode: number;
  body: unknown;
}

export interface HttpTransport {
  send(request: OutboundRequest): Promise<OutboundResponse>;
}

export class ExternalApiClientService {
  constructor(
    private readonly transport: HttpTransport,
    private readonly rateLimit: RateLimitService = rateLimitService,
    private readonly circuitBreaker: CircuitBreakerService = circuitBreakerService,
    private readonly retryPolicyService_: RetryPolicyService = retryPolicyService,
  ) {}

  async call(request: OutboundRequest): Promise<OutboundResponse> {
    this.rateLimit.consume(request.connectorKey);

    const policy = this.retryPolicyService_.getPolicy(request.connectorKey);
    let lastResponse: OutboundResponse | undefined;
    let lastError: unknown;

    for (let attempt = 1; attempt <= policy.maxAttempts; attempt++) {
      try {
        lastResponse = await this.circuitBreaker.execute(request.connectorKey, () => this.transport.send(request));
        if (!this.retryPolicyService_.isRetryable(request.connectorKey, lastResponse.statusCode)) {
          return lastResponse;
        }
        if (attempt === policy.maxAttempts) return lastResponse;
      } catch (err) {
        lastError = err;
        if (attempt === policy.maxAttempts) throw err;
      }
      await this.sleep(200 * policy.backoffMultiplier ** (attempt - 1));
    }

    if (lastResponse) return lastResponse;
    throw lastError ?? new Error('External API call failed with no response');
  }

  private sleep(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
}
