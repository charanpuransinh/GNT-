/**
 * M33 — api/rate-limit.service.ts
 * OWN: Outbound rate limiting (to external APIs — inbound API rate limiting
 * is a separate, app-layer concern outside M33's scope).
 */

interface Bucket {
  tokens: number;
  lastRefillAt: number;
}

export interface RateLimitConfig {
  connectorKey: string;
  maxRequestsPerWindow: number;
  windowMs: number;
}

export class RateLimitExceededError extends Error {
  constructor(public readonly connectorKey: string) {
    super(`Rate limit exceeded for "${connectorKey}"`);
    this.name = 'RateLimitExceededError';
  }
}

export class RateLimitService {
  private buckets = new Map<string, Bucket>();
  private configs = new Map<string, RateLimitConfig>();

  setConfig(config: RateLimitConfig): void {
    this.configs.set(config.connectorKey, config);
  }

  /** Throws RateLimitExceededError if the connector's outbound quota is exhausted. */
  consume(connectorKey: string): void {
    const config = this.configs.get(connectorKey);
    if (!config) return; // no configured limit — allow

    const now = Date.now();
    let bucket = this.buckets.get(connectorKey);
    if (!bucket || now - bucket.lastRefillAt >= config.windowMs) {
      bucket = { tokens: config.maxRequestsPerWindow, lastRefillAt: now };
    }

    if (bucket.tokens <= 0) {
      this.buckets.set(connectorKey, bucket);
      throw new RateLimitExceededError(connectorKey);
    }

    bucket.tokens -= 1;
    this.buckets.set(connectorKey, bucket);
  }
}

export const rateLimitService = new RateLimitService();
