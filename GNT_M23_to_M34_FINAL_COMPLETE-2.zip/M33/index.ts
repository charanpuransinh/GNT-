/**
 * M33 — Integration Hub & Reliability
 * index.ts — Public M33 exports.
 */

export { ConnectorRegistryService, connectorRegistryService, type ConnectorDefinition } from './connectors/connector-registry.service';
export { ConnectorConfigService, type ConnectorConfig, type ConnectorConfigRepository } from './connectors/connector-config.service';
export { ConnectorHealthService, connectorHealthService, type HealthStatus, type HealthCheckResult, type HealthCheckClient } from './connectors/connector-health.service';

export { ExternalApiClientService, type OutboundRequest, type OutboundResponse, type HttpTransport } from './api/external-api-client.service';
export { ApiVersionService, apiVersionService, UnsupportedApiVersionError, type ApiVersionInfo } from './api/api-version.service';
export { RateLimitService, rateLimitService, RateLimitExceededError, type RateLimitConfig } from './api/rate-limit.service';

export { WebhookIngressService, type IncomingWebhookPayload, type WebhookProcessor } from './webhooks/webhook-ingress.service';
export { WebhookVerificationService, type SignatureAlgorithm, type WebhookVerificationConfig } from './webhooks/webhook-verification.service';
export { WebhookDeliveryService, type OutboundWebhookSubscription, type WebhookDeliveryRecord, type WebhookDeliveryStore } from './webhooks/webhook-delivery.service';

export { CircuitBreakerService, circuitBreakerService, CircuitOpenError, type CircuitState, type CircuitBreakerOptions } from './reliability/circuit-breaker.service';
export { RetryPolicyService, retryPolicyService, type RetryPolicyConfig } from './reliability/retry-policy.service';
export { DeadLetterService, type DeadLetterEntry, type DeadLetterStore } from './reliability/dead-letter.service';
