/**
 * M33 — connectors/connector-health.service.ts
 * OWN: Connection health checks.
 */

export type HealthStatus = 'HEALTHY' | 'DEGRADED' | 'DOWN' | 'UNKNOWN';

export interface HealthCheckResult {
  connectorKey: string;
  tenantId: string;
  status: HealthStatus;
  latencyMs?: number;
  checkedAt: string;
  errorMessage?: string;
}

export interface HealthCheckClient {
  ping(): Promise<{ ok: boolean; latencyMs: number }>;
}

export class ConnectorHealthService {
  private clients = new Map<string, HealthCheckClient>();

  registerClient(connectorKey: string, client: HealthCheckClient): void {
    this.clients.set(connectorKey, client);
  }

  async check(connectorKey: string, tenantId: string): Promise<HealthCheckResult> {
    const client = this.clients.get(connectorKey);
    const checkedAt = new Date().toISOString();

    if (!client) {
      return { connectorKey, tenantId, status: 'UNKNOWN', checkedAt, errorMessage: 'NO_CLIENT_REGISTERED' };
    }

    try {
      const { ok, latencyMs } = await client.ping();
      return {
        connectorKey,
        tenantId,
        status: ok ? (latencyMs > 2000 ? 'DEGRADED' : 'HEALTHY') : 'DOWN',
        latencyMs,
        checkedAt,
      };
    } catch (err) {
      return {
        connectorKey,
        tenantId,
        status: 'DOWN',
        checkedAt,
        errorMessage: err instanceof Error ? err.message : 'UNKNOWN_ERROR',
      };
    }
  }
}

export const connectorHealthService = new ConnectorHealthService();
