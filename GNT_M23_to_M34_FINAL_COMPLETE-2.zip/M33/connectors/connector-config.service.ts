/**
 * M33 — connectors/connector-config.service.ts
 * OWN: Tenant-specific integration configuration.
 * Backs table: integration_connection (proposed, tenant-owned).
 * Rule 26: secrets stored via the approved secret mechanism — only a
 * secretRef is held here, never a raw secret.
 */

import { ConnectorRegistryService, connectorRegistryService } from './connector-registry.service';

export interface ConnectorConfig {
  configId: string;
  tenantId: string;
  connectorKey: string;
  secretRef?: string;
  settings: Record<string, unknown>;
  enabled: boolean;
}

export interface ConnectorConfigRepository {
  save(config: ConnectorConfig): Promise<void>;
  find(tenantId: string, connectorKey: string): Promise<ConnectorConfig | null>;
}

export class ConnectorConfigService {
  constructor(
    private readonly repository: ConnectorConfigRepository,
    private readonly registry: ConnectorRegistryService = connectorRegistryService,
  ) {}

  async configure(
    tenantId: string,
    connectorKey: string,
    settings: Record<string, unknown>,
    secretRef?: string,
  ): Promise<ConnectorConfig> {
    if (!this.registry.isSupported(connectorKey)) {
      throw new Error(`Connector "${connectorKey}" is not registered`);
    }
    const definition = this.registry.get(connectorKey)!;
    if (definition.requiresSecret && !secretRef) {
      throw new Error(`Connector "${connectorKey}" requires a secretRef`);
    }

    const config: ConnectorConfig = {
      configId: `cfg_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`,
      tenantId,
      connectorKey,
      secretRef,
      settings,
      enabled: true,
    };
    await this.repository.save(config);
    return config;
  }

  async getConfig(tenantId: string, connectorKey: string): Promise<ConnectorConfig | null> {
    return this.repository.find(tenantId, connectorKey);
  }
}
