/**
 * M33 — connectors/connector-registry.service.ts
 * OWN: Register supported connectors.
 */

export interface ConnectorDefinition {
  connectorKey: string;
  displayName: string;
  requiresSecret: boolean;
}

export class ConnectorRegistryService {
  private connectors = new Map<string, ConnectorDefinition>();

  register(definition: ConnectorDefinition): void {
    this.connectors.set(definition.connectorKey, definition);
  }

  get(connectorKey: string): ConnectorDefinition | undefined {
    return this.connectors.get(connectorKey);
  }

  list(): ConnectorDefinition[] {
    return [...this.connectors.values()];
  }

  isSupported(connectorKey: string): boolean {
    return this.connectors.has(connectorKey);
  }
}

export const connectorRegistryService = new ConnectorRegistryService();
