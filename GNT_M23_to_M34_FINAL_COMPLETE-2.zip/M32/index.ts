/**
 * M32 — Workflow & Agentic Automation
 * index.ts — Public M32 exports.
 * AGENT RULE (enforced by agent-safety-guard.service.ts): an agent may
 * never escalate its own permission, impersonate an owner, or bypass
 * approval rules. USE: M13 scheduler, M23 security, M25 events, M30 AI
 * (all via their own public exports — never imported internals).
 */

export { WorkflowDefinitionService, type WorkflowDefinition, type WorkflowStepDefinition, type WorkflowDefinitionRepository } from './workflow/workflow-definition.service';
export { WorkflowEngineService, workflowEngineService, type WorkflowExecutionResult } from './workflow/workflow-engine.service';
export { WorkflowConditionService, workflowConditionService, type SimpleCondition, type ComparisonOperator } from './workflow/workflow-condition.service';
export { WorkflowActionService, workflowActionService, UnknownActionError, type ActionContext, type ActionHandler } from './workflow/workflow-action.service';

export { ApprovalEngineService, type ApprovalRequest, type ApprovalRequestRepository } from './approvals/approval-engine.service';
export { ApprovalPolicyService, type ApprovalPolicy, type ApprovalPolicyRepository } from './approvals/approval-policy.service';
export { ApprovalDelegationService, type DelegationRule, type DelegationRepository } from './approvals/approval-delegation.service';

export { AgentOrchestratorService, type AgentDispatchRequest } from './agents/agent-orchestrator.service';
export { AgentTaskService, type AgentTask, type AgentTaskStatus, type AgentTaskStore } from './agents/agent-task.service';
export { AgentMemoryService, type AgentMemoryEntry, type AgentMemoryStore } from './agents/agent-memory.service';
export { AgentSafetyGuardService, agentSafetyGuardService, AgentSafetyViolationError, type AgentIdentity } from './agents/agent-safety-guard.service';

export { TaskAssignmentService, type TaskAssignment, type AssigneeType, type TaskAssignmentRepository } from './tasks/task-assignment.service';
export { TaskEscalationService, taskEscalationService, type EscalationRule, type EscalationResult } from './tasks/task-escalation.service';
