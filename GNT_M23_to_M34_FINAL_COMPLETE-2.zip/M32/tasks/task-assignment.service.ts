/**
 * M32 — tasks/task-assignment.service.ts
 * OWN: Assign human/agent tasks.
 * Backs table: task_assignment (proposed, tenant-owned).
 */

export type AssigneeType = 'HUMAN' | 'AGENT';

export interface TaskAssignment {
  assignmentId: string;
  tenantId: string;
  taskId: string;
  assigneeType: AssigneeType;
  assigneeId: string;
  assignedAt: string;
  dueAt?: string;
}

export interface TaskAssignmentRepository {
  save(assignment: TaskAssignment): Promise<void>;
  find(assignmentId: string, tenantId: string): Promise<TaskAssignment | null>;
}

export class TaskAssignmentService {
  constructor(private readonly repository: TaskAssignmentRepository) {}

  async assign(
    tenantId: string,
    taskId: string,
    assigneeType: AssigneeType,
    assigneeId: string,
    dueAt?: string,
  ): Promise<TaskAssignment> {
    const assignment: TaskAssignment = {
      assignmentId: `tassg_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`,
      tenantId,
      taskId,
      assigneeType,
      assigneeId,
      assignedAt: new Date().toISOString(),
      dueAt,
    };
    await this.repository.save(assignment);
    return assignment;
  }
}
