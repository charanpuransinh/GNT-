/**
 * M32 — tasks/task-escalation.service.ts
 * OWN: Escalation when a task assignment is overdue or unresolved.
 */

import { TaskAssignment } from './task-assignment.service';

export interface EscalationRule {
  tenantId: string;
  overdueDays: number;
  escalateToRole: string;
}

export interface EscalationResult {
  assignmentId: string;
  shouldEscalate: boolean;
  escalateToRole?: string;
}

export class TaskEscalationService {
  evaluate(assignment: TaskAssignment, rule: EscalationRule, now: Date = new Date()): EscalationResult {
    if (!assignment.dueAt) {
      return { assignmentId: assignment.assignmentId, shouldEscalate: false };
    }
    const dueDate = new Date(assignment.dueAt);
    const overdueDays = (now.getTime() - dueDate.getTime()) / (24 * 60 * 60 * 1000);

    if (overdueDays >= rule.overdueDays) {
      return { assignmentId: assignment.assignmentId, shouldEscalate: true, escalateToRole: rule.escalateToRole };
    }
    return { assignmentId: assignment.assignmentId, shouldEscalate: false };
  }
}

export const taskEscalationService = new TaskEscalationService();
