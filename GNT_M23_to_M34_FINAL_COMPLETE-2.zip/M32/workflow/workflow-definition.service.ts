/**
 * M32 — workflow/workflow-definition.service.ts
 * OWN: Define versioned workflows.
 * Backs tables: workflow_definition, workflow_version (proposed, tenant-owned).
 */

export interface WorkflowStepDefinition {
  stepId: string;
  actionKey: string; // resolved by workflow-action.service.ts
  conditionExpression?: string; // evaluated by workflow-condition.service.ts
}

export interface WorkflowDefinition {
  workflowId: string;
  tenantId: string;
  name: string;
  version: number;
  steps: WorkflowStepDefinition[];
  active: boolean;
}

export interface WorkflowDefinitionRepository {
  save(definition: WorkflowDefinition): Promise<void>;
  findLatestActive(workflowId: string, tenantId: string): Promise<WorkflowDefinition | null>;
}

export class WorkflowDefinitionService {
  constructor(private readonly repository: WorkflowDefinitionRepository) {}

  /** New versions are additive — never mutate a published version in place. */
  async publishNewVersion(
    tenantId: string,
    workflowId: string,
    name: string,
    steps: WorkflowStepDefinition[],
    previousVersion: number,
  ): Promise<WorkflowDefinition> {
    const definition: WorkflowDefinition = {
      workflowId,
      tenantId,
      name,
      version: previousVersion + 1,
      steps,
      active: true,
    };
    await this.repository.save(definition);
    return definition;
  }

  async getActive(workflowId: string, tenantId: string): Promise<WorkflowDefinition | null> {
    return this.repository.findLatestActive(workflowId, tenantId);
  }
}
