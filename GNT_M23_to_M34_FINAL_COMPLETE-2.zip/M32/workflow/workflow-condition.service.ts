/**
 * M32 — workflow/workflow-condition.service.ts
 * OWN: Evaluate conditions safely.
 * Deliberately NOT a generic eval() — a small, safe comparison DSL only,
 * so a tenant-authored condition can never execute arbitrary code.
 */

export type ComparisonOperator = 'EQ' | 'NEQ' | 'GT' | 'GTE' | 'LT' | 'LTE' | 'CONTAINS';

export interface SimpleCondition {
  field: string;
  operator: ComparisonOperator;
  value: unknown;
}

export class WorkflowConditionService {
  evaluate(condition: SimpleCondition, context: Record<string, unknown>): boolean {
    const actual = context[condition.field];

    switch (condition.operator) {
      case 'EQ':
        return actual === condition.value;
      case 'NEQ':
        return actual !== condition.value;
      case 'GT':
        return typeof actual === 'number' && typeof condition.value === 'number' && actual > condition.value;
      case 'GTE':
        return typeof actual === 'number' && typeof condition.value === 'number' && actual >= condition.value;
      case 'LT':
        return typeof actual === 'number' && typeof condition.value === 'number' && actual < condition.value;
      case 'LTE':
        return typeof actual === 'number' && typeof condition.value === 'number' && actual <= condition.value;
      case 'CONTAINS':
        return Array.isArray(actual) && actual.includes(condition.value);
      default:
        return false;
    }
  }

  evaluateAll(conditions: SimpleCondition[], context: Record<string, unknown>): boolean {
    return conditions.every((c) => this.evaluate(c, context));
  }
}

export const workflowConditionService = new WorkflowConditionService();
