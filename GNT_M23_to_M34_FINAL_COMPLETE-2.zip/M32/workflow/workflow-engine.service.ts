/**
 * M32 — workflow/workflow-engine.service.ts
 * OWN: Execute workflows.
 * Backs table: workflow_execution (proposed, tenant-owned).
 */

import { WorkflowDefinition } from './workflow-definition.service';
import { WorkflowConditionService, workflowConditionService, SimpleCondition } from './workflow-condition.service';
import { WorkflowActionService, workflowActionService, ActionContext } from './workflow-action.service';

export interface WorkflowExecutionResult {
  workflowId: string;
  version: number;
  status: 'COMPLETED' | 'FAILED' | 'PARTIAL';
  stepResults: Array<{ stepId: string; ran: boolean; success?: boolean; error?: string }>;
  startedAt: string;
  finishedAt: string;
}

export class WorkflowEngineService {
  constructor(
    private readonly conditionService: WorkflowConditionService = workflowConditionService,
    private readonly actionService: WorkflowActionService = workflowActionService,
  ) {}

  async execute(
    definition: WorkflowDefinition,
    context: { tenantId: string; actorId: string; correlationId: string; data: Record<string, unknown> },
  ): Promise<WorkflowExecutionResult> {
    const startedAt = new Date().toISOString();
    const stepResults: WorkflowExecutionResult['stepResults'] = [];
    let anyFailed = false;

    for (const step of definition.steps) {
      const shouldRun = step.conditionExpression
        ? this.conditionService.evaluate(JSON.parse(step.conditionExpression) as SimpleCondition, context.data)
        : true;

      if (!shouldRun) {
        stepResults.push({ stepId: step.stepId, ran: false });
        continue;
      }

      const actionContext: ActionContext = {
        tenantId: context.tenantId,
        actorId: context.actorId,
        correlationId: context.correlationId,
        payload: context.data,
      };

      try {
        const result = await this.actionService.run(step.actionKey, actionContext);
        stepResults.push({ stepId: step.stepId, ran: true, success: result.success, error: result.error });
        if (!result.success) anyFailed = true;
      } catch (err) {
        stepResults.push({ stepId: step.stepId, ran: true, success: false, error: err instanceof Error ? err.message : 'UNKNOWN_ERROR' });
        anyFailed = true;
      }
    }

    const ranAny = stepResults.some((r) => r.ran);
    const status: WorkflowExecutionResult['status'] = !anyFailed ? 'COMPLETED' : ranAny ? 'PARTIAL' : 'FAILED';

    return {
      workflowId: definition.workflowId,
      version: definition.version,
      status,
      stepResults,
      startedAt,
      finishedAt: new Date().toISOString(),
    };
  }
}

export const workflowEngineService = new WorkflowEngineService();
