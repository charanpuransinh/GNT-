/**
 * M32 — workflow/workflow-action.service.ts
 * OWN: Execute approved actions.
 * Calling Rule: actions run only through registered, verified handlers —
 * never a dynamic/arbitrary function call.
 */

export interface ActionContext {
  tenantId: string;
  actorId: string;
  correlationId: string;
  payload: Record<string, unknown>;
}

export interface ActionHandler {
  execute(context: ActionContext): Promise<{ success: boolean; result?: unknown; error?: string }>;
}

export class UnknownActionError extends Error {
  constructor(actionKey: string) {
    super(`No handler registered for action "${actionKey}"`);
    this.name = 'UnknownActionError';
  }
}

export class WorkflowActionService {
  private handlers = new Map<string, ActionHandler>();

  registerAction(actionKey: string, handler: ActionHandler): void {
    this.handlers.set(actionKey, handler);
  }

  async run(actionKey: string, context: ActionContext): Promise<{ success: boolean; result?: unknown; error?: string }> {
    const handler = this.handlers.get(actionKey);
    if (!handler) {
      throw new UnknownActionError(actionKey);
    }
    return handler.execute(context);
  }
}

export const workflowActionService = new WorkflowActionService();
