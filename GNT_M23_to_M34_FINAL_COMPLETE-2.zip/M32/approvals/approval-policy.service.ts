/**
 * M32 — approvals/approval-policy.service.ts
 * OWN: Approval rules.
 */

export interface ApprovalPolicy {
  policyId: string;
  tenantId: string;
  actionKey: string;
  requiredApproverRole: string;
  minApprovals: number;
}

export interface ApprovalPolicyRepository {
  find(tenantId: string, actionKey: string): Promise<ApprovalPolicy | null>;
}

export class ApprovalPolicyService {
  constructor(private readonly repository: ApprovalPolicyRepository) {}

  async getPolicy(tenantId: string, actionKey: string): Promise<ApprovalPolicy | null> {
    return this.repository.find(tenantId, actionKey);
  }
}
