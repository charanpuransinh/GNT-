/**
 * M32 — approvals/approval-delegation.service.ts
 * OWN: Controlled delegation of approval authority.
 */

export interface DelegationRule {
  delegationId: string;
  tenantId: string;
  fromUserId: string;
  toUserId: string;
  actionKey: string;
  validFrom: string;
  validTo: string;
}

export interface DelegationRepository {
  findActiveDelegation(tenantId: string, fromUserId: string, actionKey: string, atDate: string): Promise<DelegationRule | null>;
}

export class ApprovalDelegationService {
  constructor(private readonly repository: DelegationRepository) {}

  /** Resolve the effective approver — either the original user or their active delegate. */
  async resolveEffectiveApprover(
    tenantId: string,
    originalUserId: string,
    actionKey: string,
    atDate: string = new Date().toISOString(),
  ): Promise<string> {
    const delegation = await this.repository.findActiveDelegation(tenantId, originalUserId, actionKey, atDate);
    return delegation ? delegation.toUserId : originalUserId;
  }
}
