/**
 * M32 — approvals/approval-engine.service.ts
 * OWN: Approval lifecycle.
 * Backs tables: approval_request, approval_action (proposed, tenant-owned).
 */

import { ApprovalPolicyService } from './approval-policy.service';
import { ApprovalDelegationService } from './approval-delegation.service';

export interface ApprovalRequest {
  requestId: string;
  tenantId: string;
  actionKey: string;
  requestedBy: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  approvalsReceived: string[]; // approver user ids
  createdAt: string;
}

export interface ApprovalRequestRepository {
  save(request: ApprovalRequest): Promise<void>;
  find(requestId: string, tenantId: string): Promise<ApprovalRequest | null>;
}

export class ApprovalEngineService {
  constructor(
    private readonly repository: ApprovalRequestRepository,
    private readonly policyService: ApprovalPolicyService,
    private readonly delegationService: ApprovalDelegationService,
  ) {}

  async createRequest(tenantId: string, actionKey: string, requestedBy: string): Promise<ApprovalRequest> {
    const request: ApprovalRequest = {
      requestId: `apr_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`,
      tenantId,
      actionKey,
      requestedBy,
      status: 'PENDING',
      approvalsReceived: [],
      createdAt: new Date().toISOString(),
    };
    await this.repository.save(request);
    return request;
  }

  /** No self-authorization: an actor can never approve their own request. */
  async recordApproval(requestId: string, tenantId: string, approverUserId: string): Promise<ApprovalRequest> {
    const request = await this.repository.find(requestId, tenantId);
    if (!request) throw new Error('Approval request not found');
    if (request.requestedBy === approverUserId) {
      throw new Error('An actor cannot approve their own request');
    }

    const policy = await this.policyService.getPolicy(tenantId, request.actionKey);
    const effectiveApprover = await this.delegationService.resolveEffectiveApprover(tenantId, approverUserId, request.actionKey);

    if (!request.approvalsReceived.includes(effectiveApprover)) {
      request.approvalsReceived.push(effectiveApprover);
    }

    const minApprovals = policy?.minApprovals ?? 1;
    if (request.approvalsReceived.length >= minApprovals) {
      request.status = 'APPROVED';
    }

    await this.repository.save(request);
    return request;
  }

  async reject(requestId: string, tenantId: string): Promise<ApprovalRequest> {
    const request = await this.repository.find(requestId, tenantId);
    if (!request) throw new Error('Approval request not found');
    request.status = 'REJECTED';
    await this.repository.save(request);
    return request;
  }
}
