/**
 * M32 — agents/agent-memory.service.ts
 * OWN: Controlled task memory.
 * Backs table: agent_memory (proposed, tenant-owned).
 * AI Safety Contract: NO SECRET ACCESS — memory entries must never store
 * credentials/tokens (enforced with the same blocked-key check as M23 audit).
 */

const BLOCKED_KEYS = ['password', 'token', 'secret', 'accessToken', 'refreshToken', 'cardNumber'];

export interface AgentMemoryEntry {
  agentId: string;
  tenantId: string;
  taskId: string;
  key: string;
  value: unknown;
  createdAt: string;
}

export interface AgentMemoryStore {
  save(entry: AgentMemoryEntry): Promise<void>;
  get(agentId: string, tenantId: string, taskId: string, key: string): Promise<AgentMemoryEntry | null>;
}

export class AgentMemoryService {
  constructor(private readonly store: AgentMemoryStore) {}

  async remember(agentId: string, tenantId: string, taskId: string, key: string, value: unknown): Promise<void> {
    if (BLOCKED_KEYS.some((b) => key.toLowerCase().includes(b))) {
      throw new Error(`Agent memory cannot store key "${key}" — potentially sensitive`);
    }
    await this.store.save({ agentId, tenantId, taskId, key, value, createdAt: new Date().toISOString() });
  }

  async recall(agentId: string, tenantId: string, taskId: string, key: string): Promise<unknown | null> {
    const entry = await this.store.get(agentId, tenantId, taskId, key);
    return entry?.value ?? null;
  }
}
