/**
 * M32 — agents/agent-orchestrator.service.ts
 * OWN: Coordinate AI agents.
 * AGENT RULE: never self-escalate, never impersonate owner, never bypass approval.
 */

import { AgentIdentity, AgentSafetyGuardService, agentSafetyGuardService } from './agent-safety-guard.service';
import { AgentTaskService, AgentTask } from './agent-task.service';
import { ApprovalEngineService } from '../approvals/approval-engine.service';
import { WorkflowActionService, workflowActionService, ActionContext } from '../workflow/workflow-action.service';

export interface AgentDispatchRequest {
  agent: AgentIdentity;
  actionKey: string;
  requiredPermission: string;
  actionRequiresApproval: boolean;
  correlationId: string;
  payload: Record<string, unknown>;
}

export class AgentOrchestratorService {
  constructor(
    private readonly taskService: AgentTaskService,
    private readonly approvalEngine: ApprovalEngineService,
    private readonly safetyGuard: AgentSafetyGuardService = agentSafetyGuardService,
    private readonly actionService: WorkflowActionService = workflowActionService,
  ) {}

  async dispatch(request: AgentDispatchRequest): Promise<AgentTask> {
    this.safetyGuard.assertPermission(request.agent, request.requiredPermission);

    let task = await this.taskService.create(request.agent.tenantId, request.agent.agentId, request.actionKey);

    if (request.actionRequiresApproval) {
      const approvalRequest = await this.approvalEngine.createRequest(
        request.agent.tenantId,
        request.actionKey,
        request.agent.agentId,
      );
      task = await this.taskService.updateStatus(task.taskId, request.agent.tenantId, 'BLOCKED_PENDING_APPROVAL');
      // Agent stops here — execution resumes only after a human records approval
      // via ApprovalEngineService.recordApproval, never by the agent itself.
      void approvalRequest;
      return task;
    }

    return this.runAction(task, request);
  }

  /** Called after a human-recorded approval unblocks a previously-blocked task. */
  async resumeAfterApproval(task: AgentTask, request: AgentDispatchRequest): Promise<AgentTask> {
    this.safetyGuard.assertApprovalRequired(true, true);
    return this.runAction(task, request);
  }

  private async runAction(task: AgentTask, request: AgentDispatchRequest): Promise<AgentTask> {
    task = await this.taskService.updateStatus(task.taskId, request.agent.tenantId, 'RUNNING');

    const actionContext: ActionContext = {
      tenantId: request.agent.tenantId,
      actorId: request.agent.agentId,
      correlationId: request.correlationId,
      payload: request.payload,
    };

    try {
      const result = await this.actionService.run(request.actionKey, actionContext);
      return this.taskService.updateStatus(task.taskId, request.agent.tenantId, result.success ? 'COMPLETED' : 'FAILED');
    } catch {
      return this.taskService.updateStatus(task.taskId, request.agent.tenantId, 'FAILED');
    }
  }
}
