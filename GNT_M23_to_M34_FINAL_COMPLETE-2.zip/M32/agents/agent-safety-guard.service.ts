/**
 * M32 — agents/agent-safety-guard.service.ts
 * OWN: Prevent unauthorized agent actions.
 * AGENT RULE (per blueprint): an agent may never escalate its own
 * permission, may never impersonate an owner, may not bypass approval rules.
 */

export interface AgentIdentity {
  agentId: string;
  tenantId: string;
  grantedPermissions: string[];
  isAgent: true;
}

export class AgentSafetyViolationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'AgentSafetyViolationError';
  }
}

const OWNER_ROLE_MARKERS = ['OWNER', 'MD', 'ADMIN'];

export class AgentSafetyGuardService {
  /** An agent's requested permission must already be in its granted set — never dynamically escalated. */
  assertPermission(agent: AgentIdentity, requiredPermission: string): void {
    if (!agent.grantedPermissions.includes(requiredPermission)) {
      throw new AgentSafetyViolationError(`Agent ${agent.agentId} attempted to use ungranted permission ${requiredPermission}`);
    }
  }

  /** An agent can never claim to act as an owner/admin identity. */
  assertNotImpersonatingOwner(claimedRole: string): void {
    if (OWNER_ROLE_MARKERS.some((marker) => claimedRole.toUpperCase().includes(marker))) {
      throw new AgentSafetyViolationError('Agent cannot impersonate an owner/admin role');
    }
  }

  /** Business-critical actions must always route through M32 approval-engine — never bypassed. */
  assertApprovalRequired(actionRequiresApproval: boolean, approvalObtained: boolean): void {
    if (actionRequiresApproval && !approvalObtained) {
      throw new AgentSafetyViolationError('Agent cannot execute an action that requires approval without a recorded approval');
    }
  }
}

export const agentSafetyGuardService = new AgentSafetyGuardService();
