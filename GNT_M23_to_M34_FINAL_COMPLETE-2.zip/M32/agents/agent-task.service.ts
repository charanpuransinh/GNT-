/**
 * M32 — agents/agent-task.service.ts
 * OWN: Create/track agent tasks.
 * Backs table: agent_task (proposed, tenant-owned).
 */

export type AgentTaskStatus = 'PENDING' | 'RUNNING' | 'BLOCKED_PENDING_APPROVAL' | 'COMPLETED' | 'FAILED';

export interface AgentTask {
  taskId: string;
  tenantId: string;
  agentId: string;
  actionKey: string;
  status: AgentTaskStatus;
  createdAt: string;
  updatedAt: string;
}

export interface AgentTaskStore {
  save(task: AgentTask): Promise<void>;
  find(taskId: string, tenantId: string): Promise<AgentTask | null>;
}

export class AgentTaskService {
  constructor(private readonly store: AgentTaskStore) {}

  async create(tenantId: string, agentId: string, actionKey: string): Promise<AgentTask> {
    const now = new Date().toISOString();
    const task: AgentTask = {
      taskId: `atask_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`,
      tenantId,
      agentId,
      actionKey,
      status: 'PENDING',
      createdAt: now,
      updatedAt: now,
    };
    await this.store.save(task);
    return task;
  }

  async updateStatus(taskId: string, tenantId: string, status: AgentTaskStatus): Promise<AgentTask> {
    const task = await this.store.find(taskId, tenantId);
    if (!task) throw new Error('Agent task not found');
    task.status = status;
    task.updatedAt = new Date().toISOString();
    await this.store.save(task);
    return task;
  }
}
