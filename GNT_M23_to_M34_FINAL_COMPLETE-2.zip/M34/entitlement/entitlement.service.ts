/**
 * M34 — entitlement/entitlement.service.ts
 * OWN: Determine allowed capability.
 * Backs table: subscription_entitlement (proposed, tenant-owned).
 */

import { PlanFeatureService } from '../plans/plan-feature.service';

export interface ActiveSubscription {
  tenantId: string;
  planId: string;
  status: 'ACTIVE' | 'SUSPENDED' | 'EXPIRED' | 'TRIAL';
}

export interface EntitlementResult {
  tenantId: string;
  featureKey: string;
  entitled: boolean;
  limit?: number;
  reason: string;
}

export class EntitlementService {
  constructor(private readonly planFeatureService: PlanFeatureService) {}

  async checkEntitlement(subscription: ActiveSubscription, featureKey: string): Promise<EntitlementResult> {
    if (subscription.status === 'SUSPENDED' || subscription.status === 'EXPIRED') {
      return { tenantId: subscription.tenantId, featureKey, entitled: false, reason: `SUBSCRIPTION_${subscription.status}` };
    }

    const features = await this.planFeatureService.getFeatures(subscription.planId);
    const feature = features.find((f) => f.featureKey === featureKey);

    if (!feature) {
      return { tenantId: subscription.tenantId, featureKey, entitled: false, reason: 'FEATURE_NOT_IN_PLAN' };
    }

    return { tenantId: subscription.tenantId, featureKey, entitled: true, limit: feature.limit, reason: 'OK' };
  }
}
