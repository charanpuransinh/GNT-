/**
 * M34 — entitlement/entitlement-guard.ts
 * OWN: Enforce capability access at the API boundary.
 * Calling pattern (per blueprint Section 19 example):
 *   M23 authorization -> M34 entitlement -> allow/deny -> M25 notification
 *   if quota warning -> M08/M09 only when financial transaction required.
 */

import { EntitlementService, ActiveSubscription } from './entitlement.service';
import { QuotaService, quotaService, QuotaCheckResult } from './quota.service';

export class EntitlementDeniedError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'EntitlementDeniedError';
  }
}

export interface EntitlementGuardResult {
  allowed: boolean;
  quota: QuotaCheckResult | null;
}

export class EntitlementGuard {
  constructor(
    private readonly entitlementService: EntitlementService,
    private readonly quotaSvc: QuotaService = quotaService,
  ) {}

  /**
   * Enforce both plan entitlement AND quota. Callers are responsible for
   * emitting an M25 QUOTA.WARNING notification when quota.atWarningLevel
   * is true — this guard only computes the decision, never dispatches
   * notifications itself (single-responsibility, Calling Rule).
   */
  async enforce(
    subscription: ActiveSubscription,
    featureKey: string,
    currentUsage: number,
  ): Promise<EntitlementGuardResult> {
    const entitlement = await this.entitlementService.checkEntitlement(subscription, featureKey);
    if (!entitlement.entitled) {
      throw new EntitlementDeniedError(entitlement.reason);
    }

    const quota = this.quotaSvc.check({
      tenantId: subscription.tenantId,
      featureKey,
      limit: entitlement.limit,
      currentUsage,
    });

    if (!quota.allowed) {
      throw new EntitlementDeniedError('QUOTA_EXCEEDED');
    }

    return { allowed: true, quota };
  }
}
