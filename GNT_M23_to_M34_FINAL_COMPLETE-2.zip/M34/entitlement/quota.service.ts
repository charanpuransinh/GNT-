/**
 * M34 — entitlement/quota.service.ts
 * OWN: Enforce configured limits.
 */

export interface QuotaCheckInput {
  tenantId: string;
  featureKey: string;
  limit: number | undefined; // undefined = unlimited
  currentUsage: number;
}

export interface QuotaCheckResult {
  allowed: boolean;
  remaining: number | null; // null = unlimited
  atWarningLevel: boolean; // >= 90% of limit
}

const WARNING_THRESHOLD_PCT = 90;

export class QuotaService {
  check(input: QuotaCheckInput): QuotaCheckResult {
    if (input.limit === undefined) {
      return { allowed: true, remaining: null, atWarningLevel: false };
    }

    const remaining = input.limit - input.currentUsage;
    const usagePct = input.limit > 0 ? (input.currentUsage / input.limit) * 100 : 100;

    return {
      allowed: remaining > 0,
      remaining: Math.max(0, remaining),
      atWarningLevel: usagePct >= WARNING_THRESHOLD_PCT,
    };
  }
}

export const quotaService = new QuotaService();
