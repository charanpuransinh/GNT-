/**
 * M34 — usage/usage-aggregation.service.ts
 * OWN: Aggregate consumption.
 * Backs table: usage_meter (proposed, tenant-owned — rolled-up view).
 */

export interface UsageAggregate {
  tenantId: string;
  featureKey: string;
  periodStart: string;
  periodEnd: string;
  totalAmount: number;
}

export interface UsageAggregationSource {
  sumUsage(tenantId: string, featureKey: string, periodStart: string, periodEnd: string): Promise<number>;
}

export class UsageAggregationService {
  constructor(private readonly source: UsageAggregationSource) {}

  async aggregate(tenantId: string, featureKey: string, periodStart: string, periodEnd: string): Promise<UsageAggregate> {
    const totalAmount = await this.source.sumUsage(tenantId, featureKey, periodStart, periodEnd);
    return { tenantId, featureKey, periodStart, periodEnd, totalAmount };
  }
}
