/**
 * M34 — usage/usage-meter.service.ts
 * OWN: Record usage.
 * Backs table: usage_record (proposed, tenant-owned). Rule 11: idempotent.
 */

export interface UsageRecordInput {
  tenantId: string;
  featureKey: string;
  amount: number;
  idempotencyKey: string;
  occurredAt?: string;
}

export interface UsageRecord {
  recordId: string;
  tenantId: string;
  featureKey: string;
  amount: number;
  idempotencyKey: string;
  occurredAt: string;
}

export interface UsageRecordStore {
  findByIdempotencyKey(tenantId: string, idempotencyKey: string): Promise<UsageRecord | null>;
  insert(record: UsageRecord): Promise<void>;
}

export class UsageMeterService {
  constructor(private readonly store: UsageRecordStore) {}

  async record(input: UsageRecordInput): Promise<UsageRecord> {
    const existing = await this.store.findByIdempotencyKey(input.tenantId, input.idempotencyKey);
    if (existing) return existing;

    const record: UsageRecord = {
      recordId: `usage_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`,
      tenantId: input.tenantId,
      featureKey: input.featureKey,
      amount: input.amount,
      idempotencyKey: input.idempotencyKey,
      occurredAt: input.occurredAt ?? new Date().toISOString(),
    };
    await this.store.insert(record);
    return record;
  }
}
