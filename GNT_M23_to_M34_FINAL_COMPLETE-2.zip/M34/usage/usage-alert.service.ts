/**
 * M34 — usage/usage-alert.service.ts
 * OWN: Generate quota alerts.
 * Backs table: usage_alert (proposed, tenant-owned).
 * M34 -> M25 (notification) per the Master Module Dependency Map.
 */

import { QuotaCheckResult } from '../entitlement/quota.service';

export interface UsageAlert {
  alertId: string;
  tenantId: string;
  featureKey: string;
  level: 'WARNING' | 'EXCEEDED';
  remaining: number | null;
  createdAt: string;
}

export interface UsageAlertEmitter {
  /** Must route through M25's public NotificationsService/EventEmitter — never a direct email/SMS call from here. */
  emitAlert(alert: UsageAlert): Promise<void>;
}

export class UsageAlertService {
  constructor(private readonly emitter: UsageAlertEmitter) {}

  async evaluateAndAlert(tenantId: string, featureKey: string, quota: QuotaCheckResult): Promise<UsageAlert | null> {
    if (!quota.atWarningLevel && quota.allowed) return null;

    const alert: UsageAlert = {
      alertId: `ualert_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`,
      tenantId,
      featureKey,
      level: quota.allowed ? 'WARNING' : 'EXCEEDED',
      remaining: quota.remaining,
      createdAt: new Date().toISOString(),
    };
    await this.emitter.emitAlert(alert);
    return alert;
  }
}
