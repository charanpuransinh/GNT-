/**
 * M34 — Subscription, Entitlement & Usage Intelligence
 * index.ts — Public M34 exports.
 * IMPORTANT (per blueprint): M34 must not create financial invoices or GST
 * documents itself — verified: no file here posts to a ledger; pricing
 * services only compute figures. M34 calls M08/M09 public financial
 * contracts when billing is required (not yet wired — verification needed).
 */

export { PlanService, type SubscriptionPlan, type PlanRepository } from './plans/plan.service';
export { PlanFeatureService, type PlanFeature, type PlanFeatureRepository } from './plans/plan-feature.service';
export { PricingRuleService, pricingRuleService, type PricingRule, type BillingCycle, type PriceCalculationInput, type PriceCalculationResult } from './plans/pricing-rule.service';

export { EntitlementService, type ActiveSubscription, type EntitlementResult } from './entitlement/entitlement.service';
export { EntitlementGuard, EntitlementDeniedError, type EntitlementGuardResult } from './entitlement/entitlement-guard';
export { QuotaService, quotaService, type QuotaCheckInput, type QuotaCheckResult } from './entitlement/quota.service';

export { UsageMeterService, type UsageRecord, type UsageRecordInput, type UsageRecordStore } from './usage/usage-meter.service';
export { UsageAggregationService, type UsageAggregate, type UsageAggregationSource } from './usage/usage-aggregation.service';
export { UsageAlertService, type UsageAlert, type UsageAlertEmitter } from './usage/usage-alert.service';

export { SubscriptionLifecycleService, type SubscriptionRecord, type SubscriptionRepository } from './lifecycle/subscription-lifecycle.service';
export { TrialService, type TrialInfo, type TrialRepository } from './lifecycle/trial.service';
export { UpgradeDowngradeService, type PlanTransitionRequest, type PlanTransitionResult } from './lifecycle/upgrade-downgrade.service';
