/**
 * M34 — lifecycle/subscription-lifecycle.service.ts
 * OWN: Activate/suspend/expire subscriptions.
 * Backs table: subscription (proposed, tenant-owned).
 */

import { ActiveSubscription } from '../entitlement/entitlement.service';

export interface SubscriptionRecord extends ActiveSubscription {
  subscriptionId: string;
  activatedAt: string;
  updatedAt: string;
}

export interface SubscriptionRepository {
  save(subscription: SubscriptionRecord): Promise<void>;
  find(tenantId: string): Promise<SubscriptionRecord | null>;
}

export class SubscriptionLifecycleService {
  constructor(private readonly repository: SubscriptionRepository) {}

  async activate(tenantId: string, planId: string): Promise<SubscriptionRecord> {
    const now = new Date().toISOString();
    const record: SubscriptionRecord = {
      subscriptionId: `sub_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`,
      tenantId,
      planId,
      status: 'ACTIVE',
      activatedAt: now,
      updatedAt: now,
    };
    await this.repository.save(record);
    return record;
  }

  async suspend(tenantId: string): Promise<SubscriptionRecord | null> {
    const record = await this.repository.find(tenantId);
    if (!record) return null;
    record.status = 'SUSPENDED';
    record.updatedAt = new Date().toISOString();
    await this.repository.save(record);
    return record;
  }

  async expire(tenantId: string): Promise<SubscriptionRecord | null> {
    const record = await this.repository.find(tenantId);
    if (!record) return null;
    record.status = 'EXPIRED';
    record.updatedAt = new Date().toISOString();
    await this.repository.save(record);
    return record;
  }

  async getActive(tenantId: string): Promise<SubscriptionRecord | null> {
    const record = await this.repository.find(tenantId);
    return record && record.status === 'ACTIVE' ? record : null;
  }
}
