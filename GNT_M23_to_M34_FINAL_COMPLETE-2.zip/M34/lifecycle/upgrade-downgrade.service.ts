/**
 * M34 — lifecycle/upgrade-downgrade.service.ts
 * OWN: Plan transitions.
 * IMPORTANT: does not itself create financial documents — proration/billing
 * is calculated here as figures only; actual invoicing goes through M08/M09.
 */

import { PricingRuleService, pricingRuleService, PricingRule } from '../plans/pricing-rule.service';

export interface PlanTransitionRequest {
  tenantId: string;
  fromPlanId: string;
  toPlanId: string;
  toPricingRule: PricingRule;
  daysRemainingInCycle: number;
  cycleDays: number;
  userCount: number;
}

export interface PlanTransitionResult {
  tenantId: string;
  fromPlanId: string;
  toPlanId: string;
  direction: 'UPGRADE' | 'DOWNGRADE' | 'LATERAL';
  proratedAmountDue: number;
}

export class UpgradeDowngradeService {
  constructor(private readonly pricingService: PricingRuleService = pricingRuleService) {}

  calculateTransition(request: PlanTransitionRequest, direction: PlanTransitionResult['direction']): PlanTransitionResult {
    const fullPrice = this.pricingService.calculate({ rule: request.toPricingRule, userCount: request.userCount });
    const prorationFactor = request.cycleDays > 0 ? request.daysRemainingInCycle / request.cycleDays : 0;
    const proratedAmountDue = fullPrice.netAmount * prorationFactor;

    return {
      tenantId: request.tenantId,
      fromPlanId: request.fromPlanId,
      toPlanId: request.toPlanId,
      direction,
      proratedAmountDue,
    };
  }
}
