/**
 * M34 — lifecycle/trial.service.ts
 * OWN: Trial lifecycle.
 */

export interface TrialInfo {
  tenantId: string;
  planId: string;
  trialStartedAt: string;
  trialEndsAt: string;
}

export interface TrialRepository {
  save(trial: TrialInfo): Promise<void>;
  find(tenantId: string): Promise<TrialInfo | null>;
}

export class TrialService {
  constructor(private readonly repository: TrialRepository) {}

  async startTrial(tenantId: string, planId: string, durationDays: number): Promise<TrialInfo> {
    const startedAt = new Date();
    const endsAt = new Date(startedAt.getTime() + durationDays * 24 * 60 * 60 * 1000);
    const trial: TrialInfo = {
      tenantId,
      planId,
      trialStartedAt: startedAt.toISOString(),
      trialEndsAt: endsAt.toISOString(),
    };
    await this.repository.save(trial);
    return trial;
  }

  async isTrialActive(tenantId: string, now: Date = new Date()): Promise<boolean> {
    const trial = await this.repository.find(tenantId);
    if (!trial) return false;
    return now.getTime() < new Date(trial.trialEndsAt).getTime();
  }
}
