/**
 * M34 — plans/plan.service.ts
 * OWN: Create/manage plans.
 * Backs table: subscription_plan (proposed, tenant-owned — plans themselves
 * may be platform-level rather than tenant-owned; kept tenant-scoped here
 * for custom/negotiated plans, verify against real requirement at wiring).
 */

export interface SubscriptionPlan {
  planId: string;
  name: string;
  tenantId: string | null; // null = platform-wide standard plan
  active: boolean;
  createdAt: string;
}

export interface PlanRepository {
  save(plan: SubscriptionPlan): Promise<void>;
  find(planId: string): Promise<SubscriptionPlan | null>;
  listActive(): Promise<SubscriptionPlan[]>;
}

export class PlanService {
  constructor(private readonly repository: PlanRepository) {}

  async create(name: string, tenantId: string | null = null): Promise<SubscriptionPlan> {
    const plan: SubscriptionPlan = {
      planId: `plan_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`,
      name,
      tenantId,
      active: true,
      createdAt: new Date().toISOString(),
    };
    await this.repository.save(plan);
    return plan;
  }

  async deactivate(planId: string): Promise<void> {
    const plan = await this.repository.find(planId);
    if (!plan) return;
    plan.active = false;
    await this.repository.save(plan);
  }

  async listActive(): Promise<SubscriptionPlan[]> {
    return this.repository.listActive();
  }
}
