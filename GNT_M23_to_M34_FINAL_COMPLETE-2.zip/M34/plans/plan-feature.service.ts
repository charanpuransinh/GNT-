/**
 * M34 — plans/plan-feature.service.ts
 * OWN: Map features to plans.
 * Backs table: plan_feature (proposed).
 */

export interface PlanFeature {
  planId: string;
  featureKey: string;
  limit?: number; // undefined = unlimited
}

export interface PlanFeatureRepository {
  save(feature: PlanFeature): Promise<void>;
  listForPlan(planId: string): Promise<PlanFeature[]>;
}

export class PlanFeatureService {
  constructor(private readonly repository: PlanFeatureRepository) {}

  async addFeature(planId: string, featureKey: string, limit?: number): Promise<PlanFeature> {
    const feature: PlanFeature = { planId, featureKey, limit };
    await this.repository.save(feature);
    return feature;
  }

  async getFeatures(planId: string): Promise<PlanFeature[]> {
    return this.repository.listForPlan(planId);
  }

  async hasFeature(planId: string, featureKey: string): Promise<boolean> {
    const features = await this.repository.listForPlan(planId);
    return features.some((f) => f.featureKey === featureKey);
  }
}
