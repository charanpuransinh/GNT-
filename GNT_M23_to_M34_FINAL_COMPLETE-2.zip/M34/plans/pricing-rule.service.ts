/**
 * M34 — plans/pricing-rule.service.ts
 * OWN: Calculate configurable plan pricing.
 * Rule 22: tenant-level configuration, not a hardcoded universal policy.
 * IMPORTANT (blueprint): M34 must not create financial invoices/GST itself
 * — this only calculates a price figure; M08/M09 handle actual billing.
 */

export type BillingCycle = 'MONTHLY' | 'YEARLY';

export interface PricingRule {
  planId: string;
  billingCycle: BillingCycle;
  basePrice: number;
  currency: string;
  perUserPrice?: number;
  discountPct?: number;
}

export interface PriceCalculationInput {
  rule: PricingRule;
  userCount: number;
}

export interface PriceCalculationResult {
  planId: string;
  billingCycle: BillingCycle;
  currency: string;
  grossAmount: number;
  discountAmount: number;
  netAmount: number;
}

export class PricingRuleService {
  calculate(input: PriceCalculationInput): PriceCalculationResult {
    const { rule, userCount } = input;
    const variableAmount = (rule.perUserPrice ?? 0) * Math.max(0, userCount);
    const grossAmount = rule.basePrice + variableAmount;
    const discountAmount = rule.discountPct ? grossAmount * (rule.discountPct / 100) : 0;

    return {
      planId: rule.planId,
      billingCycle: rule.billingCycle,
      currency: rule.currency,
      grossAmount,
      discountAmount,
      netAmount: grossAmount - discountAmount,
    };
  }
}

export const pricingRuleService = new PricingRuleService();
