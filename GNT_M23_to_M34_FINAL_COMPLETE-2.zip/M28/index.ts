/**
 * M28 — Reporting, Export & Communication
 * index.ts — Public M28 exports.
 */

export { ReportTemplateService, type ReportTemplate, type ReportTemplateRepository } from './reports/report-template.service';
export { ReportBuilder, type BuiltReport, type ReportDataProvider } from './reports/report-builder';
export { ReportExportService, reportExportService, type ExportFormat, type ExportRenderer, type ExportedFile } from './reports/report-export.service';

export { ExportScheduler, type ReportScheduleRequest, type SchedulerPort } from './scheduler/export-scheduler';

export { EmailDispatcher, type EmailMessage, type EmailProvider } from './communication/email-dispatcher';
export { EmailSmsService, type SmsMessage, type SmsProvider } from './communication/email-sms.service';
export { CommunicationLogService, type CommunicationLogEntry, type CommunicationLogStore, type CommunicationChannel, type CommunicationStatus } from './communication/communication-log.service';
