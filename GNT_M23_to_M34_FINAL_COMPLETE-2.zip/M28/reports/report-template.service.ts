/**
 * M28 — reports/report-template.service.ts
 * OWN: Manage reusable report templates.
 * Backs table: report_template (proposed, tenant-owned).
 */

export interface ReportTemplate {
  templateId: string;
  tenantId: string;
  name: string;
  sourceMetricKeys: string[];
  columns: string[];
  createdBy: string;
}

export interface ReportTemplateRepository {
  save(template: ReportTemplate): Promise<void>;
  find(templateId: string, tenantId: string): Promise<ReportTemplate | null>;
  listForTenant(tenantId: string): Promise<ReportTemplate[]>;
}

export class ReportTemplateService {
  constructor(private readonly repository: ReportTemplateRepository) {}

  async create(template: Omit<ReportTemplate, 'templateId'>): Promise<ReportTemplate> {
    const full: ReportTemplate = { ...template, templateId: `tpl_${Date.now()}_${Math.random().toString(36).slice(2, 10)}` };
    await this.repository.save(full);
    return full;
  }

  async get(templateId: string, tenantId: string): Promise<ReportTemplate | null> {
    return this.repository.find(templateId, tenantId);
  }

  async listForTenant(tenantId: string): Promise<ReportTemplate[]> {
    return this.repository.listForTenant(tenantId);
  }
}
