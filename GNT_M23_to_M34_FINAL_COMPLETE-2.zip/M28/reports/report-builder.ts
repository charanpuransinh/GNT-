/**
 * M28 — reports/report-builder.ts
 * OWN: Build reports from approved data sources.
 *
 * VERIFICATION NEEDED: real M27 analytics contract at wiring time (imported
 * by type only here to avoid a hard runtime dependency before M27 is
 * confirmed wired in the target repo).
 */

import { ReportTemplate } from './report-template.service';

export interface ReportDataProvider {
  fetchRows(tenantId: string, sourceMetricKeys: string[], fromDate: string, toDate: string): Promise<Record<string, unknown>[]>;
}

export interface BuiltReport {
  templateId: string;
  tenantId: string;
  columns: string[];
  rows: Record<string, unknown>[];
  generatedAt: string;
}

export class ReportBuilder {
  constructor(private readonly dataProvider: ReportDataProvider) {}

  async build(template: ReportTemplate, fromDate: string, toDate: string): Promise<BuiltReport> {
    const rows = await this.dataProvider.fetchRows(template.tenantId, template.sourceMetricKeys, fromDate, toDate);
    return {
      templateId: template.templateId,
      tenantId: template.tenantId,
      columns: template.columns,
      rows,
      generatedAt: new Date().toISOString(),
    };
  }
}
