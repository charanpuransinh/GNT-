/**
 * M28 — communication/email-sms.service.ts
 * OWN: Channel abstraction for email/SMS.
 *
 * VERIFICATION NEEDED: real SMS provider — depends on an injected
 * SmsProvider adapter, same pattern as EmailDispatcher.
 */

import { EmailDispatcher, EmailMessage } from './email-dispatcher';
import { CommunicationLogService } from './communication-log.service';

export interface SmsMessage {
  to: string;
  body: string;
}

export interface SmsProvider {
  send(message: SmsMessage): Promise<{ delivered: boolean; providerMessageId?: string; error?: string }>;
}

class UnconfiguredSmsProvider implements SmsProvider {
  async send(): Promise<{ delivered: boolean; error?: string }> {
    return { delivered: false, error: 'SMS_PROVIDER_NOT_CONFIGURED' };
  }
}

export class EmailSmsService {
  constructor(
    private readonly tenantId: string,
    private readonly emailDispatcher: EmailDispatcher,
    private readonly smsProvider: SmsProvider = new UnconfiguredSmsProvider(),
    private readonly log?: CommunicationLogService,
  ) {}

  async sendEmail(message: EmailMessage): Promise<{ delivered: boolean }> {
    const result = await this.emailDispatcher.dispatch(message);
    await this.log?.log({
      tenantId: this.tenantId,
      channel: 'EMAIL',
      recipient: message.to,
      subject: message.subject,
      status: result.delivered ? 'SENT' : 'FAILED',
      errorMessage: result.error,
    });
    return { delivered: result.delivered };
  }

  async sendSms(message: SmsMessage): Promise<{ delivered: boolean }> {
    const result = await this.smsProvider.send(message);
    await this.log?.log({
      tenantId: this.tenantId,
      channel: 'SMS',
      recipient: message.to,
      status: result.delivered ? 'SENT' : 'FAILED',
      errorMessage: result.error,
    });
    return { delivered: result.delivered };
  }
}
