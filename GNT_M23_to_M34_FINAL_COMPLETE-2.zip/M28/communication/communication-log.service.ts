/**
 * M28 — communication/communication-log.service.ts
 * OWN: Delivery/audit history for outbound communications.
 * Backs table: communication_log (proposed, tenant-owned).
 */

export type CommunicationChannel = 'EMAIL' | 'SMS';
export type CommunicationStatus = 'SENT' | 'FAILED';

export interface CommunicationLogEntry {
  id: string;
  tenantId: string;
  channel: CommunicationChannel;
  recipient: string;
  subject?: string;
  status: CommunicationStatus;
  errorMessage?: string;
  sentAt: string;
}

export interface CommunicationLogStore {
  insert(entry: CommunicationLogEntry): Promise<void>;
  listForTenant(tenantId: string, limit?: number): Promise<CommunicationLogEntry[]>;
}

export class CommunicationLogService {
  constructor(private readonly store: CommunicationLogStore) {}

  async log(entry: Omit<CommunicationLogEntry, 'id' | 'sentAt'>): Promise<CommunicationLogEntry> {
    const full: CommunicationLogEntry = {
      ...entry,
      id: `comm_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`,
      sentAt: new Date().toISOString(),
    };
    await this.store.insert(full);
    return full;
  }

  async recent(tenantId: string, limit = 50): Promise<CommunicationLogEntry[]> {
    return this.store.listForTenant(tenantId, limit);
  }
}
