/**
 * M28 — communication/email-dispatcher.ts
 * OWN: Send email.
 *
 * VERIFICATION NEEDED: real email provider (SMTP/SES/SendGrid etc.) and
 * secret storage (Rule 26). Depends on an injected EmailProvider adapter.
 */

export interface EmailMessage {
  to: string;
  subject: string;
  body: string;
  isHtml?: boolean;
}

export interface EmailProvider {
  send(message: EmailMessage): Promise<{ delivered: boolean; providerMessageId?: string; error?: string }>;
}

export class EmailDispatcher {
  constructor(private readonly provider: EmailProvider) {}

  async dispatch(message: EmailMessage): Promise<{ delivered: boolean; providerMessageId?: string; error?: string }> {
    if (!message.to || !message.subject) {
      return { delivered: false, error: 'INVALID_EMAIL_MESSAGE' };
    }
    try {
      return await this.provider.send(message);
    } catch (err) {
      return { delivered: false, error: err instanceof Error ? err.message : 'UNKNOWN_ERROR' };
    }
  }
}
