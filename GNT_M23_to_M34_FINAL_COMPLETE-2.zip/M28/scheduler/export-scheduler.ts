/**
 * M28 — scheduler/export-scheduler.ts
 * OWN: Schedule report delivery using the approved scheduler.
 *
 * Rule 27 (Global Rules): M13 remains the canonical scheduler if verified in
 * the repository. M28 must integrate with M13 rather than create a
 * competing cron framework — this file NEVER runs its own cron loop; it
 * only registers a job description with an injected SchedulerPort.
 */

export interface ReportScheduleRequest {
  tenantId: string;
  templateId: string;
  cronExpression: string;
  format: 'PDF' | 'XLSX' | 'CSV';
  recipients: string[];
}

export interface SchedulerPort {
  /** Must be backed by the real, verified M13 scheduler — never a new cron loop. */
  registerJob(jobKey: string, cronExpression: string, payload: Record<string, unknown>): Promise<{ jobId: string }>;
  cancelJob(jobId: string): Promise<void>;
}

export class ExportScheduler {
  constructor(private readonly scheduler: SchedulerPort) {}

  async schedule(request: ReportScheduleRequest): Promise<{ jobId: string }> {
    const jobKey = `m28-report-export:${request.tenantId}:${request.templateId}`;
    return this.scheduler.registerJob(jobKey, request.cronExpression, {
      tenantId: request.tenantId,
      templateId: request.templateId,
      format: request.format,
      recipients: request.recipients,
    });
  }

  async unschedule(jobId: string): Promise<void> {
    await this.scheduler.cancelJob(jobId);
  }
}
