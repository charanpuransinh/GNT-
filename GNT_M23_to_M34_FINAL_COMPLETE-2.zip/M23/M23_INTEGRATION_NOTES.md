# M23 — Security, Governance & Data Protection — Integration Notes

STATUS: Source code READY (strict TypeScript, zero compile errors).
WIRING STATUS: BLOCKED — pending repository verification (Rule 1: No Guessing).

## What is done
All 13 files per the blueprint's M23 tree are generated with real logic
(not stubs) for: authorization evaluation, scope resolution, tenant-policy
engine, trusted tenant-context establishment, tenant-isolation guard,
cross-tenant attempt detection, sensitive-field detection, data masking,
data-retention execution, security audit logging, and security event
publishing. Compiles clean under `tsc --strict`.

## Why it is not wired into the live app yet
Per the blueprint's own Rule 1 and Rule 20 ("Wiring Only After Testing"),
several real repository details must be verified before this can be
connected to production GNT — none of these were guessed:

1. **M01 AuthUser shape** — the exact fields M01 attaches to an
   authenticated request. This module depends on a `TrustedRequestSource`
   interface instead, so it can be adapted once confirmed.
2. **M02 permission-string format** — assumed `MODULE.RESOURCE.ACTION`
   (matches this blueprint's own naming, e.g. `M23.SECURITY.READ`) but not
   yet cross-checked against M02's actual permission table.
3. **Shared EventBus class** (mentioned in project memory as already built)
   — `SecurityEventService` expects an `EventPublisher`-shaped adapter for
   it; not yet wired to the real class.
4. **M19 audit infrastructure** — unclear whether a canonical audit-log
   table already exists. `SecurityAuditService` currently owns its own
   `security_audit_event` table rather than assuming M19's schema.
5. **Scope source** (branch/department/team) — which existing module
   owns this master data is unconfirmed; `ScopeResolverService` depends on
   an injected `ScopeProvider` adapter rather than a guessed table.

## M21 note (per your earlier decision)
This blueprint's own text says "M01–M22 are treated as existing/canonical."
Per project decision on 2026-09-08, **M21 was retired as a standalone
module** and merged into M11's data-sense pipeline. M23 code does not
reference M21 in any way, so there is no conflict — flagged here only so
the fact is on record for whoever wires this in next.

## Not yet done (flagged, not hidden)
- Prisma schema / migration for `security_policy`, `security_audit_event`,
  `data_retention_policy` (Database Contract, Section 23) — not generated
  in this pass; needs an existing-schema inspection first per Section 23's
  own required steps.
- Unit test files (Rule 21's 10-scenario matrix, Section 25's full matrix)
  — not generated in this pass to keep this delivery inside the current
  token budget. Recommend as the very next task.
- Express-layer adapters (turning `TenantIsolationGuard`/`AuthorizationService`
  into actual middleware) — kept framework-agnostic until request/response
  shapes are verified.

## Next step recommendation
Give this integration-notes file + the actual GNT repo access (Trishul V2)
to resolve the 5 verification items above, then generate tests and wire.
