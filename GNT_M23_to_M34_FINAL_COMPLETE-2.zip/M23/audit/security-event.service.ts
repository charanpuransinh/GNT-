/**
 * M23 — audit/security-event.service.ts
 * OWN: Publish M23 security events, following the Event Contract (Section 22).
 *
 * Events owned by M23:
 *   SECURITY.ACCESS_DENIED
 *   SECURITY.CROSS_TENANT_ATTEMPT
 *   SECURITY.POLICY_CHANGED
 *   SECURITY.SENSITIVE_DATA_ACCESSED
 *   SECURITY.RETENTION_EXECUTED
 *
 * VERIFICATION NEEDED: the real event bus implementation. Memory notes an
 * EventBus class already exists in the shared infrastructure layer — this
 * service depends on an injected EventPublisher matching that class's public
 * contract rather than reimporting its internals directly (Calling Rule).
 */

export type M23EventName =
  | 'SECURITY.ACCESS_DENIED'
  | 'SECURITY.CROSS_TENANT_ATTEMPT'
  | 'SECURITY.POLICY_CHANGED'
  | 'SECURITY.SENSITIVE_DATA_ACCESSED'
  | 'SECURITY.RETENTION_EXECUTED';

export interface M23Event {
  eventName: M23EventName;
  tenantId: string;
  actorId: string;
  correlationId: string;
  entityType: string;
  entityId: string;
  payload?: Record<string, unknown>;
}

export interface EventPublisher {
  publish(event: {
    eventId: string;
    eventName: string;
    occurredAt: string;
    tenantId: string;
    actorId: string;
    correlationId: string;
    entityType: string;
    entityId: string;
    payloadVersion: number;
    payload: Record<string, unknown>;
  }): Promise<void>;
}

/** In-memory fallback publisher — replace with the verified shared EventBus when wiring. */
class InMemoryEventPublisher implements EventPublisher {
  async publish(): Promise<void> {
    // no-op fallback; real wiring must inject the verified EventBus
  }
}

export class SecurityEventService {
  constructor(private readonly publisher: EventPublisher = new InMemoryEventPublisher()) {}

  async publish(event: M23Event): Promise<void> {
    await this.publisher.publish({
      eventId: `evt_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`,
      eventName: event.eventName,
      occurredAt: new Date().toISOString(),
      tenantId: event.tenantId,
      actorId: event.actorId,
      correlationId: event.correlationId,
      entityType: event.entityType,
      entityId: event.entityId,
      payloadVersion: 1,
      payload: event.payload ?? {},
    });
  }
}

export const securityEventService = new SecurityEventService();
