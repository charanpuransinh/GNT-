/**
 * M23 — audit/security-audit.service.ts
 * OWN: Create immutable security audit records.
 * Backs table: security_audit_event (proposed, tenant-owned).
 *
 * Rule 10 (Global Rules): Security-sensitive, financial, HR, AI, integration,
 * permission and workflow actions must generate an immutable audit event.
 *
 * VERIFICATION NEEDED: whether GNT already has a canonical audit-log table
 * (memory notes an "existing audit infrastructure" referenced by M19).
 * Until confirmed, this service writes to its OWN security_audit_event table
 * rather than guessing M19's schema, and exposes a stable interface so it
 * can be re-pointed at a shared audit store later without changing callers.
 */

export interface SecurityAuditRecord {
  id?: string;
  tenantId: string;
  actorId: string;
  action: string;
  resourceType: string;
  resourceId: string;
  outcome: 'ALLOWED' | 'DENIED' | 'ERROR';
  correlationId: string;
  metadata?: Record<string, unknown>;
  createdAt?: string;
}

export interface SecurityAuditStore {
  insert(record: SecurityAuditRecord & { createdAt: string }): Promise<void>;
}

/** In-memory fallback — replace with the verified persistent store when wiring. */
class InMemorySecurityAuditStore implements SecurityAuditStore {
  private records: Array<SecurityAuditRecord & { createdAt: string }> = [];
  async insert(record: SecurityAuditRecord & { createdAt: string }): Promise<void> {
    this.records.push(record);
  }
  getAll() {
    return this.records;
  }
}

export class SecurityAuditService {
  constructor(private readonly store: SecurityAuditStore = new InMemorySecurityAuditStore()) {}

  /**
   * Records are never mutated or deleted through this service — only
   * inserted. Immutability is a contract requirement (Rule 10).
   */
  async record(entry: SecurityAuditRecord): Promise<void> {
    // Never log secrets/tokens/passwords (Rule 16) — callers must not put
    // them in metadata; this is a best-effort safety net for obvious keys.
    const safeMetadata = entry.metadata ? this.stripSensitiveKeys(entry.metadata) : undefined;

    await this.store.insert({
      ...entry,
      metadata: safeMetadata,
      createdAt: new Date().toISOString(),
    });
  }

  private stripSensitiveKeys(metadata: Record<string, unknown>): Record<string, unknown> {
    const blocked = ['password', 'token', 'secret', 'accessToken', 'refreshToken', 'cardNumber'];
    const cleaned: Record<string, unknown> = {};
    for (const [key, value] of Object.entries(metadata)) {
      if (blocked.some((b) => key.toLowerCase().includes(b.toLowerCase()))) continue;
      cleaned[key] = value;
    }
    return cleaned;
  }
}

export const securityAuditService = new SecurityAuditService();
