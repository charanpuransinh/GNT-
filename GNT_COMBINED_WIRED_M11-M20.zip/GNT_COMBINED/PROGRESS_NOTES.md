# GNT — Class C (M11-M15) + Team D (M16-M20) — Combined Wiring & Fix Log

## PASS 1 — WIRING / PLACEMENT (गलती नहीं ढूंढी, सिर्फ सही जगह पर रखा) — ✅ COMPLETE

Merged दोनों zip (GNT_CLASS_C_FINAL.zip + Tim_D.zip के अंदर की 5 nested zips) को एक
single repo structure में, ब्लूप्रिंट के मैपिंग के हिसाब से:

- `backend/src/modules/m11-payment` ... `m20-international-trade` — सभी 10 modules अब
  सही जगह पर हैं।
- `frontend/src/modules/mXX-...` — same.
- `api-contracts/v1/`, `database/`, `tests/`, `wiring-maps/` — merge किया गया।

**एक placement issue मिला और ठीक किया (यह गलती ढूंढना नहीं था, सिर्फ गलत जगह की बात थी):**
M19 (Tim_D.zip के अंदर `M19.zip`) ब्लूप्रिंट के standard पैटर्न
(`backend/src/modules/m19-.../...`) में नहीं था — सीधे `backend/controllers`,
`backend/services` जैसे loose folders में था। इसे
`backend/src/modules/m19-production-monitoring/` और
`frontend/src/modules/m19-production-monitoring/` में सही जगह पर रखा गया है।
कोई कोड नहीं बदला — सिर्फ location सही की गई।

## PASS 2 — गलती ढूंढना और ठीक करना (शुरुआत M11 से) — 🔄 IN PROGRESS

### M11 — Payment & Communication — ✅ Audited, 1 real बग मिला और ठीक किया

**बग मिला:** `repositories/ledger.repository.ts` सीधे `prisma.ledgerEntry.createMany()`
कर रहा था — यह table M10 (Accounting) की है, M11 की नहीं। Comment में लिखा था
"Links to M10 via PUBLIC API only" लेकिन असल कोड M10 की table में सीधे लिख रहा था।
यह module-boundary का उल्लंघन है (एक module दूसरे की table में सीधे नहीं लिख सकता)।

**ठीक कैसे किया:**
- नई file `services/ledgerPublicContract.ts` बनाई — एक PUBLIC-contract interface
  (`LedgerPublicContract.postJournalEntries`) जो M10 के असली `ledger.service.ts` से
  wire होगा जब वो उपलब्ध होगा। अभी तक `NotWiredLedgerContract` एक साफ error देता है
  (fake success नहीं देता)।
- `ledger.repository.ts` से `.create()`/`.createMany()` हटाया — अब सिर्फ read-only
  lookup (`findByTransaction`) बचा है, table को अपनी तरफ से नहीं लिखता।
- `payment.service.ts` के `processPayment()` में ledger-posting को अपने prisma
  transaction के बाहर निकाला और नए contract से call करवाया, try/catch के साथ (जब तक
  M10 wire नहीं होता, payment complete होगा पर ledger-posting "PENDING" log होगी,
  silently miss नहीं होगी)।

**Note (fix नहीं किया, सिर्फ flag कर रहा हूँ — confirm चाहिए):**
M11 का अपना `schema.prisma` अपना ही `Invoice` model define करता है
(`model Invoice { ... }`, `model InvoiceLineItem { ... }`)। Blueprint का rule है कि
Invoice Master सिर्फ एक जगह (सामान्यतः M08 Sales) होना चाहिए — duplicate नहीं।
हो सकता है यह M11 का अपना अलग "payment-request invoice" concept हो, इसलिए बिना
confirm किए schema नहीं छेड़ा। **Krisna से confirm चाहिए:** क्या यह जानबूझकर अलग
entity है, या यह असली duplicate-master violation है जिसे हटाना है?

अन्य M11 checks जो पास हुए (कोई बग नहीं मिला):
- `index.ts` सिर्फ controllers/services/routes/types export करता है, repositories
  export नहीं करता — boundary सही है।
- कोई illegal cross-module import (दूसरे module के repository/internal service को
  सीधे import करना) नहीं मिला।
- Event bus (`event.bus.ts`) सही events publish करता है जो M13/M15 सुनते हैं।

### M12 — HR — ✅ Audited, 1 बग मिला और ठीक किया

**बग मिला:** हर service file (`attendance`, `department`, `employee`, `leave`,
`payroll`) अपना अलग-अलग `new PrismaClient()` बना रहा था — 5 अलग connections।
Modular monolith में यह production में DB connection-pool exhaust कर सकता है।

**ठीक किया:** नई file `db.ts` बनाई जो एक ही shared `prisma` instance export करती
है; सभी 5 services अब वहीं से import करती हैं।

कोई cross-module boundary violation या fake/mock data नहीं मिला — M12 सिर्फ अपनी
own tables (Employee, Attendance, Department, Leave, Payroll...) छूता है।

### M13 — Automation — ⚠️ Audited, 1 बग ठीक किया + 1 बड़ी चीज़ सिर्फ FLAG की (fix नहीं)

**बग मिला और ठीक किया:** module का असली entry point `index.ts`, `"./queue/queue.setup"`
से import कर रहा था, जबकि असली file `./queue.setup.ts` है (कोई `queue/` subfolder
है ही नहीं) — यह import हमेशा crash करता। Path ठीक कर दिया।

**बड़ी चीज़ जो मिली, ठीक नहीं की, सिर्फ flag की:** M13 के अंदर दो अलग-अलग, आपस में
न जुड़े हुए implementation scaffold मिले:
- **असली/wired रास्ता** (module के `index.ts` से चलता है): `workflow.controller.ts`,
  `job.controller.ts`, `schedule.controller.ts` + `scheduler.service.ts` +
  `event.handler.ts`, routes `workflow.routes.ts`/`job.routes.ts`/`schedule.routes.ts`।
- **एक दूसरा, कहीं wire ना हुआ scaffold**: `routes/index.ts`, `controllers/WorkflowController.ts`,
  `ExecutionController.ts`, `WebhookController.ts`, `services/SchedulerService.ts`,
  `events/EventSubscriber.ts` — इनमें ऐसे imports हैं जो repo में मौजूद ही नहीं
  (`../../../m02-auth/src/middleware`, `../../../m03-core/src/middleware`,
  `../engine/WorkflowEngine`, `../scheduler/SchedulerService`)। यह असली module
  entry point से कहीं जुड़ा नहीं है, यानी dead/duplicate code है।

इन 6 files में साफ़ header comment लगा दिया है (कि यह orphaned है, wire नहीं है,
broken imports हैं) — **delete नहीं किया**, क्योंकि silent delete/rename मना है।
**Krisna से confirm चाहिए:** इसे पूरा हटाना है, या इसमें जो काम की चीज़ है (जैसे
`WebhookController` का HMAC-verified public webhook receiver) उसे असली wired
path में merge करना है।

`WorkflowEngine.ts`, `ActionRegistry.ts`, `DelayAction.ts`, `SendEmailAction.ts`
(root-level files) दोनों scaffold में शेयर होते हैं — यह असली/ज़रूरी files हैं,
इन्हें छुआ नहीं गया।

M13 की गहराई में और नहीं गया (90+ files हैं, बहुत सारे tests/dto/config files बाकी
हैं) — बाकी बचे हिस्से का audit अगली बार जारी रहेगा अगर ज़रूरत पड़े।

### M14 — Import/Export — ✅ बड़ा wiring बग मिला और ठीक किया

Module में तीन अलग-अलग implementation set थे — module का असली PUBLIC entry point
(`index.ts`) एक टूटे हुए scaffold को export कर रहा था
(`routes/importRoutes.ts` जो `../middleware/authMiddleware` और
`../middleware/validationMiddleware` import करता है — ये files कहीं हैं ही नहीं;
फाइल में खुद comment है "TEMP MOCK or real")। जबकि असली, पूरा काम करने वाला router
(`routes/index.ts`, Lock: LOCK_11_ROUTES, सही middleware `auth.ts`/`tenant.ts` और
सही controllers `import.controller.ts`/`export.controller.ts`/`template.controller.ts`/
`job.controller.ts` इस्तेमाल करता है) कहीं export/mount ही नहीं हो रहा था।

**ठीक किया:** `index.ts` को असली working router (`routes/index.ts`) और असली
services (`import.service.ts`, `export.service.ts`, `template.service.ts`,
`job.service.ts`) export करने के लिए दुरुस्त किया। पुराने camelCase files
(`importRoutes.ts`, `exportRoutes.ts`, `importController.ts`, `exportController.ts`,
`importService.ts`, `exportService.ts`, `uploadMiddleware.ts`) delete नहीं किए
(silent delete मना है) — वो अब unused पड़े हैं, Krisna confirm करें तो हटा देंगे।

### M15 — Sync — ✅ Quick wiring check पास, कोई बग नहीं मिला
`index.ts` का हर import path resolve होता है (`routes/sync.routes.ts`,
`utils/sync.errors.ts`) — सही तरह wired है।

### M16 — Notification — ✅ Quick wiring check पास
सभी 4 exports (`notification.service`, `notification.events`,
`notification.routes`, `notification.handlers`) सही resolve होते हैं। Frontend
`index.ts` नहीं है — flag कर रहा हूं, ज़रूरी नहीं कि बग हो, पर confirm कर लें।

### M17 — Reporting — ✅ 1 boundary violation मिला और ठीक किया
`index.ts` अपनी `report.internal.ts` (जिसके अपने header में लिखा है "INTERNAL
ONLY — Not exposed publicly") से `ReportQueryBuilder` को PUBLIC export कर रहा
था। हटा दिया — फाइल वैसी ही है, सिर्फ बाहर export होना बंद किया।

### M18 — External Integration — ✅ Quick wiring check पास, कोई बग नहीं मिला
सभी imports resolve होते हैं, कोई internal-leak नहीं।

### M19 — Production & Monitoring — ✅ 1 boundary violation मिला और ठीक किया
वैसा ही पैटर्न जैसा M17 में — `security.internal.ts` की क्लास `SecurityInternal`
(नाम से ही internal) index.ts से PUBLIC export हो रही थी। हटा दिया।

### M20 — International Trade — ✅ Quick wiring check पास, कोई बग नहीं मिला
सभी imports resolve होते हैं। Frontend `index.ts` नहीं है — flag कर रहा हूं।

## अगला कदम (Next)
1. Krisna से M11 duplicate Invoice model पर confirm लें।
2. Krisna से M13 orphaned scaffold (6 files) पर confirm लें — delete/merge।
3. Krisna से M14 के पुराने unused camelCase files पर confirm लें — delete करें या नहीं।
4. M16/M20 में frontend index.ts ना होने की वजह पता करें (जानबूझकर या गैप)।
5. यह "quick wiring pass" था (हर module की गहराई में हर file नहीं देखी) — अगर Krisna
   चाहें तो M11 जैसा गहरा (line-by-line) audit हर module का अलग से किया जा सकता है।

---
**यह zip session की latest copy है — M11 से M20 तक सभी 10 modules की wiring-level
जांच हो चुकी है, कुल 6 real बग मिले और ठीक किए गए (M11 ledger boundary, M12 Prisma
instances, M13 import path + orphaned scaffold flagged, M14 wrong PUBLIC entry point,
M17 internal-leak, M19 internal-leak)। मेरे पास भी यही state है।**
